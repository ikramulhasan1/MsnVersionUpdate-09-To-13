/**
 * Phase R2 (Technical SEO Audit) — polls
 * App\Http\Controllers\TechnicalSeoController::progress() every few
 * seconds while a scan is still in progress, updating the status
 * label in place; reloads the page once the scan finishes so the real
 * result (or error) renders through the normal Blade view rather than
 * this script trying to build the whole result display itself in JS.
 */
(function () {
    const card = document.getElementById('tsa-progress-card');

    if (!card) {
        return;
    }

    const progressUrl = card.dataset.progressUrl;
    const label = document.getElementById('tsa-progress-label');

    async function poll() {
        try {
            const response = await fetch(progressUrl, { headers: { Accept: 'application/json' } });
            const data = await response.json();

            if (label) {
                label.textContent = data.label + '…';
            }

            if (data.finished) {
                window.location.reload();

                return;
            }
        } catch (error) {
            // A single failed poll isn't fatal — just try again on the
            // next interval tick.
        }

        setTimeout(poll, 5000);
    }

    poll();
})();