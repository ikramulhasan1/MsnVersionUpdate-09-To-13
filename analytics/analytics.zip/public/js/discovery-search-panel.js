/**
 * Drives the Website Discovery search panel's cascading dropdowns
 * (resources/views/discovery/partials/search-panel.blade.php):
 * Sub-Niche is populated from the chosen Industry, and Region/City
 * from the chosen Country (Region additionally narrows City).
 *
 * Vanilla JS only, per project rules (see public/js/app.js) — no
 * build step, no framework. Follows the same fetch()-then/catch
 * pattern public/js/audit-progress.js already established for talking
 * to a JSON endpoint from this app's plain-JS layer.
 */
(function () {
    'use strict';

    var card = document.getElementById('discovery-search-panel-card');

    if (!card) {
        return;
    }

    var subNichesUrl = card.getAttribute('data-sub-niches-url');
    var regionsUrl = card.getAttribute('data-regions-url');
    var citiesUrl = card.getAttribute('data-cities-url');
    var searchesStoreUrl = card.getAttribute('data-searches-store-url');

    var industryField = document.getElementById('discovery-industry');
    var subNicheField = document.getElementById('discovery-sub-niche');
    var countryField = document.getElementById('discovery-country');
    var regionField = document.getElementById('discovery-region');
    var cityField = document.getElementById('discovery-city');

    /**
     * Replaces $field's options with a placeholder plus one <option>
     * per entry in $values, re-selecting $selectedValue if it's among
     * them (so a value carried over from a previous search submission
     * — see each select's own data-selected attribute — survives the
     * dropdown being repopulated).
     */
    function populate(field, values, placeholderText, selectedValue) {
        field.innerHTML = '';

        var placeholder = document.createElement('option');
        placeholder.value = '';
        placeholder.textContent = placeholderText;
        field.appendChild(placeholder);

        values.forEach(function (value) {
            var option = document.createElement('option');
            option.value = value;
            option.textContent = value;

            if (selectedValue && value === selectedValue) {
                option.selected = true;
            }

            field.appendChild(option);
        });
    }

    function setDisabled(field, disabled, placeholderText) {
        field.disabled = disabled;

        if (disabled) {
            field.innerHTML = '';
            var placeholder = document.createElement('option');
            placeholder.value = '';
            placeholder.textContent = placeholderText;
            field.appendChild(placeholder);
        }
    }

    function fetchJson(url, params) {
        var query = Object.keys(params)
            .filter(function (key) {
                return params[key];
            })
            .map(function (key) {
                return encodeURIComponent(key) + '=' + encodeURIComponent(params[key]);
            })
            .join('&');

        return fetch(url + (query ? '?' + query : ''), {
            headers: { Accept: 'application/json' },
        }).then(function (response) {
            if (!response.ok) {
                throw new Error('Discovery lookup request failed with ' + response.status);
            }
            return response.json();
        });
    }

    function loadSubNiches(selectedValue) {
        var industry = industryField.value;

        if (!industry) {
            setDisabled(subNicheField, true, 'Choose an industry first');
            return;
        }

        fetchJson(subNichesUrl, { industry: industry })
            .then(function (data) {
                subNicheField.disabled = false;
                populate(subNicheField, data.sub_niches || [], 'Any sub-niche', selectedValue);
            })
            .catch(function (error) {
                // Logged, not just shown as a placeholder — a silent failure
                // here previously gave no way to tell "the endpoint 404'd"
                // apart from "the network dropped" apart from "the response
                // wasn't valid JSON" from the UI alone.
                console.error('Failed to load sub-niches:', error);
                setDisabled(subNicheField, true, 'Unable to load sub-niches');
            });
    }

    function loadRegions(selectedValue) {
        var country = countryField.value;

        if (!country) {
            setDisabled(regionField, true, 'Choose a country first');
            setDisabled(cityField, true, 'Choose a country first');
            return;
        }

        fetchJson(regionsUrl, { country: country })
            .then(function (data) {
                regionField.disabled = false;
                populate(regionField, data.regions || [], 'Any region', selectedValue);
            })
            .catch(function (error) {
                console.error('Failed to load regions:', error);
                setDisabled(regionField, true, 'Unable to load regions');
            });

        // Cities depend on country alone (region further narrows them),
        // so they're loaded alongside regions rather than waiting for a
        // region to be picked first.
        loadCities(cityField.getAttribute('data-selected') || '');
    }

    function loadCities(selectedValue) {
        var country = countryField.value;

        if (!country) {
            setDisabled(cityField, true, 'Choose a country first');
            return;
        }

        fetchJson(citiesUrl, { country: country, region: regionField.value })
            .then(function (data) {
                cityField.disabled = false;
                populate(cityField, data.cities || [], 'Any city', selectedValue);
            })
            .catch(function (error) {
                console.error('Failed to load cities:', error);
                setDisabled(cityField, true, 'Unable to load cities');
            });
    }

    industryField.addEventListener('change', function () {
        loadSubNiches('');
    });

    countryField.addEventListener('change', function () {
        loadRegions('');
    });

    regionField.addEventListener('change', function () {
        loadCities(cityField.getAttribute('data-selected') || '');
    });

    // On first load, if a filter was already submitted (the page was
    // reached via a redirect from DiscoveryController::search()), the
    // relevant cascading dropdown(s) need to be populated immediately
    // — not only after the user changes the parent field — so the
    // previously chosen Sub-Niche/Region/City actually shows up
    // selected rather than reverting to "Any ...".
    if (industryField.value) {
        loadSubNiches(subNicheField.getAttribute('data-selected') || '');
    }

    if (countryField.value) {
        loadRegions(regionField.getAttribute('data-selected') || '');
    }

    // ---- Website Quality dual-range sliders (Phase C3) ---------------
    //
    // Two overlaid <input type="range"> elements per score (see the
    // .discovery-range-slider CSS in app.css) simulate a single dual-
    // handle slider: this keeps the min handle from passing the max
    // handle (and vice versa) and keeps each pair's on-screen "X-Y"
    // label in sync as either handle moves.
    function initRangeSliders() {
        var sliders = document.querySelectorAll('[data-range-slider]');

        sliders.forEach(function (slider) {
            var minInput = slider.querySelector('[data-range-role="min"]');
            var maxInput = slider.querySelector('[data-range-role="max"]');
            var wrapper = slider.parentElement;
            var minLabel = wrapper ? wrapper.querySelector('[data-range-min-label]') : null;
            var maxLabel = wrapper ? wrapper.querySelector('[data-range-max-label]') : null;

            if (!minInput || !maxInput) {
                return;
            }

            function render() {
                if (minLabel) {
                    minLabel.textContent = minInput.value;
                }
                if (maxLabel) {
                    maxLabel.textContent = maxInput.value;
                }
            }

            minInput.addEventListener('input', function () {
                if (parseInt(minInput.value, 10) > parseInt(maxInput.value, 10)) {
                    minInput.value = maxInput.value;
                }
                render();
            });

            maxInput.addEventListener('input', function () {
                if (parseInt(maxInput.value, 10) < parseInt(minInput.value, 10)) {
                    maxInput.value = minInput.value;
                }
                render();
            });
        });
    }

    initRangeSliders();

    // ---- Sort By dropdown (Phase D4) ---------------------------------
    //
    // Not part of the search <form> (that form only ever POSTs to
    // DiscoveryController::search(), which redirects back to a GET
    // index() URL — see search-panel.blade.php's own docblock), so
    // changing sort navigates directly to a modified version of the
    // CURRENT URL instead: every already-active filter in the query
    // string is preserved automatically (they're just left alone),
    // only `sort` is added/replaced, and `page` is reset to 1 since a
    // re-sorted result set starting on whatever page the user happened
    // to be on would be confusing.
    var sortField = document.getElementById('discovery-sort');

    if (sortField) {
        sortField.addEventListener('change', function () {
            var url = new URL(window.location.href);

            if (sortField.value) {
                url.searchParams.set('sort', sortField.value);
            } else {
                url.searchParams.delete('sort');
            }

            url.searchParams.delete('page');

            window.location.href = url.toString();
        });
    }

    // ---- Save this search (Phase F3) ----------------------------------
    //
    // A native window.prompt() for the name — this app has no modal/
    // dialog component of its own (see public/js/app.js's minimal,
    // framework-free scope), and a one-line text prompt is all "name
    // this search" needs. Reuses the same <form> the Search button
    // submits (so every currently-filled-in filter field is included
    // automatically), just pointed at a different action for this one
    // submission via form.action, with the name written into the
    // hidden #discovery-save-search-name input search-panel.blade.php
    // already renders for this purpose.
    var saveSearchButton = document.getElementById('discovery-save-search-btn');
    var saveSearchNameField = document.getElementById('discovery-save-search-name');
    var searchForm = document.getElementById('discovery-search-form');

    if (saveSearchButton && saveSearchNameField && searchForm && searchesStoreUrl) {
        saveSearchButton.addEventListener('click', function () {
            var name = window.prompt('Name this search:');

            if (!name || !name.trim()) {
                return;
            }

            saveSearchNameField.value = name.trim();
            searchForm.action = searchesStoreUrl;
            searchForm.submit();
        });
    }
})();