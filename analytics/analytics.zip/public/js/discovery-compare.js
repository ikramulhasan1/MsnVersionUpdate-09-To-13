/**
 * Website Discovery — Compare feature (Phase E2).
 *
 * Tracks 2-5 selected sites (by uuid) in localStorage across every
 * result-card.blade.php's "Compare" checkbox — chosen over sessionStorage
 * so a selection survives closing and reopening the tab, matching how a
 * shopping-comparison list is normally expected to persist while
 * browsing. Renders a floating "Compare (N)" bar fixed to the bottom of
 * the viewport once 2+ are selected, and disables any further unchecked
 * checkbox once 5 are selected (the DiscoveryController::compare()
 * endpoint this bar links to also validates 2-5 server-side — see that
 * method's own docblock — this is the primary UX guard, not the only
 * one).
 *
 * Vanilla JS only, per project rules (see public/js/app.js) — no build
 * step, no framework.
 */
(function () {
    'use strict';

    var STORAGE_KEY = 'discovery-compare-selection';
    var MIN_SELECTION = 2;
    var MAX_SELECTION = 5;

    var resultsSection = document.getElementById('discovery-results');
    var compareUrl = resultsSection ? resultsSection.getAttribute('data-compare-url') : null;

    // No "Compare" checkboxes anywhere on this page (e.g. the compare
    // page itself, or a future page that doesn't include result cards)
    // — nothing for this script to do.
    if (!document.querySelector('input[name="compare[]"]')) {
        return;
    }

    function readSelection() {
        try {
            var raw = window.localStorage.getItem(STORAGE_KEY);
            var parsed = raw ? JSON.parse(raw) : [];
            return Array.isArray(parsed) ? parsed : [];
        } catch (e) {
            // localStorage unavailable (private browsing, quota, disabled) —
            // the compare feature just won't persist across page loads;
            // fail silently rather than breaking the rest of the page.
            return [];
        }
    }

    function writeSelection(uuids) {
        try {
            window.localStorage.setItem(STORAGE_KEY, JSON.stringify(uuids));
        } catch (e) {
            // See readSelection() — same silent-failure reasoning.
        }
    }

    function syncCheckboxes(selection) {
        var checkboxes = document.querySelectorAll('input[name="compare[]"]');

        checkboxes.forEach(function (checkbox) {
            var isSelected = selection.indexOf(checkbox.value) !== -1;
            checkbox.checked = isSelected;
            checkbox.disabled = !isSelected && selection.length >= MAX_SELECTION;
        });
    }

    function buildCompareUrl(selection) {
        var params = selection
            .map(function (uuid) {
                return 'websites[]=' + encodeURIComponent(uuid);
            })
            .join('&');

        return (compareUrl || '/discovery/compare') + '?' + params;
    }

    function renderBar(selection) {
        var existing = document.getElementById('discovery-compare-bar');

        if (selection.length < MIN_SELECTION) {
            if (existing) {
                existing.remove();
            }
            return;
        }

        if (!existing) {
            existing = document.createElement('div');
            existing.id = 'discovery-compare-bar';
            existing.className = 'discovery-compare-bar';
            document.body.appendChild(existing);
        }

        existing.innerHTML = '';

        var countLabel = document.createElement('span');
        countLabel.className = 'small fw-medium me-1';
        countLabel.textContent = selection.length + ' selected';
        existing.appendChild(countLabel);

        var compareLink = document.createElement('a');
        compareLink.className = 'btn btn-primary btn-sm';
        compareLink.href = buildCompareUrl(selection);
        compareLink.textContent = 'Compare (' + selection.length + ')';
        existing.appendChild(compareLink);

        var clearButton = document.createElement('button');
        clearButton.type = 'button';
        clearButton.className = 'btn btn-outline-secondary btn-sm';
        clearButton.textContent = 'Clear';
        clearButton.addEventListener('click', function () {
            writeSelection([]);
            syncCheckboxes([]);
            renderBar([]);
        });
        existing.appendChild(clearButton);
    }

    // Delegated on document rather than bound per-checkbox: result cards
    // are rendered server-side per page load (no dynamic insertion today),
    // but delegation costs nothing here and stays correct if that ever
    // changes.
    document.addEventListener('change', function (event) {
        var target = event.target;

        if (!target || target.getAttribute('name') !== 'compare[]') {
            return;
        }

        var selection = readSelection();
        var uuid = target.value;

        if (target.checked) {
            if (selection.indexOf(uuid) === -1) {
                if (selection.length >= MAX_SELECTION) {
                    target.checked = false;
                    return;
                }
                selection.push(uuid);
            }
        } else {
            selection = selection.filter(function (id) {
                return id !== uuid;
            });
        }

        writeSelection(selection);
        syncCheckboxes(selection);
        renderBar(selection);
    });

    var initialSelection = readSelection();
    syncCheckboxes(initialSelection);
    renderBar(initialSelection);
})();