/**
 * Phase N2 (Sidebar Navigation) — toggles body.app-sidebar-collapsed
 * (see public/css/app.css's own .app-sidebar rules for what that
 * class actually does visually) and remembers the choice in
 * localStorage so the sidebar's own open/closed state survives a page
 * reload, the same persistence pattern public/js/theme.js already
 * established for the light/dark toggle.
 *
 * Vanilla JS only, per project rules — no build step, no framework.
 */
(function () {
    'use strict';

    var STORAGE_KEY = 'audit-sidebar-collapsed';
    var toggle = document.getElementById('app-sidebar-toggle');

    if (!toggle) {
        return;
    }

    if (localStorage.getItem(STORAGE_KEY) === '1') {
        document.body.classList.add('app-sidebar-collapsed');
        toggle.setAttribute('aria-expanded', 'false');
    }

    toggle.addEventListener('click', function () {
        var collapsed = document.body.classList.toggle('app-sidebar-collapsed');
        localStorage.setItem(STORAGE_KEY, collapsed ? '1' : '0');
        toggle.setAttribute('aria-expanded', collapsed ? 'false' : 'true');
    });
})();