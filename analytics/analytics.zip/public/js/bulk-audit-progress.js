/**
 * Website Audit — Bulk Audit progress polling (Phase K5).
 *
 * Mirrors public/js/audit-progress.js's own "poll while processing,
 * reload once finished" shape for a SINGLE audit, rolled up to a
 * whole App\Models\BulkAuditBatch instead — no smooth decimal
 * animation here (a batch's own progress is naturally chunky, "X of Y
 * finished", not a single continuously-advancing percentage the way
 * one audit's own pipeline stage is), just a periodic real poll and a
 * direct progress-bar width update.
 *
 * Vanilla JS only, per project rules (see public/js/app.js) — no
 * build step, no framework.
 */
(function () {
    'use strict';

    var POLL_INTERVAL_MS = 3000;

    var page = document.getElementById('bulk-audit-page');

    if (!page) {
        return;
    }

    var alreadyFinished = page.getAttribute('data-bulk-audit-finished') === '1';

    // Nothing to poll — the batch was already COMPLETED by the time
    // this page loaded (see resources/views/audit/bulk/show.blade.php's
    // own docblock: the progress card itself starts hidden in this
    // case too), so this script has no work to do at all.
    if (alreadyFinished) {
        return;
    }

    var progressUrl = page.getAttribute('data-bulk-audit-progress-url');
    var card = document.getElementById('bulk-audit-progress-card');
    var bar = document.getElementById('bulk-audit-progress-bar');
    var progressWrapper = bar ? bar.closest('[role="progressbar"]') : null;
    var label = document.getElementById('bulk-audit-progress-label');
    var countLabel = document.getElementById('bulk-audit-progress-count');
    var stopped = false;

    function poll() {
        if (stopped || !progressUrl) {
            return;
        }

        fetch(progressUrl, { headers: { Accept: 'application/json' } })
            .then(function (response) {
                if (!response.ok) {
                    throw new Error('progress request failed');
                }
                return response.json();
            })
            .then(function (data) {
                if (stopped) {
                    return;
                }

                if (bar) {
                    bar.style.width = data.percent + '%';
                }
                if (progressWrapper) {
                    progressWrapper.setAttribute('aria-valuenow', String(data.percent));
                }
                if (countLabel) {
                    countLabel.textContent = (data.completed + data.failed) + ' of ' + data.total + ' finished';
                }

                if (data.finished) {
                    stopped = true;

                    if (label) {
                        label.textContent = 'Done.';
                    }

                    // Reload once, the same way public/js/audit-progress.js
                    // does for a single audit — the freshly-rendered page
                    // (server-side) is what actually shows every audit's
                    // real, final scores; this script only ever animates
                    // the progress bar itself, never the results table.
                    window.location.reload();
                    return;
                }

                window.setTimeout(poll, POLL_INTERVAL_MS);
            })
            .catch(function () {
                // A transient network hiccup shouldn't permanently stop
                // polling — retry on the same interval rather than giving
                // up after one failed request.
                if (!stopped) {
                    window.setTimeout(poll, POLL_INTERVAL_MS);
                }
            });
    }

    if (card) {
        window.setTimeout(poll, POLL_INTERVAL_MS);
    }
})();