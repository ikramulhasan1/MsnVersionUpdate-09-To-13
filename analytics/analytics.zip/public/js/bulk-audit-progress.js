/**
 * Website Audit — Bulk Audit progress polling (Phase K5).
 *
 * Mirrors public/js/audit-progress.js's own "poll while processing,
 * reload once finished" shape for a SINGLE audit, rolled up to a
 * whole App\Models\BulkAuditBatch instead — no smooth decimal
 * animation here (a batch's own progress is naturally chunky, "X of Y
 * finished", not a single continuously-advancing percentage the way
 * one audit's own pipeline stage is), just a periodic real poll and a
 * direct progress-bar width update.
 *
 * ETA estimation mirrors public/js/audit-progress.js's own approach
 * (see that file's own docblock) but projects from a different rate:
 * average elapsed time PER FINISHED AUDIT so far, extrapolated across
 * however many are still left — (elapsedMs / finishedCount) *
 * remainingCount — rather than a single 0-100% progress figure. This
 * naturally accounts for App\Audit\Jobs\BulkFetchJob's own concurrent
 * pre-fetch (audits tend to start finishing in bursts once a chunk's
 * worth of pages come back, not one at a time at a perfectly even
 * pace), since it's based on actual completions observed, not a
 * theoretical per-audit duration.
 *
 * Vanilla JS only, per project rules (see public/js/app.js) — no
 * build step, no framework.
 */
(function () {
    'use strict';

    var POLL_INTERVAL_MS = 3000;

    var page = document.getElementById('bulk-audit-page');

    if (!page) {
        return;
    }

    var alreadyFinished = page.getAttribute('data-bulk-audit-finished') === '1';

    // Nothing to poll — the batch was already COMPLETED by the time
    // this page loaded (see resources/views/audit/bulk/show.blade.php's
    // own docblock: the progress card itself starts hidden in this
    // case too), so this script has no work to do at all.
    if (alreadyFinished) {
        return;
    }

    var progressUrl = page.getAttribute('data-bulk-audit-progress-url');
    var card = document.getElementById('bulk-audit-progress-card');
    var bar = document.getElementById('bulk-audit-progress-bar');
    var progressWrapper = bar ? bar.closest('[role="progressbar"]') : null;
    var label = document.getElementById('bulk-audit-progress-label');
    var countLabel = document.getElementById('bulk-audit-progress-count');
    var stopped = false;

    // ---- Estimated time remaining ------------------------------------
    var startedAt = Date.now();
    var etaRemainingMs = null;
    var etaLabel = document.getElementById('bulk-audit-progress-eta');
    var etaIntervalId = null;

    function formatEta(ms) {
        var totalSeconds = Math.max(0, Math.round(ms / 1000));
        var minutes = Math.floor(totalSeconds / 60);
        var seconds = totalSeconds % 60;

        return minutes + ':' + (seconds < 10 ? '0' : '') + seconds;
    }

    function renderEta() {
        if (!etaLabel) {
            return;
        }

        if (stopped) {
            etaLabel.textContent = 'Done.';
            return;
        }

        if (etaRemainingMs === null) {
            etaLabel.textContent = 'Estimating time remaining…';
            return;
        }

        etaLabel.textContent = '~' + formatEta(etaRemainingMs) + ' remaining';
    }

    function poll() {
        if (stopped || !progressUrl) {
            return;
        }

        fetch(progressUrl, { headers: { Accept: 'application/json' } })
            .then(function (response) {
                if (!response.ok) {
                    throw new Error('progress request failed');
                }
                return response.json();
            })
            .then(function (data) {
                if (stopped) {
                    return;
                }

                if (bar) {
                    bar.style.width = data.percent + '%';
                }
                if (progressWrapper) {
                    progressWrapper.setAttribute('aria-valuenow', String(data.percent));
                }
                if (countLabel) {
                    countLabel.textContent = (data.completed + data.failed) + ' of ' + data.total + ' finished';
                }

                // See this file's own docblock — projected from actual
                // completions-per-elapsed-time, not the single audit's
                // own 0-100% figure. Below 2 finished audits the rate is
                // too noisy to extrapolate from usefully, so the label
                // just keeps showing "Estimating…" until there's enough
                // real data.
                var finishedCount = data.completed + data.failed;
                var remainingCount = data.total - finishedCount;

                if (finishedCount >= 2 && remainingCount > 0) {
                    var elapsedMs = Date.now() - startedAt;
                    var avgMsPerAudit = elapsedMs / finishedCount;
                    etaRemainingMs = Math.max(0, avgMsPerAudit * remainingCount);
                } else if (remainingCount <= 0) {
                    etaRemainingMs = 0;
                }

                if (data.finished) {
                    stopped = true;
                    etaRemainingMs = 0;

                    if (label) {
                        label.textContent = 'Done.';
                    }
                    if (etaIntervalId !== null) {
                        window.clearInterval(etaIntervalId);
                        etaIntervalId = null;
                    }
                    renderEta();

                    // Reload once, the same way public/js/audit-progress.js
                    // does for a single audit — the freshly-rendered page
                    // (server-side) is what actually shows every audit's
                    // real, final scores; this script only ever animates
                    // the progress bar itself, never the results table.
                    window.location.reload();
                    return;
                }

                window.setTimeout(poll, POLL_INTERVAL_MS);
            })
            .catch(function () {
                // A transient network hiccup shouldn't permanently stop
                // polling — retry on the same interval rather than giving
                // up after one failed request.
                if (!stopped) {
                    window.setTimeout(poll, POLL_INTERVAL_MS);
                }
            });
    }

    if (card) {
        renderEta();
        etaIntervalId = window.setInterval(function () {
            if (etaRemainingMs !== null && etaRemainingMs > 0) {
                etaRemainingMs -= 1000;

                if (etaRemainingMs < 0) {
                    etaRemainingMs = 0;
                }
            }

            renderEta();
        }, 1000);

        window.setTimeout(poll, POLL_INTERVAL_MS);
    }
})();