/**
 * Phase O5 (Keyword List/Project Management) — the shared client-side
 * half of the "Add to List" flow. Loaded on both
 * keyword-research/index.blade.php and keyword-magic-tool/index.blade.php
 * (each already @includes keyword-lists/_add-to-list-modal.blade.php
 * once) — every "Add to List" / "+" button on either page calls
 * window.KeywordLists.open({keyword, volume, difficulty, cpc}) rather
 * than each page reimplementing this modal/fetch logic separately.
 */
window.KeywordLists = (function () {
    let pendingKeyword = null;
    let modalInstance = null;

    function ensureModal() {
        if (modalInstance === null) {
            const el = document.getElementById('kw-add-to-list-modal');
            modalInstance = new bootstrap.Modal(el);
        }

        return modalInstance;
    }

    async function loadExistingLists() {
        const select = document.getElementById('kw-existing-list-select');
        select.innerHTML = '<option value="">— Select a list —</option>';

        try {
            const response = await fetch('/keyword-lists/json', {
                headers: { Accept: 'application/json' },
            });
            const lists = await response.json();

            lists.forEach(function (list) {
                const option = document.createElement('option');
                option.value = list.id;
                option.textContent = list.name;
                select.appendChild(option);
            });
        } catch (error) {
            // A failed dropdown load isn't fatal — the "create a new
            // list" path below still works even if this silently
            // comes back empty.
        }
    }

    function open(keywordData) {
        pendingKeyword = keywordData;

        document.getElementById('kw-add-keyword-label').textContent = keywordData.keyword;
        document.getElementById('kw-new-list-name').value = '';
        document.getElementById('kw-add-to-list-error').classList.add('d-none');

        loadExistingLists();
        ensureModal().show();
    }

    async function submit() {
        const errorBox = document.getElementById('kw-add-to-list-error');
        errorBox.classList.add('d-none');

        const listId = document.getElementById('kw-existing-list-select').value;
        const newListName = document.getElementById('kw-new-list-name').value.trim();

        if (!listId && !newListName) {
            errorBox.textContent = 'Choose an existing list or name a new one.';
            errorBox.classList.remove('d-none');
            return;
        }

        const csrfToken = document.querySelector('meta[name="csrf-token"]').getAttribute('content');

        try {
            const response = await fetch('/keyword-lists/add-item', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    Accept: 'application/json',
                    'X-CSRF-TOKEN': csrfToken,
                },
                body: JSON.stringify({
                    list_id: listId || null,
                    new_list_name: newListName || null,
                    keyword: pendingKeyword.keyword,
                    volume: pendingKeyword.volume,
                    difficulty: pendingKeyword.difficulty,
                    cpc: pendingKeyword.cpc,
                }),
            });

            const data = await response.json();

            if (!response.ok) {
                errorBox.textContent = data.message || 'Something went wrong.';
                errorBox.classList.remove('d-none');
                return;
            }

            ensureModal().hide();
        } catch (error) {
            errorBox.textContent = 'Network error — please try again.';
            errorBox.classList.remove('d-none');
        }
    }

    document.addEventListener('DOMContentLoaded', function () {
        const submitButton = document.getElementById('kw-add-to-list-submit');

        if (submitButton) {
            submitButton.addEventListener('click', submit);
        }
    });

    return { open: open };
})();