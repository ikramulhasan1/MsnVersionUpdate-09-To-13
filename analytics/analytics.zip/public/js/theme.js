/**
 * Dark mode toggle. Persists the choice in localStorage and dispatches a
 * `themechange` event on document so other scripts (e.g. the dashboard
 * chart) can react without this file knowing anything about them.
 */
(function () {
    'use strict';

    var STORAGE_KEY = 'audit-theme';

    function currentTheme() {
        return document.documentElement.getAttribute('data-bs-theme') || 'light';
    }

    function applyTheme(theme, toggleButton) {
        document.documentElement.setAttribute('data-bs-theme', theme);
        localStorage.setItem(STORAGE_KEY, theme);

        if (toggleButton) {
            toggleButton.setAttribute('aria-pressed', theme === 'dark' ? 'true' : 'false');
        }

        document.dispatchEvent(new CustomEvent('themechange', { detail: { theme: theme } }));
    }

    document.addEventListener('DOMContentLoaded', function () {
        var toggleButton = document.getElementById('theme-toggle');

        if (!toggleButton) {
            return;
        }

        toggleButton.setAttribute('aria-pressed', currentTheme() === 'dark' ? 'true' : 'false');

        toggleButton.addEventListener('click', function () {
            var next = currentTheme() === 'dark' ? 'light' : 'dark';
            applyTheme(next, toggleButton);
        });
    });
})();
