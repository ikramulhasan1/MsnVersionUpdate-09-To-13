/**
 * Initializes the dashboard's Score Comparison (bar) and Category
 * Overview (radar) charts (Chart.js). Loaded only on the audit result
 * page, after the Chart.js CDN script. Kept separate from app.js so
 * pages without a dashboard never pay for it.
 *
 * Reads the "Inspection Certificate" palette's semantic colors
 * (--audit-success/--audit-warning/--audit-danger/--audit-muted and the
 * --audit-primary accent) straight from the computed CSS custom
 * properties, so both charts stay in sync with the active theme and the
 * rest of the dashboard's score coloring without duplicating hex values
 * in JS. Listens for the `themechange` event (dispatched by theme.js)
 * to re-read those colors when the user switches between light and dark
 * mode.
 *
 * The bar chart's bars use a fixed borderRadius (6) for rounded corners,
 * and the radar chart's fill uses a precise withAlpha()-computed 0.15
 * opacity rather than a hex-suffix shorthand — both are recomputed from
 * the live palette() on every themechange, so the finished look stays
 * consistent across theme switches, not just at initial render.
 */
(function () {
    'use strict';

    function cssVar(name) {
        return getComputedStyle(document.documentElement).getPropertyValue(name).trim();
    }

    function palette() {
        return {
            success: cssVar('--audit-success'),
            warning: cssVar('--audit-warning'),
            danger: cssVar('--audit-danger'),
            primary: cssVar('--audit-primary'),
            muted: cssVar('--audit-muted'),
            text: cssVar('--audit-muted'),
            grid: cssVar('--audit-border'),
        };
    }

    function withAlpha(hexColor, alpha) {
        const hex = hexColor.replace('#', '').trim();
        const normalized = hex.length === 3
            ? hex.split('').map((c) => c + c).join('')
            : hex;
        const value = parseInt(normalized, 16);
        const r = (value >> 16) & 255;
        const g = (value >> 8) & 255;
        const b = value & 255;

        return `rgba(${r}, ${g}, ${b}, ${alpha})`;
    }

    function scoreColor(score, colors) {
        if (score === null) {
            return colors.muted;
        }
        if (score >= 90) {
            return colors.success;
        }
        if (score >= 70) {
            return colors.primary;
        }
        if (score >= 50) {
            return colors.warning;
        }
        return colors.danger;
    }

    /**
     * Radar chart fill opacity: an exact 0.15 alpha via rgba() (computed
     * by withAlpha() above) rather than the previous hex-suffix
     * shorthand (colors.primary + '33', ~0.2) — precise and readable,
     * and correct regardless of whether the underlying CSS variable is
     * ever expressed as a 3- or 6-digit hex value.
     */
    const RADAR_FILL_OPACITY = 0.15;

    document.addEventListener('DOMContentLoaded', function () {
        initScoreComparisonChart();
        initCategoryRadarChart();
    });

    function initScoreComparisonChart() {
        const canvas = document.getElementById('scoreComparisonChart');

        if (! canvas || typeof Chart === 'undefined') {
            return;
        }

        const labels = JSON.parse(canvas.dataset.labels || '[]');
        const scores = JSON.parse(canvas.dataset.scores || '[]');
        const colors = palette();

        const chart = new Chart(canvas, {
            type: 'bar',
            data: {
                labels: labels,
                datasets: [{
                    label: 'Score',
                    data: scores,
                    backgroundColor: scores.map((s) => scoreColor(s, colors)),
                    borderRadius: 6,
                    maxBarThickness: 48,
                }],
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: { display: false },
                    tooltip: {
                        callbacks: {
                            label: (context) => (context.parsed.y === null ? 'Not available' : context.parsed.y + ' / 100'),
                        },
                    },
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        max: 100,
                        ticks: { stepSize: 20, color: colors.text },
                        grid: { color: colors.grid },
                    },
                    x: {
                        ticks: { color: colors.text },
                        grid: { display: false },
                    },
                },
            },
        });

        document.addEventListener('themechange', function () {
            const updated = palette();
            chart.data.datasets[0].backgroundColor = scores.map((s) => scoreColor(s, updated));
            chart.options.scales.y.ticks.color = updated.text;
            chart.options.scales.y.grid.color = updated.grid;
            chart.options.scales.x.ticks.color = updated.text;
            chart.update();
        });
    }

    function initCategoryRadarChart() {
        const canvas = document.getElementById('categoryRadarChart');

        if (! canvas || typeof Chart === 'undefined') {
            return;
        }

        const labels = JSON.parse(canvas.dataset.labels || '[]');
        const scores = JSON.parse(canvas.dataset.scores || '[]');
        // Chart.js's radial scale can't plot null, so a category with no
        // score yet renders as 0 on the chart itself — the bar chart and
        // category cards elsewhere on the page are what honestly show
        // "not available" for that category; this chart is a shape
        // overview, not the source of truth for any single score.
        const plottedScores = scores.map((s) => (s === null ? 0 : s));
        const colors = palette();

        const chart = new Chart(canvas, {
            type: 'radar',
            data: {
                labels: labels,
                datasets: [{
                    label: 'Score',
                    data: plottedScores,
                    backgroundColor: withAlpha(colors.primary, RADAR_FILL_OPACITY),
                    borderColor: colors.primary,
                    pointBackgroundColor: colors.primary,
                    borderWidth: 2,
                }],
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: { display: false },
                    tooltip: {
                        callbacks: {
                            label: (context) => {
                                const raw = scores[context.dataIndex];
                                return raw === null ? 'Not available' : raw + ' / 100';
                            },
                        },
                    },
                },
                scales: {
                    r: {
                        beginAtZero: true,
                        max: 100,
                        ticks: { stepSize: 25, backdropColor: 'transparent', color: colors.text },
                        grid: { color: colors.grid },
                        angleLines: { color: colors.grid },
                        pointLabels: { color: colors.text, font: { size: 11 } },
                    },
                },
            },
        });

        document.addEventListener('themechange', function () {
            const updated = palette();
            chart.data.datasets[0].backgroundColor = withAlpha(updated.primary, RADAR_FILL_OPACITY);
            chart.data.datasets[0].borderColor = updated.primary;
            chart.data.datasets[0].pointBackgroundColor = updated.primary;
            chart.options.scales.r.ticks.color = updated.text;
            chart.options.scales.r.grid.color = updated.grid;
            chart.options.scales.r.angleLines.color = updated.grid;
            chart.options.scales.r.pointLabels.color = updated.text;
            chart.update();
        });
    }
})();