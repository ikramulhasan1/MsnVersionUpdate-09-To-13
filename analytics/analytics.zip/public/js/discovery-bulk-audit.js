/**
 * Website Discovery — Bulk Audit (Phase H1).
 *
 * A separate selection from public/js/discovery-compare.js's own
 * "Compare" checkboxes (different feature, different name attribute —
 * bulk_audit[] vs compare[] — different cap): tracks up to
 * MAX_SELECTION selected sites in localStorage across page loads/
 * pagination, and shows a floating "Bulk Audit Selected (N)" bar once
 * 1+ is checked. Clicking that bar's button submits the hidden,
 * server-rendered #discovery-bulk-audit-form (see
 * discovery/index.blade.php — it already carries a real @csrf token,
 * so this script only ever needs to populate it with hidden
 * bulk_audit[] inputs before calling form.submit(), never build its
 * own CSRF token from scratch) to
 * App\Http\Controllers\DiscoveryController::bulkAudit().
 *
 * This app has no queue worker — every audit in the selection runs
 * fully, one after another, in the same request that submission makes
 * (see that controller method's own docblock) — so the confirmation
 * prompt below warns about the wait rather than submitting silently.
 */
(function () {
    'use strict';

    var STORAGE_KEY = 'discovery-bulk-audit-selection';
    var MAX_SELECTION = 5;

    var form = document.getElementById('discovery-bulk-audit-form');

    // No "Audit" checkboxes anywhere on this page — nothing for this
    // script to do.
    if (!document.querySelector('input[name="bulk_audit[]"]') || !form) {
        return;
    }

    function readSelection() {
        try {
            var raw = window.localStorage.getItem(STORAGE_KEY);
            var parsed = raw ? JSON.parse(raw) : [];
            return Array.isArray(parsed) ? parsed : [];
        } catch (e) {
            return [];
        }
    }

    function writeSelection(uuids) {
        try {
            window.localStorage.setItem(STORAGE_KEY, JSON.stringify(uuids));
        } catch (e) {
            // localStorage unavailable — the selection just won't persist
            // across page loads; fail silently rather than breaking the
            // rest of the page.
        }
    }

    function syncCheckboxes(selection) {
        var checkboxes = document.querySelectorAll('input[name="bulk_audit[]"]');

        checkboxes.forEach(function (checkbox) {
            var isSelected = selection.indexOf(checkbox.value) !== -1;
            checkbox.checked = isSelected;
            checkbox.disabled = !isSelected && selection.length >= MAX_SELECTION;
        });
    }

    function submitBulkAudit(selection) {
        // Clear out any hidden inputs from a previous population before
        // adding the current selection — this form is reused, not
        // rebuilt, so stale inputs from an earlier state need removing
        // first.
        form.querySelectorAll('input[name="bulk_audit[]"]').forEach(function (input) {
            input.remove();
        });

        selection.forEach(function (uuid) {
            var input = document.createElement('input');
            input.type = 'hidden';
            input.name = 'bulk_audit[]';
            input.value = uuid;
            form.appendChild(input);
        });

        // Cleared before navigating away, not after: once the browser
        // leaves this page for the redirect, there is no "after" for
        // this script to run in. Clearing now means the page this
        // navigation lands back on starts with an empty selection
        // (these sites were JUST audited, not still pending one),
        // rather than confusingly re-showing the same bar again.
        writeSelection([]);

        form.submit();
    }

    function renderBar(selection) {
        var existing = document.getElementById('discovery-bulk-audit-bar');

        if (selection.length < 1) {
            if (existing) {
                existing.remove();
            }
            return;
        }

        if (!existing) {
            existing = document.createElement('div');
            existing.id = 'discovery-bulk-audit-bar';
            // Reuses .discovery-compare-bar's own fixed-floating-pill
            // styling (Phase E2) rather than a new CSS class — the two
            // bars never appear at the same time (a page reload always
            // starts with neither), so there's no visual clash to avoid.
            existing.className = 'discovery-compare-bar';
            document.body.appendChild(existing);
        }

        existing.innerHTML = '';

        var countLabel = document.createElement('span');
        countLabel.className = 'small fw-medium me-1';
        countLabel.textContent = selection.length + ' selected';
        existing.appendChild(countLabel);

        var auditButton = document.createElement('button');
        auditButton.type = 'button';
        auditButton.className = 'btn btn-primary btn-sm';
        auditButton.textContent = 'Bulk Audit Selected (' + selection.length + ')';
        auditButton.addEventListener('click', function () {
            var confirmed = window.confirm(
                'Audit ' + selection.length + ' selected website(s) now?\n\n'
                + 'Each audit runs fully before the next starts, so this may take '
                + 'several minutes — please wait for the page to reload rather than '
                + 'navigating away.',
            );

            if (confirmed) {
                submitBulkAudit(selection);
            }
        });
        existing.appendChild(auditButton);

        var clearButton = document.createElement('button');
        clearButton.type = 'button';
        clearButton.className = 'btn btn-outline-secondary btn-sm';
        clearButton.textContent = 'Clear';
        clearButton.addEventListener('click', function () {
            writeSelection([]);
            syncCheckboxes([]);
            renderBar([]);
        });
        existing.appendChild(clearButton);
    }

    document.addEventListener('change', function (event) {
        var target = event.target;

        if (!target || target.getAttribute('name') !== 'bulk_audit[]') {
            return;
        }

        var selection = readSelection();
        var uuid = target.value;

        if (target.checked) {
            if (selection.indexOf(uuid) === -1) {
                if (selection.length >= MAX_SELECTION) {
                    target.checked = false;
                    return;
                }
                selection.push(uuid);
            }
        } else {
            selection = selection.filter(function (id) {
                return id !== uuid;
            });
        }

        writeSelection(selection);
        syncCheckboxes(selection);
        renderBar(selection);
    });

    var initialSelection = readSelection();
    syncCheckboxes(initialSelection);
    renderBar(initialSelection);
})();