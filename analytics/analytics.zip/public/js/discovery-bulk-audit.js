/**
 * Website Discovery — Bulk Audit (Phase H1, extended in Phase K3).
 *
 * A separate selection from public/js/discovery-compare.js's own
 * "Compare" checkboxes (different feature, different name attribute —
 * bulk_audit[] vs compare[] — different cap): tracks up to
 * MAX_SELECTION selected sites in localStorage across page loads/
 * pagination, and shows a floating "Bulk Audit Selected (N)" bar once
 * 1+ is checked. Clicking that bar's button submits the hidden,
 * server-rendered #discovery-bulk-audit-form (see
 * discovery/index.blade.php — it already carries a real @csrf token,
 * so this script only ever needs to populate it with hidden
 * bulk_audit[] inputs — and now, Phase K3, a mode value too — before
 * calling form.submit(), never build its own CSRF token from scratch)
 * to App\Http\Controllers\DiscoveryController::bulkAudit().
 *
 * Phase K3: that controller method now dispatches through
 * App\Audit\Services\BulkAuditBatchService (a real, dedicated-queue
 * batch) instead of running every selected website's audit
 * synchronously in the same request — MAX_SELECTION is raised well
 * past its old, request-timeout-driven value of 5 for the same reason
 * DiscoveryController::MAX_BULK_AUDIT's own docblock explains, and the
 * bar now includes a Quick Scan / Full Audit choice (mirroring
 * App\Audit\Enums\AuditMode's own two options everywhere else this app
 * offers that choice) rather than always running one fixed mode.
 */
(function () {
    'use strict';

    var STORAGE_KEY = 'discovery-bulk-audit-selection';
    var MAX_SELECTION = 100;

    var form = document.getElementById('discovery-bulk-audit-form');

    // No "Audit" checkboxes anywhere on this page — nothing for this
    // script to do.
    if (!document.querySelector('input[name="bulk_audit[]"]') || !form) {
        return;
    }

    function readSelection() {
        try {
            var raw = window.localStorage.getItem(STORAGE_KEY);
            var parsed = raw ? JSON.parse(raw) : [];
            return Array.isArray(parsed) ? parsed : [];
        } catch (e) {
            return [];
        }
    }

    function writeSelection(uuids) {
        try {
            window.localStorage.setItem(STORAGE_KEY, JSON.stringify(uuids));
        } catch (e) {
            // localStorage unavailable — the selection just won't persist
            // across page loads; fail silently rather than breaking the
            // rest of the page.
        }
    }

    function syncCheckboxes(selection) {
        var checkboxes = document.querySelectorAll('input[name="bulk_audit[]"]');

        checkboxes.forEach(function (checkbox) {
            var isSelected = selection.indexOf(checkbox.value) !== -1;
            checkbox.checked = isSelected;
            checkbox.disabled = !isSelected && selection.length >= MAX_SELECTION;
        });
    }

    function submitBulkAudit(selection, mode) {
        // Clear out any hidden inputs from a previous population before
        // adding the current selection — this form is reused, not
        // rebuilt, so stale inputs from an earlier state need removing
        // first.
        form.querySelectorAll('input[name="bulk_audit[]"], input[name="mode"]').forEach(function (input) {
            input.remove();
        });

        selection.forEach(function (uuid) {
            var input = document.createElement('input');
            input.type = 'hidden';
            input.name = 'bulk_audit[]';
            input.value = uuid;
            form.appendChild(input);
        });

        var modeInput = document.createElement('input');
        modeInput.type = 'hidden';
        modeInput.name = 'mode';
        modeInput.value = mode;
        form.appendChild(modeInput);

        // Cleared before navigating away, not after: once the browser
        // leaves this page for the redirect, there is no "after" for
        // this script to run in. Clearing now means the page this
        // navigation lands back on starts with an empty selection
        // (these sites were JUST audited, not still pending one),
        // rather than confusingly re-showing the same bar again.
        writeSelection([]);

        form.submit();
    }

    function renderBar(selection) {
        var existing = document.getElementById('discovery-bulk-audit-bar');

        if (selection.length < 1) {
            if (existing) {
                existing.remove();
            }
            return;
        }

        if (!existing) {
            existing = document.createElement('div');
            existing.id = 'discovery-bulk-audit-bar';
            // Reuses .discovery-compare-bar's own fixed-floating-pill
            // styling (Phase E2) rather than a new CSS class — the two
            // bars never appear at the same time (a page reload always
            // starts with neither), so there's no visual clash to avoid.
            existing.className = 'discovery-compare-bar';
            document.body.appendChild(existing);
        }

        existing.innerHTML = '';

        var countLabel = document.createElement('span');
        countLabel.className = 'small fw-medium me-1';
        countLabel.textContent = selection.length + ' selected';
        existing.appendChild(countLabel);

        // Phase K3 — mirrors App\Audit\Enums\AuditMode's own two
        // options everywhere else this app offers this choice (see
        // home/index.blade.php's and resources/views/audit/bulk/create.blade.php's
        // own radio versions of the same choice). A plain <select>
        // here rather than radios, purely because this floating bar is
        // already tight on horizontal space.
        var modeSelect = document.createElement('select');
        modeSelect.className = 'form-select form-select-sm w-auto';
        modeSelect.setAttribute('aria-label', 'Audit mode');

        ['quick', 'full'].forEach(function (value) {
            var option = document.createElement('option');
            option.value = value;
            option.textContent = value === 'quick' ? 'Quick Scan' : 'Full Audit';
            modeSelect.appendChild(option);
        });

        existing.appendChild(modeSelect);

        var auditButton = document.createElement('button');
        auditButton.type = 'button';
        auditButton.className = 'btn btn-primary btn-sm';
        auditButton.textContent = 'Bulk Audit Selected (' + selection.length + ')';
        auditButton.addEventListener('click', function () {
            var mode = modeSelect.value;
            var modeLabel = mode === 'quick' ? 'Quick Scan' : 'Full Audit';

            var confirmed = window.confirm(
                'Queue ' + selection.length + ' selected website(s) for ' + modeLabel + '?\n\n'
                + 'These are queued, not run immediately — the page reloads right away, but '
                + 'it can take a little while before all results actually appear. Refresh '
                + 'the batch page again after a few minutes.',
            );

            if (confirmed) {
                submitBulkAudit(selection, mode);
            }
        });
        existing.appendChild(auditButton);

        var clearButton = document.createElement('button');
        clearButton.type = 'button';
        clearButton.className = 'btn btn-outline-secondary btn-sm';
        clearButton.textContent = 'Clear';
        clearButton.addEventListener('click', function () {
            writeSelection([]);
            syncCheckboxes([]);
            renderBar([]);
        });
        existing.appendChild(clearButton);
    }

    document.addEventListener('change', function (event) {
        var target = event.target;

        if (!target || target.getAttribute('name') !== 'bulk_audit[]') {
            return;
        }

        var selection = readSelection();
        var uuid = target.value;

        if (target.checked) {
            if (selection.indexOf(uuid) === -1) {
                if (selection.length >= MAX_SELECTION) {
                    target.checked = false;
                    return;
                }
                selection.push(uuid);
            }
        } else {
            selection = selection.filter(function (id) {
                return id !== uuid;
            });
        }

        writeSelection(selection);
        syncCheckboxes(selection);
        renderBar(selection);
    });

    var initialSelection = readSelection();
    syncCheckboxes(initialSelection);
    renderBar(initialSelection);
})();