/**
 * Polls GET /audits/{audit}/progress while an audit is still processing
 * and updates the progress bar / percentage / label in place. Once the
 * server reports the audit finished, reloads the page once so the full
 * results dashboard (or the failure state) renders — this script only
 * ever runs on the "still processing" branch of the result page, so a
 * reload here always lands back on a URL that now shows the real content.
 *
 * Vanilla JS only, per project rules (see public/js/app.js) — no build
 * step, no framework.
 */
(function () {
    'use strict';

    var POLL_INTERVAL_MS = 1000;
    var card = document.getElementById('audit-progress-card');

    if (!card) {
        return;
    }

    var progressUrl = card.getAttribute('data-audit-progress-url');
    var bar = document.getElementById('audit-progress-bar');
    var percentLabel = document.getElementById('audit-progress-percent');
    var statusLabel = document.getElementById('audit-progress-label');
    var progressWrapper = bar ? bar.closest('[role="progressbar"]') : null;
    var stopped = false;
    var finished = false;

    // ---- Smooth decimal animation state -----------------------------
    //
    // The server only reports whole-stage percentages (e.g. it jumps
    // 10 -> 35 -> 70 -> 100 as each pipeline step finishes), which would
    // look like the bar "hangs then jumps" if applied directly. Instead
    // we keep a floating-point `displayed` value that's continuously
    // eased toward the latest real number every animation frame, and
    // rendered with one decimal place (e.g. "42.7%") so it always looks
    // like it's live-climbing rather than sitting still between polls.
    //
    // A small "creep" ceiling is also allowed to inch ahead of the last
    // real server value while we wait for the next poll, purely so the
    // number never looks frozen for a full second at a time. It is
    // capped well below the next real jump and is always corrected back
    // to the true value as soon as a fresh poll response arrives, so it
    // never drifts far from what's actually happening server-side.
    var displayed = 0; // what's currently rendered, with decimals
    var realTarget = 0; // last confirmed percent from the server
    var lastRealChangeAt = Date.now(); // last time realTarget actually moved
    var CREEP_PER_SECOND = 1.5; // max fake-forward drift per second of waiting
    var CREEP_CAP_ABOVE_TARGET = 6; // never creep more than this far past realTarget
    var STALL_THRESHOLD_MS = 45 * 1000; // no real movement this long => show stall hint
    var stallHint = document.getElementById('audit-progress-stall-hint');
    var rafId = null;

    function creepCeiling() {
        // Time is measured from the last genuine change in realTarget,
        // not from the last poll — polls happen every second regardless
        // of whether the server has actually made progress, so basing
        // this on "time since poll" made the creep budget collapse back
        // toward realTarget every single second even while the audit
        // was fully stuck, producing a visible 0% -> ~2% -> 0% sawtooth
        // instead of an honest "stopped climbing" plateau.
        var secondsSinceRealChange = (Date.now() - lastRealChangeAt) / 1000;
        var creep = Math.min(CREEP_CAP_ABOVE_TARGET, secondsSinceRealChange * CREEP_PER_SECOND);

        return Math.min(99, realTarget + creep);
    }

    function render(percent) {
        if (bar) {
            bar.style.width = percent + '%';
        }

        if (progressWrapper) {
            progressWrapper.setAttribute('aria-valuenow', String(Math.round(percent)));
        }

        if (percentLabel) {
            percentLabel.textContent = percent.toFixed(1);
        }
    }

    function tick() {
        var target = finished ? 100 : creepCeiling();

        // Ease toward the target rather than snapping, so each frame's
        // movement is a fraction of the remaining distance — fast at
        // first, settling smoothly as it approaches the target.
        displayed += (target - displayed) * (finished ? 0.15 : 0.08);

        if (Math.abs(target - displayed) < 0.05) {
            displayed = target;
        }

        render(displayed);

        if (finished && displayed >= 99.95) {
            render(100);
            window.setTimeout(function () {
                window.location.reload();
            }, 400);
            return;
        }

        rafId = window.requestAnimationFrame(tick);
    }

    function applyProgress(data) {
        var newTarget = Math.max(0, Math.min(100, data.percent || 0));

        if (newTarget !== realTarget) {
            realTarget = newTarget;
            lastRealChangeAt = Date.now();

            if (stallHint) {
                stallHint.classList.add('d-none');
            }
        } else if (stallHint && Date.now() - lastRealChangeAt >= STALL_THRESHOLD_MS) {
            // The server keeps reporting the same percent poll after
            // poll — most commonly because nothing is actually picking
            // the audit up (e.g. the deployment's QUEUE_CONNECTION isn't
            // "sync" and there's no queue:work worker running). Surface
            // that honestly instead of letting the "usually takes a few
            // seconds" copy sit there indefinitely.
            stallHint.classList.remove('d-none');
        }

        if (statusLabel && data.label) {
            statusLabel.textContent = data.label;
        }
    }

    function poll() {
        if (stopped) {
            return;
        }

        fetch(progressUrl, {
            headers: { Accept: 'application/json' },
        })
            .then(function (response) {
                if (!response.ok) {
                    throw new Error('Progress request failed with ' + response.status);
                }
                return response.json();
            })
            .then(function (data) {
                applyProgress(data);

                if (data.finished) {
                    stopped = true;
                    finished = true;
                    if (bar) {
                        bar.classList.remove('progress-bar-animated');
                    }
                    return;
                }

                window.setTimeout(poll, POLL_INTERVAL_MS);
            })
            .catch(function () {
                // Transient network hiccup — keep trying rather than
                // leaving the bar stuck; a real failure will eventually
                // surface via the audit's own FAILED status.
                window.setTimeout(poll, POLL_INTERVAL_MS);
            });
    }

    rafId = window.requestAnimationFrame(tick);
    poll();
})();
