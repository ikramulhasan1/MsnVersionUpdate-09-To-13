/**
 * Wires up the Outreach Draft card's "Copy" button
 * (resources/views/audit/result.blade.php) to copy the drafted
 * subject + body to the clipboard via the Clipboard API. Loaded only
 * on the audit result page, kept separate from app.js/dashboard-
 * charts.js so pages without an Outreach Draft card never pay for it.
 *
 * Subject/body are read from the button's own data-outreach-subject/
 * data-outreach-body attributes (Blade-escaped when rendered, then
 * decoded back to plain text by the browser's own attribute parsing —
 * no separate unescaping needed here) rather than re-reading the
 * rendered Subject row / <pre> body text, so what gets copied is
 * exactly the same draft text the server produced, independent of any
 * later DOM/whitespace formatting in either element.
 */
(function () {
    'use strict';

    const COPIED_LABEL = 'Copied!';
    const COPIED_DURATION_MS = 2000;

    document.addEventListener('DOMContentLoaded', function () {
        const buttons = document.querySelectorAll('.outreach-copy-btn');

        buttons.forEach(function (button) {
            button.addEventListener('click', function () {
                copyDraft(button);
            });
        });
    });

    function copyDraft(button) {
        if (! navigator.clipboard || ! navigator.clipboard.writeText) {
            return;
        }

        const subject = button.dataset.outreachSubject || '';
        const body = button.dataset.outreachBody || '';
        const text = subject !== '' ? `Subject: ${subject}\n\n${body}` : body;

        navigator.clipboard.writeText(text).then(function () {
            showCopiedState(button);
        }).catch(function () {
            // Clipboard permission denied or unavailable in this
            // context — fail silently rather than showing a false
            // "Copied!" confirmation the user didn't actually get.
        });
    }

    function showCopiedState(button) {
        const label = button.querySelector('.outreach-copy-label');

        if (! label) {
            return;
        }

        const originalLabel = label.textContent;

        button.classList.add('is-copied');
        label.textContent = COPIED_LABEL;

        window.setTimeout(function () {
            button.classList.remove('is-copied');
            label.textContent = originalLabel;
        }, COPIED_DURATION_MS);
    }
})();