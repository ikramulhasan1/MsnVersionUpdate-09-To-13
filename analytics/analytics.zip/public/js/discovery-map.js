/**
 * Website Discovery — Map View (Phase E3).
 *
 * Drives the "List View | Map View" toggle and, on first switch to Map
 * View, lazy-loads a Leaflet map and plots every filtered result that
 * has a latitude/longitude (see
 * App\Http\Controllers\DiscoveryController::mapData()'s own docblock
 * for why this is a separate, unpaginated JSON fetch rather than reading
 * markers off the List View's own paginated $websites). Leaflet itself
 * is loaded via CDN in discovery/index.blade.php's own @push('scripts')
 * (this app has no JS build step/bundler — see public/js/app.js's own
 * "vanilla JS only" rule — so a CDN `<script>` tag, matching how
 * Bootstrap/Chart.js are already loaded elsewhere in this app, is the
 * simplest way to bring in a small third-party library like this).
 */
(function () {
    'use strict';

    var mapSection = document.getElementById('discovery-map-section');
    var listSection = document.getElementById('discovery-results-list');
    var listViewButton = document.getElementById('discovery-view-list');
    var mapViewButton = document.getElementById('discovery-view-map');

    if (!mapSection || !listSection || !listViewButton || !mapViewButton) {
        return;
    }

    var mapDataUrl = mapSection.getAttribute('data-map-data-url');
    var map = null;
    var markersLoaded = false;

    function escapeHtml(text) {
        var div = document.createElement('div');
        div.textContent = text == null ? '' : String(text);
        return div.innerHTML;
    }

    function scoreOrDash(value) {
        return value === null || value === undefined ? '—' : value;
    }

    function buildPopupHtml(site) {
        var name = escapeHtml(site.name || site.domain);
        var domain = escapeHtml(site.domain);
        var showUrl = escapeHtml(site.show_url);

        return (
            '<div class="discovery-map-popup">' +
            '<p class="fw-medium mb-1"><a href="' + showUrl + '">' + name + '</a></p>' +
            '<p class="text-secondary small mb-2">' + domain + '</p>' +
            '<p class="small mb-2">' +
            'SEO ' + scoreOrDash(site.seo_score) +
            ' &middot; Perf ' + scoreOrDash(site.performance_score) +
            ' &middot; Sec ' + scoreOrDash(site.security_score) +
            ' &middot; A11y ' + scoreOrDash(site.accessibility_score) +
            '</p>' +
            '<a href="' + showUrl + '" class="btn btn-sm btn-outline-primary">View Details</a>' +
            '</div>'
        );
    }

    function initMap() {
        if (map || typeof L === 'undefined') {
            return;
        }

        map = L.map('discovery-map').setView([20, 0], 2);

        L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
            attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors',
            maxZoom: 18,
        }).addTo(map);
    }

    function loadMarkers() {
        if (markersLoaded || !map || !mapDataUrl) {
            return;
        }

        markersLoaded = true;

        fetch(mapDataUrl, { headers: { Accept: 'application/json' } })
            .then(function (response) {
                if (!response.ok) {
                    throw new Error('Map data request failed with ' + response.status);
                }
                return response.json();
            })
            .then(function (data) {
                var sites = data.websites || [];
                var bounds = [];

                sites.forEach(function (site) {
                    if (typeof site.lat !== 'number' || typeof site.lng !== 'number') {
                        return;
                    }

                    var marker = L.marker([site.lat, site.lng]).addTo(map);
                    marker.bindPopup(buildPopupHtml(site));
                    bounds.push([site.lat, site.lng]);
                });

                if (bounds.length > 0) {
                    map.fitBounds(bounds, { padding: [30, 30] });
                }
            })
            .catch(function () {
                // Silent failure: the map itself (base tiles) still works
                // even if markers fail to load — better than breaking the
                // whole view over one failed fetch.
                markersLoaded = false;
            });
    }

    function showList() {
        listSection.classList.remove('d-none');
        mapSection.classList.add('d-none');
        listViewButton.classList.add('active');
        mapViewButton.classList.remove('active');
    }

    function showMap() {
        listSection.classList.add('d-none');
        mapSection.classList.remove('d-none');
        mapViewButton.classList.add('active');
        listViewButton.classList.remove('active');

        initMap();
        loadMarkers();

        // Leaflet measures its container's size when the map is created;
        // if that container was display:none at the time (as it is here
        // until Map View is first opened), tiles render at the wrong size
        // until something tells Leaflet to re-measure.
        if (map) {
            window.setTimeout(function () {
                map.invalidateSize();
            }, 100);
        }
    }

    listViewButton.addEventListener('click', showList);
    mapViewButton.addEventListener('click', showMap);
})();