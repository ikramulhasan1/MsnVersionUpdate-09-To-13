/**
 * Minimal, framework-free app JS (per project rules: vanilla JS only).
 * Exposes a tiny AuditApp namespace so views can trigger shared UI behavior
 * without inline scripts scattered across templates.
 */
const AuditApp = (function () {
    'use strict';

    function showLoadingOverlay() {
        const overlay = document.getElementById('loading-overlay');
        if (overlay) {
            overlay.classList.remove('d-none');
        }
    }

    function hideLoadingOverlay() {
        const overlay = document.getElementById('loading-overlay');
        if (overlay) {
            overlay.classList.add('d-none');
        }
    }

    return {
        showLoadingOverlay: showLoadingOverlay,
        hideLoadingOverlay: hideLoadingOverlay,
    };
})();
