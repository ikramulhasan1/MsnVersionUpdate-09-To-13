/**
 * Phase N2 (Dynamic Notification System) — polls GET
 * notifications.recent (this script's own data-recent-url attribute,
 * set by layouts/app.blade.php) periodically and renders the result
 * into the sidebar's own bell dropdown
 * (resources/views/layouts/partials/sidebar.blade.php). Only ever
 * loaded for a logged-in visitor (see that layout's own @auth guard
 * around this script tag) — the dropdown this drives doesn't exist in
 * the DOM at all otherwise.
 *
 * Vanilla JS only, per project rules — no build step, no framework.
 */
(function () {
    'use strict';

    var script = document.currentScript;
    var recentUrl = script ? script.getAttribute('data-recent-url') : null;
    var badge = document.getElementById('app-notification-badge');
    var list = document.getElementById('app-notification-list');
    var bellToggle = document.getElementById('app-notification-bell-toggle');

    if (!recentUrl || !badge || !list || !bellToggle) {
        return;
    }

    var POLL_INTERVAL_MS = 30000;

    function escapeHtml(value) {
        var div = document.createElement('div');
        div.textContent = value == null ? '' : String(value);
        return div.innerHTML;
    }

    function renderNotifications(data) {
        if (data.unread_count > 0) {
            badge.textContent = data.unread_count > 99 ? '99+' : String(data.unread_count);
            badge.classList.remove('d-none');
        } else {
            badge.classList.add('d-none');
        }

        if (data.notifications.length === 0) {
            list.innerHTML = '<p class="text-secondary small text-center py-3 mb-0">No notifications yet.</p>';
            return;
        }

        var html = '';

        data.notifications.forEach(function (notification) {
            var itemClasses = 'app-notification-item' + (notification.read ? '' : ' unread');
            var href = notification.url ? notification.url : '#';

            html += ''
                + '<form method="POST" action="/notifications/' + encodeURIComponent(notification.id) + '/read">'
                + '<input type="hidden" name="_token" value="' + escapeHtml(getCsrfToken()) + '">'
                + '<button type="submit" class="' + itemClasses + '" style="width:100%;text-align:left;border:none;background:none;">'
                + '<div class="app-notification-item-title">' + escapeHtml(notification.title) + '</div>'
                + '<div class="app-notification-item-message">' + escapeHtml(notification.message) + '</div>'
                + '<div class="app-notification-item-time">' + escapeHtml(notification.created_at) + '</div>'
                + '</button>'
                + '</form>';
        });

        list.innerHTML = html;
    }

    function getCsrfToken() {
        var meta = document.querySelector('meta[name="csrf-token"]');

        if (meta) {
            return meta.getAttribute('content') || '';
        }

        // Fallback — this app's own layout doesn't currently render a
        // <meta name="csrf-token">, so the hidden CSRF input already
        // present on any nearby @csrf-rendered form is reused instead.
        var input = document.querySelector('input[name="_token"]');

        return input ? input.value : '';
    }

    function poll() {
        fetch(recentUrl, { headers: { Accept: 'application/json' } })
            .then(function (response) {
                if (!response.ok) {
                    throw new Error('notifications.recent request failed');
                }
                return response.json();
            })
            .then(renderNotifications)
            .catch(function () {
                // A transient network hiccup shouldn't stop future polls
                // — silently retry on the next interval rather than
                // leaving the dropdown stuck on "Loading…" forever.
            });
    }

    poll();
    window.setInterval(poll, POLL_INTERVAL_MS);

    // Also refresh right when the dropdown is opened — the 30s poll
    // interval alone could mean stale data for up to that long if
    // someone opens it right after a poll just ran.
    bellToggle.addEventListener('click', poll);
})();