
<?php echo $__env->make('audit.partials.dashboard', [
    'audit' => $audit,
    'overallScore' => $overallScore,
    'categories' => $categories,
    'generatedAt' => $generatedAt,
], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<?php echo $__env->make('audit.partials.dashboard-components', [
    'categories' => $categories,
], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>


<?php if($prospectQualification): ?>
    <?php
        // Phase M6 — audit_score_variant()'s own thresholds (90/70/50)
        // assume a /100 input; a partial result's raw ->score can be a
        // small number purely because maxPossibleScore is small (e.g.
        // 18/40), which would misleadingly read as "danger" red even
        // though 18/40 = 45% is a reasonably strong partial signal.
        // Normalizing onto a /100 scale first keeps the badge color
        // meaningful regardless of how much data was actually
        // available.
        $normalizedQualificationScore = $prospectQualification->maxPossibleScore > 0
            ? (int) round(($prospectQualification->score / $prospectQualification->maxPossibleScore) * 100)
            : 0;
        $qualificationVariant = audit_score_variant($normalizedQualificationScore);
        $bucketMaxPoints = [
            'website_issues' => 60,
            'business_signals' => 25,
            'technology_upgrade_opportunities' => 15,
        ];
    ?>
    <section class="mt-4">
        <div class="card">
            <div class="card-body p-4">
                <div class="d-flex flex-wrap align-items-center justify-content-between gap-2 mb-3">
                    <h2 class="h5 mb-0">Prospect Qualification</h2>
                    <div class="d-flex align-items-center gap-3">
                        <span
                            class="badge bg-<?php echo e($qualificationVariant); ?>-subtle text-<?php echo e($qualificationVariant); ?>-emphasis">
                            <?php echo e($prospectQualification->priority()); ?> priority
                        </span>
                        <span
                            class="badge bg-<?php echo e($qualificationVariant); ?>-subtle text-<?php echo e($qualificationVariant); ?>-emphasis">
                            <?php echo e($prospectQualification->score); ?>/<?php echo e($prospectQualification->maxPossibleScore); ?>

                        </span>
                        <?php if($prospectQualification->grade): ?>
                            <span class="grade-seal"
                                style="color: <?php echo e(audit_score_color_var($prospectQualification->score)); ?>;">
                                <?php echo e($prospectQualification->grade); ?>

                            </span>
                        <?php endif; ?>
                    </div>
                </div>

                
                <?php if($prospectQualification->isPartial): ?>
                    <div class="alert alert-warning py-2 px-3 small mb-3">
                        Partial data — not every scoring input was available for this audit (see the "N/A"
                        row(s) below), so this score is out of
                        <?php echo e($prospectQualification->maxPossibleScore); ?>, not the full 100, and no letter grade
                        is shown.
                    </div>
                <?php endif; ?>

                <p class="text-secondary"><?php echo e($prospectQualification->summary); ?></p>

                <ul class="list-group list-group-flush mb-0">
                    <?php $__currentLoopData = $prospectQualification->breakdown; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bucket => $points): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                            $bucketAvailable = $prospectQualification->availableBuckets[$bucket] ?? true;
                            $bucketMax = $bucketMaxPoints[$bucket] ?? max($points, 1);
                            $bucketPct = $bucketAvailable && $bucketMax > 0 ? min(100, ($points / $bucketMax) * 100) : 0;
                            $bucketLabel = ucwords(str_replace('_', ' ', $bucket));
                        ?>
                        <li class="list-group-item d-flex flex-column gap-1 px-0 py-2">
                            <div class="d-flex align-items-center justify-content-between">
                                <span class="fw-medium small"><?php echo e($bucketLabel); ?></span>
                                <?php if($bucketAvailable): ?>
                                    <span class="text-secondary small font-mono"><?php echo e($points); ?>

                                        / <?php echo e($bucketMax); ?> pts</span>
                                <?php else: ?>
                                    <span class="text-secondary small font-mono">N/A — no data</span>
                                <?php endif; ?>
                            </div>
                            <div class="progress progress-thin" role="progressbar"
                                aria-label="<?php echo e($bucketLabel); ?> points" aria-valuenow="<?php echo e($points); ?>"
                                aria-valuemin="0" aria-valuemax="<?php echo e($bucketMax); ?>">
                                <div class="progress-bar <?php echo e($bucketAvailable ? 'bg-'.$qualificationVariant : 'bg-secondary'); ?>"
                                    style="width: <?php echo e($bucketAvailable ? $bucketPct : 100); ?>%; <?php echo e($bucketAvailable ? '' : 'opacity: 0.25;'); ?>">
                                </div>
                            </div>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        </div>
    </section>
<?php endif; ?>

<?php if($outreachDraft): ?>
    <section class="mt-4">
        <div class="card outreach-card">
            <div
                class="outreach-card-header d-flex flex-wrap align-items-center justify-content-between gap-2 px-4 py-3">
                <div class="d-flex align-items-center gap-2">
                    <h2 class="h5 mb-0">Outreach Draft</h2>
                    <span class="badge bg-secondary-subtle text-secondary-emphasis">
                        Draft — for human review, never sent automatically
                    </span>
                </div>
                <button type="button" class="btn btn-sm btn-outline-secondary outreach-copy-btn"
                    data-outreach-subject="<?php echo e($outreachDraft->subject); ?>"
                    data-outreach-body="<?php echo e($outreachDraft->body); ?>">
                    <svg width="13" height="13" viewBox="0 0 16 16" fill="none" aria-hidden="true"
                        class="me-1">
                        <rect x="5.5" y="5.5" width="8.5" height="8.5" rx="1.3" stroke="currentColor"
                            stroke-width="1.3" />
                        <path
                            d="M10.5 5.5V3.8A1.3 1.3 0 0 0 9.2 2.5H3.3A1.3 1.3 0 0 0 2 3.8v6a1.3 1.3 0 0 0 1.3 1.3H5.5"
                            stroke="currentColor" stroke-width="1.3" />
                    </svg>
                    <span class="outreach-copy-label">Copy</span>
                </button>
            </div>

            <div class="outreach-card-subject-row px-4 py-2">
                <span class="outreach-card-field-label">Subject</span>
                <span class="outreach-card-field-value"><?php echo e($outreachDraft->subject); ?></span>
            </div>

            <div class="card-body p-4">
                <pre class="outreach-draft-body mb-3"><?php echo e($outreachDraft->body); ?></pre>

                <?php if(!empty($outreachDraft->basedOnIssues)): ?>
                    <p class="text-secondary small mb-1">Based on:</p>
                    <ul class="mb-0 ps-3">
                        <?php $__currentLoopData = $outreachDraft->basedOnIssues; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $issue): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="small mb-1"><?php echo e($issue); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                <?php endif; ?>
            </div>
        </div>
    </section>
<?php endif; ?><?php /**PATH D:\laragon\www\MsnVersionUpdate-09-To-13\analytics\resources\views\audit\partials\full-report.blade.php ENDPATH**/ ?>