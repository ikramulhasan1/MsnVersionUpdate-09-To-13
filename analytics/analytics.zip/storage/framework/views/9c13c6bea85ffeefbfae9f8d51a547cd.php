


<?php $__env->startSection('title', 'Watchlist'); ?>

<?php $__env->startSection('content'); ?>
    <section class="container dashboard-section">
        <div class="d-flex flex-wrap align-items-center justify-content-between gap-3 mb-4">
            <div>
                <p class="text-secondary small mb-1">Discover</p>
                <h1 class="h3 mb-0">Watchlist</h1>
            </div>
            <a href="<?php echo e(route('discovery.index')); ?>" class="btn btn-outline-secondary btn-sm">
                Back to Search
            </a>
        </div>

        <?php if(session('status')): ?>
            <div class="alert alert-success"><?php echo e(session('status')); ?></div>
        <?php endif; ?>

        <?php if($items->isEmpty()): ?>
            <div class="discovery-placeholder">
                <p class="mb-0">
                    No saved websites yet. Use the ⭐ Save button on a result card or a website's detail page to
                    add one.
                </p>
            </div>
        <?php else: ?>
            <div class="row row-cols-1 row-cols-lg-3 g-3">
                <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if(! $item->discoveredWebsite) continue; ?>
                    <div class="col">
                        <?php echo $__env->make('discovery.partials.result-card', [
                            'website' => $item->discoveredWebsite,
                            'isWatched' => true,
                        ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        <?php endif; ?>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\laragon\www\MsnVersionUpdate-09-To-13\analytics\resources\views\discovery\watchlist.blade.php ENDPATH**/ ?>