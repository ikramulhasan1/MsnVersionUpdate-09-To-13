

<?php $__env->startSection('title', 'Notifications — Website Audit & Analysis Platform'); ?>

<?php $__env->startSection('content'); ?>
    <section class="container py-4" style="max-width: 720px;">
        <div class="d-flex align-items-center justify-content-between mb-4">
            <h1 class="h4 fw-semibold mb-0">Notifications</h1>

            <?php if($notifications->getCollection()->contains(fn ($n) => $n->read_at === null)): ?>
                <form method="POST" action="<?php echo e(route('notifications.read-all')); ?>">
                    <?php echo csrf_field(); ?>
                    <button type="submit" class="btn btn-sm btn-outline-secondary">Mark all read</button>
                </form>
            <?php endif; ?>
        </div>

        <?php if($notifications->isEmpty()): ?>
            <div class="card">
                <div class="card-body p-4 text-center text-secondary">
                    You don't have any notifications yet.
                </div>
            </div>
        <?php else: ?>
            <div class="card">
                <ul class="list-group list-group-flush">
                    <?php $__currentLoopData = $notifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="list-group-item d-flex align-items-start justify-content-between gap-3 p-3
                            <?php echo e($notification->read_at === null ? 'app-notification-item unread' : ''); ?>">
                            <div class="flex-grow-1">
                                <?php if($notification->data['url'] ?? null): ?>
                                    <a href="<?php echo e($notification->data['url']); ?>" class="text-decoration-none d-block">
                                        <div class="fw-semibold small"><?php echo e($notification->data['title'] ?? 'Notification'); ?></div>
                                        <div class="small text-secondary"><?php echo e($notification->data['message'] ?? ''); ?></div>
                                    </a>
                                <?php else: ?>
                                    <div class="fw-semibold small"><?php echo e($notification->data['title'] ?? 'Notification'); ?></div>
                                    <div class="small text-secondary"><?php echo e($notification->data['message'] ?? ''); ?></div>
                                <?php endif; ?>
                                <div class="small text-secondary mt-1" style="font-size: 0.75rem;">
                                    <?php echo e($notification->created_at?->diffForHumans()); ?>

                                </div>
                            </div>

                            <div class="d-flex align-items-center gap-2 flex-shrink-0">
                                <?php if($notification->read_at === null): ?>
                                    <form method="POST" action="<?php echo e(route('notifications.read', $notification->id)); ?>">
                                        <?php echo csrf_field(); ?>
                                        <button type="submit" class="btn btn-sm btn-outline-secondary">Mark read</button>
                                    </form>
                                <?php endif; ?>
                                <form method="POST" action="<?php echo e(route('notifications.destroy', $notification->id)); ?>"
                                    onsubmit="return confirm('Delete this notification?');">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="btn btn-sm btn-outline-danger">Delete</button>
                                </form>
                            </div>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>

            <div class="mt-4">
                <?php echo e($notifications->links()); ?>

            </div>
        <?php endif; ?>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\laragon\www\MsnVersionUpdate-09-To-13\analytics\resources\views\notifications\index.blade.php ENDPATH**/ ?>