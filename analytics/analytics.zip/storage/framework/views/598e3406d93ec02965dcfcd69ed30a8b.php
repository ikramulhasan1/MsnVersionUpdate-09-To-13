

<?php $__env->startSection('title', ($plan->exists ? 'Edit Plan — ' . $plan->name : 'New Plan') . ' — Admin'); ?>

<?php $__env->startSection('content'); ?>
    <section class="container py-4" style="max-width: 680px;">
        <p class="text-secondary small mb-1">Admin</p>
        <h1 class="h4 fw-semibold mb-4"><?php echo e($plan->exists ? 'Edit ' . $plan->name : 'New Plan'); ?></h1>

        <form method="POST"
            action="<?php echo e($plan->exists ? route('admin.plans.update', $plan) : route('admin.plans.store')); ?>">
            <?php echo csrf_field(); ?>
            <?php if($plan->exists): ?>
                <?php echo method_field('PUT'); ?>
            <?php endif; ?>

            <div class="card mb-4">
                <div class="card-body p-4">
                    <div class="mb-3">
                        <label for="name" class="form-label">Plan Name</label>
                        <input type="text" class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="name"
                            name="name" value="<?php echo e(old('name', $plan->name)); ?>" required>
                        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="mb-3">
                        <label for="slug" class="form-label">
                            Slug <span class="text-secondary small">(auto-generated from name if left blank)</span>
                        </label>
                        <input type="text" class="form-control <?php $__errorArgs = ['slug'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="slug"
                            name="slug" value="<?php echo e(old('slug', $plan->slug)); ?>">
                        <?php $__errorArgs = ['slug'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="mb-3">
                        <label for="description" class="form-label">Description</label>
                        <textarea class="form-control" id="description" name="description" rows="2"><?php echo e(old('description', $plan->description)); ?></textarea>
                    </div>

                    <div class="row g-3 mb-3">
                        <div class="col-6">
                            <label for="price_dollars" class="form-label">Price (USD)</label>
                            <input type="number" step="0.01" min="0"
                                class="form-control <?php $__errorArgs = ['price_dollars'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="price_dollars"
                                name="price_dollars"
                                value="<?php echo e(old('price_dollars', $plan->exists ? number_format($plan->price_cents / 100, 2, '.', '') : '0.00')); ?>"
                                required>
                            <?php $__errorArgs = ['price_dollars'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="col-6">
                            <label for="billing_cycle" class="form-label">Billing Cycle</label>
                            <select class="form-select" id="billing_cycle" name="billing_cycle">
                                <option value="" <?php if(old('billing_cycle', $plan->billing_cycle) === null): echo 'selected'; endif; ?>>
                                    One-time / Free
                                </option>
                                <option value="month" <?php if(old('billing_cycle', $plan->billing_cycle) === 'month'): echo 'selected'; endif; ?>>
                                    Monthly
                                </option>
                                <option value="year" <?php if(old('billing_cycle', $plan->billing_cycle) === 'year'): echo 'selected'; endif; ?>>
                                    Yearly
                                </option>
                            </select>
                        </div>
                    </div>

                    <div class="row g-3 mb-3">
                        <div class="col-6">
                            <label for="duration_days" class="form-label">
                                Expires After (days) <span class="text-secondary small">(blank = never expires)</span>
                            </label>
                            <input type="number" min="1" class="form-control" id="duration_days"
                                name="duration_days" value="<?php echo e(old('duration_days', $plan->duration_days)); ?>">
                        </div>
                        <div class="col-6">
                            <label for="sort_order" class="form-label">Display Order</label>
                            <input type="number" min="0" class="form-control" id="sort_order" name="sort_order"
                                value="<?php echo e(old('sort_order', $plan->sort_order ?? 0)); ?>">
                        </div>
                    </div>

                    <div class="form-check mb-2">
                        <input class="form-check-input" type="checkbox" id="is_public" name="is_public" value="1"
                            <?php if(old('is_public', $plan->is_public ?? true)): echo 'checked'; endif; ?>>
                        <label class="form-check-label" for="is_public">
                            Show on public homepage pricing section
                        </label>
                    </div>

                    <div class="form-check">
                        <input class="form-check-input" type="checkbox" id="is_default_trial"
                            name="is_default_trial" value="1"
                            <?php if(old('is_default_trial', $plan->is_default_trial ?? false)): echo 'checked'; endif; ?>>
                        <label class="form-check-label" for="is_default_trial">
                            Auto-assign to every new registration (only one plan should have this checked)
                        </label>
                    </div>
                </div>
            </div>

            <div class="card mb-4">
                <div class="card-body p-4">
                    <h2 class="h6 fw-semibold mb-3">Features</h2>

                    <?php $__currentLoopData = $featureToggles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="form-check mb-2">
                            <input class="form-check-input" type="checkbox" name="features[]"
                                id="feature-<?php echo e($key); ?>" value="<?php echo e($key); ?>"
                                <?php if(in_array($key, old('features', $plan->exists ? array_keys(array_filter($plan->features ?? [], fn ($v, $k) => is_bool($v) && $v, ARRAY_FILTER_USE_BOTH)) : []), true)): echo 'checked'; endif; ?>>
                            <label class="form-check-label" for="feature-<?php echo e($key); ?>"><?php echo e($label); ?></label>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    <div class="mt-3">
                        <label for="daily_audit_limit" class="form-label">
                            Daily Audit Limit <span class="text-secondary small">(blank = unlimited)</span>
                        </label>
                        <input type="number" min="1" class="form-control" id="daily_audit_limit"
                            name="daily_audit_limit"
                            value="<?php echo e(old('daily_audit_limit', $plan->features['daily_audit_limit'] ?? null)); ?>"
                            style="max-width: 200px;">
                    </div>
                </div>
            </div>

            <div class="d-flex gap-2">
                <button type="submit" class="btn btn-primary"><?php echo e($plan->exists ? 'Save Changes' : 'Create Plan'); ?></button>
                <a href="<?php echo e(route('admin.plans.index')); ?>" class="btn btn-outline-secondary">Cancel</a>
            </div>
        </form>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\laragon\www\MsnVersionUpdate-09-To-13\analytics\resources\views\admin\plans\form.blade.php ENDPATH**/ ?>