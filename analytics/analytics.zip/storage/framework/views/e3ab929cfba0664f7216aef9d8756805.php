
<div class="card" id="discovery-search-panel-card" data-sub-niches-url="<?php echo e(route('discovery.sub-niches')); ?>"
    data-regions-url="<?php echo e(route('discovery.regions')); ?>" data-cities-url="<?php echo e(route('discovery.cities')); ?>"
    data-searches-store-url="<?php echo e(route('discovery.searches.store')); ?>">
    <div class="card-body p-4">
        <form method="POST" action="<?php echo e(route('discovery.search')); ?>" id="discovery-search-form">
            <?php echo csrf_field(); ?>

            <div class="row g-3">
                <div class="col-12 col-md-6 col-lg-3">
                    <label for="discovery-industry" class="form-label small fw-medium">Industry</label>
                    
                    <select class="form-select" id="discovery-industry" name="industry">
                        <option value="">Any industry</option>
                        <?php $__currentLoopData = $industries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $industry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php($industryCount = $industryCounts[$industry] ?? 0)
                            <option value="{{ $industry }}" @selected(($filters['industry'] ?? '') === $industry)
                                @disabled($industryCount === 0)>
                                {{ $industry }} ({{ $industryCount }})
                            </option>
                        @endforeach
                    </select>
                </div>

                <div class="col-12 col-md-6 col-lg-3">
                    <label for="discovery-sub-niche" class="form-label small fw-medium">Sub-Niche</label>
                    <select class="form-select" id="discovery-sub-niche" name="sub_niche"
                        data-selected="{{ $filters['sub_niche'] ?? '' }}" @disabled(empty($filters['industry']))>
                        <option value="">
                            {{ empty($filters['industry']) ? 'Choose an industry first' : 'Any sub-niche' }}
                        </option>
                    </select>
                </div>

                <div class="col-12 col-md-6 col-lg-3">
                    <label for="discovery-country" class="form-label small fw-medium">Country</label>
                    {{-- Same "(N)" count + disabled-when-zero treatment as Industry
                         above — see WebsiteSearchService::countsByCountry()'s own
                         docblock. Also doubles as a real diagnostic: if EVERY
                         country here shows (0) despite discovered_websites clearly
                         having rows, that's a strong sign this dropdown's own
                         $country['code'] values (ISO 3166-1 alpha-2, from
                         GeoLookupServiceInterface::countries()) don't actually match
                         whatever raw value discovered_websites.country is storing
                         for real rows — worth checking directly against the table's
                         own data if that happens. --}}
                    <select class="form-select" id="discovery-country" name="country">
                        <option value="">Any country</option>
                        @foreach ($countries as $country)
                            @php($countryCount = $countryCounts[$country['code']] ?? 0)
                            <option value="{{ $country['code'] }}" @selected(($filters['country'] ?? '') === $country['code'])
                                @disabled($countryCount === 0)>
                                {{ $country['name'] }} ({{ $countryCount }})
                            </option>
                        @endforeach
                    </select>
                </div>

                <div class="col-12 col-md-6 col-lg-3">
                    <label for="discovery-region" class="form-label small fw-medium">Region</label>
                    <select class="form-select" id="discovery-region" name="region"
                        data-selected="{{ $filters['region'] ?? '' }}" @disabled(empty($filters['country']))>
                        <option value="">
                            {{ empty($filters['country']) ? 'Choose a country first' : 'Any region' }}
                        </option>
                    </select>
                </div>

                <div class="col-12 col-md-6 col-lg-3">
                    <label for="discovery-city" class="form-label small fw-medium">City</label>
                    <select class="form-select" id="discovery-city" name="city"
                        data-selected="{{ $filters['city'] ?? '' }}" @disabled(empty($filters['country']))>
                        <option value="">
                            {{ empty($filters['country']) ? 'Choose a country first' : 'Any city' }}
                        </option>
                    </select>
                </div>

                <div class="col-12 col-md-6 col-lg-3">
                    <label for="discovery-radius" class="form-label small fw-medium">Radius (miles)</label>
                    <input type="number" class="form-control" id="discovery-radius" name="radius" min="0"
                        step="1" value="{{ $filters['radius'] ?? '' }}" placeholder="e.g. 25">
                </div>

                {{-- Feature request: filter by WHEN this module found a site
                     (discovered_at), separate from the Advanced Filters accordion's
                     own "Last Updated" bucket (last_updated_at — a SITE's own content
                     freshness, not when this module found it). Plain <input type="date">
                     rather than a bucketed <select> like Last Updated, since a specific
                     from/to range is exactly what "discovered date" means as a request,
                     unlike Last Updated's own deliberately coarse buckets — see
                     WebsiteSearchService::applyDiscoveredDateRange()'s own docblock. --}}
                <div class="col-12 col-md-6 col-lg-3">
                    <label for="discovery-discovered-from" class="form-label small fw-medium">
                        Discovered From
                    </label>
                    <input type="date" class="form-control" id="discovery-discovered-from" name="discovered_from"
                        value="{{ $filters['discovered_from'] ?? '' }}">
                </div>

                <div class="col-12 col-md-6 col-lg-3">
                    <label for="discovery-discovered-to" class="form-label small fw-medium">
                        Discovered To
                    </label>
                    <input type="date" class="form-control" id="discovery-discovered-to" name="discovered_to"
                        value="{{ $filters['discovered_to'] ?? '' }}">
                </div>

                <div class="col-12 col-lg-3 d-flex align-items-end gap-2">
                    <button type="submit" class="btn btn-primary flex-grow-1">Search</button>
                    <button type="button" class="btn btn-outline-secondary flex-shrink-0"
                        id="discovery-save-search-btn" title="Save this search">
                        Save
                    </button>
                </div>

                <div class="col-12 col-lg-3 d-flex align-items-end">
                    {{-- formaction submits this SAME form (same filters) to a different
                         route than the form's own action="" — see search-panel.blade.php's
                         own docblock (Phase J1) and public/js/discovery-search-panel.js's
                         confirm()-before-submit handler for this button. --}}
                    <button type="submit" formaction="{{ route('discovery.discover') }}"
                        class="btn btn-outline-primary w-100" id="discovery-discover-btn"
                        title="Queue a search of Google Places and Yelp (and any other connected source) for new websites matching these filters">
                        Discover More
                    </button>
                </div>
            </div>

            <p class="text-secondary small mt-2 mb-0">
                "Search" looks through websites this module already knows about. "Discover More" queues a
                background check (via Google Places, Yelp, and any other connected source) for brand new
                ones matching these same filters. The page reloads right away, but it can take a minute or
                two before any new results actually appear — refresh again after a couple of minutes.
            </p>

            {{-- Filled in by JS (public/js/discovery-search-panel.js's "Save this search"
                 handler, Phase F3) before the form is submitted to searches.store. --}}
            <input type="hidden" name="name" id="discovery-save-search-name">

            {{-- Advanced Filters — Website Status / Website Type checkboxes (Phase C1).
                 Reuses the exact accordion markup dashboard-components.blade.php's
                 "Detailed Results" accordion already established (see this
                 file's own docblock), collapsed by default. --}}
            <div class="accordion mt-3" id="discovery-advanced-filters-accordion">
                <div class="accordion-item">
                    <h2 class="accordion-header" id="discovery-advanced-filters-heading">
                        <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
                            data-bs-target="#discovery-advanced-filters-collapse" aria-expanded="false"
                            aria-controls="discovery-advanced-filters-collapse">
                            Advanced Filters
                        </button>
                    </h2>
                    <div id="discovery-advanced-filters-collapse" class="accordion-collapse collapse"
                        aria-labelledby="discovery-advanced-filters-heading">
                        <div class="accordion-body">
                            <p class="fw-medium mb-1">Boolean Query <span
                                    class="text-secondary small fw-normal">(Advanced)</span></p>
                            <p class="text-secondary small mb-2">
                                Combine terms with AND / OR / NOT — e.g.
                                <code>Restaurant AND WordPress AND NOT Facebook</code>. Evaluated left to right;
                                parentheses/grouping aren't supported yet. Use quotes for a multi-word term, e.g.
                                <code>"fine dining"</code>.
                            </p>
                            <input type="text" class="form-control mb-4" name="boolean_query"
                                id="discovery-boolean-query" value="{{ $filters['boolean_query'] ?? '' }}"
                                placeholder="e.g. Restaurant AND WordPress AND NOT Facebook" maxlength="500">

                            <div class="row g-4">
                                <div class="col-12 col-md-6">
                                    <p class="form-label small fw-medium mb-2">Website Status</p>
                                    @foreach ($websiteStatuses as $status)
                                        <div class="form-check">
                                            <input class="form-check-input" type="checkbox" name="status[]"
                                                id="discovery-status-{{ $status->value }}"
                                                value="{{ $status->value }}" @checked(in_array($status->value, (array) ($filters['status'] ?? []), true))>
                                            <label class="form-check-label"
                                                for="discovery-status-{{ $status->value }}">
                                                {{ $status->label() }}
                                            </label>
                                        </div>
                                    @endforeach
                                </div>

                                <div class="col-12 col-md-6">
                                    <p class="form-label small fw-medium mb-2">Website Type</p>
                                    @foreach ($websiteTypes as $type)
                                        <div class="form-check">
                                            <input class="form-check-input" type="checkbox" name="website_type[]"
                                                id="discovery-type-{{ $type->value }}" value="{{ $type->value }}"
                                                @checked(in_array($type->value, (array) ($filters['website_type'] ?? []), true))>
                                            <label class="form-check-label" for="discovery-type-{{ $type->value }}">
                                                {{ $type->label() }}
                                            </label>
                                        </div>
                                    @endforeach
                                </div>
                            </div>

                            <hr class="my-4" style="border-color: var(--audit-border);">

                            <p class="fw-medium mb-3">Technology</p>
                            <div class="row g-4">
                                @foreach ($technologyGroups as $group => $options)
                                    <div class="col-12 col-sm-6 col-lg-4">
                                        <p class="form-label small fw-medium mb-2">
                                            {{ match ($group) {
                                                'cms' => 'CMS',
                                                'framework' => 'Framework',
                                                'ecommerce_platform' => 'E-commerce Platform',
                                                'cdn' => 'CDN',
                                                default => ucfirst($group),
                                            } }}
                                        </p>
                                        @forelse ($options as $option)
                                            <div class="form-check">
                                                <input class="form-check-input" type="checkbox"
                                                    name="technology[{{ $group }}][]"
                                                    id="discovery-tech-{{ $group }}-{{ $option['slug'] }}"
                                                    value="{{ $option['slug'] }}" @checked(in_array($option['slug'], (array) ($filters['technology'][$group] ?? []), true))>
                                                <label class="form-check-label"
                                                    for="discovery-tech-{{ $group }}-{{ $option['slug'] }}">
                                                    {{ $option['name'] }}
                                                </label>
                                            </div>
                                        @empty
                                            <p class="text-secondary small mb-0">None detected yet.</p>
                                        @endforelse
                                    </div>
                                @endforeach

                                <div class="col-12 col-sm-6 col-lg-4">
                                    <p class="form-label small fw-medium mb-2">Server</p>
                                    @foreach ($serverSoftware as $server)
                                        <div class="form-check">
                                            <input class="form-check-input" type="checkbox"
                                                name="technology[server][]"
                                                id="discovery-tech-server-{{ $server->value }}"
                                                value="{{ $server->value }}" @checked(in_array($server->value, (array) ($filters['technology']['server'] ?? []), true))>
                                            <label class="form-check-label"
                                                for="discovery-tech-server-{{ $server->value }}">
                                                {{ $server->label() }}
                                            </label>
                                        </div>
                                    @endforeach
                                </div>
                            </div>

                            <hr class="my-4" style="border-color: var(--audit-border);">

                            <p class="fw-medium mb-3">Website Quality</p>
                            <div class="row g-4 mb-2">
                                
                                                                @php
                                    $qualityGroups = [
                                        'seo' => 'SEO',
                                        'performance' => 'Performance',
                                        'security' => 'Security',
                                        'accessibility' => 'Accessibility',
                                    ];
                                ?>

                                <?php $__currentLoopData = $qualityGroups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $qualityKey => $qualityName): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php
                                        $qualityMin = $filters['quality'][$qualityKey]['min'] ?? 0;
                                        $qualityMax = $filters['quality'][$qualityKey]['max'] ?? 100;
                                    ?>

                                    <div class="col-12 col-md-6 col-lg-3">
                                        <div class="d-flex justify-content-between align-items-center mb-1">
                                            <label class="form-label small fw-medium mb-0">
                                                <?php echo e($qualityName); ?> Score
                                            </label>

                                            <span class="small text-secondary font-mono">
                                                <span data-range-min-label><?php echo e($qualityMin); ?></span>&ndash;<span
                                                    data-range-max-label><?php echo e($qualityMax); ?></span>
                                            </span>
                                        </div>

                                        <div class="discovery-range-slider" data-range-slider>
                                            <input type="range"
                                                class="discovery-range-input"
                                                min="0"
                                                max="100"
                                                step="1"
                                                name="quality[<?php echo e($qualityKey); ?>][min]"
                                                value="<?php echo e($qualityMin); ?>"
                                                data-range-role="min">

                                            <input type="range"
                                                class="discovery-range-input"
                                                min="0"
                                                max="100"
                                                step="1"
                                                name="quality[<?php echo e($qualityKey); ?>][max]"
                                                value="<?php echo e($qualityMax); ?>"
                                                data-range-role="max">
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>

                            <div class="row g-4">
                                <div class="col-12 col-md-6">
                                    <p class="form-label small fw-medium mb-2">SEO Issues</p>
                                    <div class="discovery-checkbox-scroll">
                                        <?php $__currentLoopData = $seoIssues; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $issue): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="form-check">
                                                <input class="form-check-input" type="checkbox" name="issue[seo][]"
                                                    id="discovery-issue-seo-<?php echo e($issue['code']); ?>"
                                                    value="<?php echo e($issue['code']); ?>" <?php if(in_array($issue['code'], (array) ($filters['issue']['seo'] ?? []), true)): echo 'checked'; endif; ?>>
                                                <label class="form-check-label"
                                                    for="discovery-issue-seo-<?php echo e($issue['code']); ?>">
                                                    <?php echo e($issue['label']); ?>

                                                </label>
                                            </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                </div>

                                <div class="col-12 col-md-6">
                                    <p class="form-label small fw-medium mb-2">Security Issues</p>
                                    <div class="discovery-checkbox-scroll">
                                        <?php $__currentLoopData = $securityIssues; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $issue): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="form-check">
                                                <input class="form-check-input" type="checkbox"
                                                    name="issue[security][]"
                                                    id="discovery-issue-security-<?php echo e($issue['code']); ?>"
                                                    value="<?php echo e($issue['code']); ?>" <?php if(in_array($issue['code'], (array) ($filters['issue']['security'] ?? []), true)): echo 'checked'; endif; ?>>
                                                <label class="form-check-label"
                                                    for="discovery-issue-security-<?php echo e($issue['code']); ?>">
                                                    <?php echo e($issue['label']); ?>

                                                </label>
                                            </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                </div>
                            </div>

                            <hr class="my-4" style="border-color: var(--audit-border);">

                            <p class="fw-medium mb-3">Opportunity</p>
                            <div class="row g-2">
                                <?php $__currentLoopData = $opportunityFilters; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $opportunity): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="col-12 col-sm-6 col-lg-4">
                                        <div class="form-check">
                                            <input class="form-check-input" type="checkbox" name="opportunity[]"
                                                id="discovery-opportunity-<?php echo e($opportunity->value); ?>"
                                                value="<?php echo e($opportunity->value); ?>"
                                                title="<?php echo e($opportunity->criterion()); ?>" <?php if(in_array($opportunity->value, (array) ($filters['opportunity'] ?? []), true)): echo 'checked'; endif; ?>>
                                            <label class="form-check-label"
                                                for="discovery-opportunity-<?php echo e($opportunity->value); ?>"
                                                title="<?php echo e($opportunity->criterion()); ?>">
                                                <?php echo e($opportunity->label()); ?>

                                            </label>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>

                            <hr class="my-4" style="border-color: var(--audit-border);">

                            <p class="fw-medium mb-3">Age &amp; Size</p>
                            <div class="row g-4 mb-2">
                                <?php
                                    $domainAgeMin = $filters['domain_age']['min'] ?? 0;
                                    $domainAgeMax = $filters['domain_age']['max'] ?? 20;
                                    $employeesMin = $filters['employees']['min'] ?? 0;
                                    $employeesMax = $filters['employees']['max'] ?? 500;
                                ?>
                                <div class="col-12 col-md-6 col-lg-4">
                                    <div class="d-flex justify-content-between align-items-center mb-1">
                                        <label class="form-label small fw-medium mb-0">Domain Age (years)</label>
                                        <span class="small text-secondary font-mono">
                                            <span data-range-min-label><?php echo e($domainAgeMin); ?></span>&ndash;<span
                                                data-range-max-label><?php echo e($domainAgeMax); ?></span><?php echo e($domainAgeMax >= 20 ? '+' : ''); ?>

                                        </span>
                                    </div>
                                    <div class="discovery-range-slider" data-range-slider>
                                        <input type="range" class="discovery-range-input" min="0"
                                            max="20" step="1" name="domain_age[min]"
                                            value="<?php echo e($domainAgeMin); ?>" data-range-role="min">
                                        <input type="range" class="discovery-range-input" min="0"
                                            max="20" step="1" name="domain_age[max]"
                                            value="<?php echo e($domainAgeMax); ?>" data-range-role="max">
                                    </div>
                                </div>

                                <div class="col-12 col-md-6 col-lg-4">
                                    <div class="d-flex justify-content-between align-items-center mb-1">
                                        <label class="form-label small fw-medium mb-0">Employee Estimate</label>
                                        <span class="small text-secondary font-mono">
                                            <span data-range-min-label><?php echo e($employeesMin); ?></span>&ndash;<span
                                                data-range-max-label><?php echo e($employeesMax); ?></span><?php echo e($employeesMax >= 500 ? '+' : ''); ?>

                                        </span>
                                    </div>
                                    <div class="discovery-range-slider" data-range-slider>
                                        <input type="range" class="discovery-range-input" min="0"
                                            max="500" step="10" name="employees[min]"
                                            value="<?php echo e($employeesMin); ?>" data-range-role="min">
                                        <input type="range" class="discovery-range-input" min="0"
                                            max="500" step="10" name="employees[max]"
                                            value="<?php echo e($employeesMax); ?>" data-range-role="max">
                                    </div>
                                </div>

                                <div class="col-12 col-md-6 col-lg-4">
                                    <label for="discovery-last-updated" class="form-label small fw-medium">
                                        Last Updated
                                    </label>
                                    <select class="form-select" id="discovery-last-updated" name="last_updated">
                                        <option value="">Any time</option>
                                        <?php $__currentLoopData = $lastUpdatedRanges; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $range): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($range->value); ?>" <?php if(($filters['last_updated'] ?? '') === $range->value): echo 'selected'; endif; ?>>
                                                <?php echo e($range->label()); ?>

                                            </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>

                            <div class="row g-4">
                                <div class="col-12 col-md-6">
                                    <p class="form-label small fw-medium mb-2">Business Size</p>
                                    <?php $__currentLoopData = $businessSizes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $size): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="form-check">
                                            <input class="form-check-input" type="checkbox" name="business_size[]"
                                                id="discovery-business-size-<?php echo e($size->value); ?>"
                                                value="<?php echo e($size->value); ?>" <?php if(in_array($size->value, (array) ($filters['business_size'] ?? []), true)): echo 'checked'; endif; ?>>
                                            <label class="form-check-label"
                                                for="discovery-business-size-<?php echo e($size->value); ?>">
                                                <?php echo e($size->label()); ?>

                                            </label>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>

                                <div class="col-12 col-md-6">
                                    <p class="form-label small fw-medium mb-2">Est. Traffic</p>
                                    <?php $__currentLoopData = $trafficRanges; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $traffic): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="form-check">
                                            <input class="form-check-input" type="checkbox" name="traffic[]"
                                                id="discovery-traffic-<?php echo e($traffic->value); ?>"
                                                value="<?php echo e($traffic->value); ?>" <?php if(in_array($traffic->value, (array) ($filters['traffic'] ?? []), true)): echo 'checked'; endif; ?>>
                                            <label class="form-check-label"
                                                for="discovery-traffic-<?php echo e($traffic->value); ?>">
                                                <?php echo e($traffic->label()); ?>

                                            </label>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </div>

                            <hr class="my-4" style="border-color: var(--audit-border);">

                            <p class="fw-medium mb-3">Social Media</p>
                            <div class="row g-3">
                                <?php $__currentLoopData = $socialPlatforms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $platform): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="col-12 col-sm-6 col-lg-4">
                                        <label for="discovery-social-<?php echo e($platform->value); ?>"
                                            class="form-label small fw-medium mb-1">
                                            <?php echo e($platform->label()); ?>

                                        </label>
                                        <select class="form-select form-select-sm"
                                            id="discovery-social-<?php echo e($platform->value); ?>"
                                            name="social[<?php echo e($platform->value); ?>]">
                                            <option value="" <?php if(($filters['social'][$platform->value] ?? '') === ''): echo 'selected'; endif; ?>>
                                                Any
                                            </option>
                                            <option value="has" <?php if(($filters['social'][$platform->value] ?? '') === 'has'): echo 'selected'; endif; ?>>
                                                Has <?php echo e($platform->label()); ?>

                                            </option>
                                            <option value="missing" <?php if(($filters['social'][$platform->value] ?? '') === 'missing'): echo 'selected'; endif; ?>>
                                                Doesn't Have <?php echo e($platform->label()); ?>

                                            </option>
                                        </select>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>

                            <hr class="my-4" style="border-color: var(--audit-border);">

                            <p class="fw-medium mb-1">Contact Availability</p>
                            <p class="text-secondary small mb-3">
                                Narrows the results below, like most of the Advanced Filters groups above (see
                                the note at the bottom of this panel for the ones that don't yet).
                            </p>
                            <div class="row g-2">
                                <div class="col-12 col-sm-6 col-lg-3">
                                    <div class="form-check">
                                        <input class="form-check-input" type="radio" name="contact_availability"
                                            id="discovery-contact-any" value="" <?php if(empty($filters['contact_availability'])): echo 'checked'; endif; ?>>
                                        <label class="form-check-label" for="discovery-contact-any">Any</label>
                                    </div>
                                </div>
                                <?php $__currentLoopData = $contactAvailabilityOptions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="col-12 col-sm-6 col-lg-3">
                                        <div class="form-check">
                                            <input class="form-check-input" type="radio"
                                                name="contact_availability"
                                                id="discovery-contact-<?php echo e($option->value); ?>"
                                                value="<?php echo e($option->value); ?>" <?php if(($filters['contact_availability'] ?? '') === $option->value): echo 'checked'; endif; ?>>
                                            <label class="form-check-label"
                                                for="discovery-contact-<?php echo e($option->value); ?>">
                                                <?php echo e($option->label()); ?>

                                            </label>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <p class="text-secondary small mb-0 mt-3">
                Industry/Sub-Niche, Location, Website Type, Business Size, Technology, Website Quality score
                ranges, Domain Age, Last Updated, Est. Traffic, Social Media, Contact Availability, and the
                Boolean Query field all narrow the results below. Website Status, Opportunity, SEO/Security
                specific issues, Employee Estimate, and Radius are still UI-only for now — they submit and
                round-trip, but don't filter yet.
            </p>
        </form>
    </div>
</div>
<?php /**PATH D:\laragon\www\MsnVersionUpdate-09-To-13\analytics\resources\views\discovery\partials\search-panel.blade.php ENDPATH**/ ?>