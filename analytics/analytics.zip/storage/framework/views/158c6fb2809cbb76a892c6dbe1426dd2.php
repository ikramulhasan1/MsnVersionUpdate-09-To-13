


<?php $__env->startSection('title', 'Saved Searches'); ?>

<?php $__env->startSection('content'); ?>
    <section class="container dashboard-section">
        <div class="d-flex flex-wrap align-items-center justify-content-between gap-3 mb-4">
            <div>
                <p class="text-secondary small mb-1">Discover</p>
                <h1 class="h3 mb-0">Saved Searches</h1>
            </div>
            <a href="<?php echo e(route('discovery.index')); ?>" class="btn btn-outline-secondary btn-sm">
                Back to Search
            </a>
        </div>

        <?php if(session('status')): ?>
            <div class="alert alert-success"><?php echo e(session('status')); ?></div>
        <?php endif; ?>

        <?php if($searches->isEmpty()): ?>
            <div class="discovery-placeholder">
                <p class="mb-0">
                    No saved searches yet. Use "Save this search" on the search panel to create one.
                </p>
            </div>
        <?php else: ?>
            <div class="card">
                <ul class="list-group list-group-flush">
                    <?php $__currentLoopData = $searches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $search): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="list-group-item d-flex flex-wrap align-items-center justify-content-between gap-3">
                            <div>
                                <div class="d-flex align-items-center gap-2 flex-wrap">
                                    <p class="fw-medium mb-0"><?php echo e($search->name); ?></p>
                                    <?php if($search->is_scheduled): ?>
                                        <span class="badge bg-secondary-subtle text-secondary-emphasis">
                                            Auto-refresh on
                                        </span>
                                    <?php endif; ?>
                                    <?php if($search->new_results_count !== null && $search->new_results_count > 0): ?>
                                        <span class="badge bg-primary-subtle text-primary-emphasis">
                                            <?php echo e($search->new_results_count); ?>

                                            <?php echo e(\Illuminate\Support\Str::plural('New Website', $search->new_results_count)); ?>

                                            Found
                                        </span>
                                    <?php endif; ?>
                                </div>
                                <p class="text-secondary small mb-0">
                                    Saved <?php echo e($search->created_at?->diffForHumans()); ?>

                                    <?php if($search->last_run_at): ?>
                                        &middot; Last checked <?php echo e($search->last_run_at->diffForHumans()); ?>

                                    <?php endif; ?>
                                </p>
                            </div>
                            <div class="d-flex align-items-center gap-2">
                                <a href="<?php echo e(route('discovery.index', $search->filters)); ?>" class="btn btn-sm btn-primary">
                                    Run Search
                                </a>
                                <form method="POST" action="<?php echo e(route('discovery.searches.toggle-schedule', $search)); ?>">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('PATCH'); ?>
                                    <button type="submit" class="btn btn-sm btn-outline-secondary">
                                        <?php echo e($search->is_scheduled ? 'Disable' : 'Enable'); ?> Auto-Refresh
                                    </button>
                                </form>
                                <form method="POST" action="<?php echo e(route('discovery.searches.destroy', $search)); ?>">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="btn btn-sm btn-outline-secondary">Delete</button>
                                </form>
                            </div>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\laragon\www\MsnVersionUpdate-09-To-13\analytics\resources\views\discovery\saved.blade.php ENDPATH**/ ?>