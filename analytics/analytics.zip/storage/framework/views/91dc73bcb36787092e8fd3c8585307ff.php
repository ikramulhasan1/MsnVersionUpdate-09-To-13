
<ul class="nav nav-tabs mb-4">
    <li class="nav-item">
        <a class="nav-link <?php echo e(request()->routeIs('admin.users.*') ? 'active' : ''); ?>"
            href="<?php echo e(route('admin.users.index')); ?>">
            Users
        </a>
    </li>
    <li class="nav-item">
        <a class="nav-link <?php echo e(request()->routeIs('admin.plans.*') ? 'active' : ''); ?>"
            href="<?php echo e(route('admin.plans.index')); ?>">
            Pricing Plans
        </a>
    </li>
</ul><?php /**PATH D:\laragon\www\MsnVersionUpdate-09-To-13\analytics\resources\views\admin\partials\nav.blade.php ENDPATH**/ ?>