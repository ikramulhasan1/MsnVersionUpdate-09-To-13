
<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title><?php echo $__env->yieldContent('title', 'Website Audit Report'); ?></title>
    <style>
        /* A4 page with room at the bottom for the fixed page-number
           footer, and enough top margin that content never starts
           flush against the page edge. */
        @page {
            size: a4;
            margin: 30px 32px 55px 32px;
        }

        * {
            box-sizing: border-box;
        }

        body {
            margin: 0;
            font-family: 'DejaVu Sans', sans-serif;
            font-size: 11px;
            line-height: 1.5;
            color: #15181f;
        }

        h1,
        h2,
        h3 {
            font-family: 'DejaVu Sans', sans-serif;
            font-weight: bold;
            line-height: 1.3;
            margin: 0 0 8px;
            /* A heading is never left alone at the bottom of a page
               with its content pushed to the next one. */
            page-break-after: avoid;
        }

        p {
            margin: 0 0 8px;
        }

        /* Print-safety rules that apply to every table in the PDF,
           regardless of which partial renders it (Scores, Charts'
           severity legend, Recommendations, Summary):
           - table-layout: fixed + word-wrap keeps a long URL or issue
             description from ever overflowing the page width.
           - thead as its own table-row-group is what lets dompdf
             repeat column headers automatically on every page a table
             spans, so a reader never sees an unlabeled continuation.
           - tr { page-break-inside: avoid } keeps a single row from
             being split across two pages. */
        table {
            border-collapse: collapse;
            table-layout: fixed;
            width: 100%;
        }

        th,
        td {
            word-wrap: break-word;
            overflow-wrap: break-word;
        }

        thead {
            display: table-header-group;
        }

        tr {
            page-break-inside: avoid;
        }

        /* Fixed footer, repeated on every page. {PAGE_NUM} / {PAGE_COUNT}
           are dompdf's built-in page-numbering tokens — they only
           resolve inside a `position: fixed` element, which is also
           what makes this element repeat on every page rather than
           appearing once. */
        .pdf-footer {
            position: fixed;
            left: 0;
            right: 0;
            bottom: -40px;
            height: 24px;
            padding-top: 6px;
            border-top: 1px solid #e3e1d9;
            font-size: 9px;
            color: #5b6270;
        }

        .pdf-footer-left {
            display: inline-block;
            width: 70%;
        }

        .pdf-footer-right {
            display: inline-block;
            width: 30%;
            text-align: right;
        }

        <?php echo $__env->yieldPushContent('styles'); ?>
    </style>
</head>

<body>
    <div class="pdf-footer">
        <span class="pdf-footer-left"><?php echo e(config('app.name')); ?> &mdash; Website Audit Report</span>
        <span class="pdf-footer-right">Page {PAGE_NUM} of {PAGE_COUNT}</span>
    </div>

    <?php echo $__env->yieldContent('content'); ?>
</body>

</html>
<?php /**PATH D:\laragon\www\MsnVersionUpdate-09-To-13\analytics\resources\views\audit\pdf\layout.blade.php ENDPATH**/ ?>