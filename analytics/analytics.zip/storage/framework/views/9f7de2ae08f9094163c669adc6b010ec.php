


<?php $__env->startSection('title', $batch->name ?? 'Bulk Audit Batch'); ?>

<?php $__env->startSection('content'); ?>
    <section class="container dashboard-section" id="bulk-audit-page"
        data-bulk-audit-progress-url="<?php echo e(route('bulk-audits.progress', $batch)); ?>"
        data-bulk-audit-finished="<?php echo e($batch->status->value === 'completed' ? '1' : '0'); ?>">
        <?php if(session('status')): ?>
            <div class="alert alert-success"><?php echo e(session('status')); ?></div>
        <?php endif; ?>

        <div class="d-flex flex-wrap align-items-start justify-content-between gap-3 mb-4">
            <div>
                <p class="text-secondary small mb-1">Website Audit</p>
                <h1 class="h3 mb-0"><?php echo e($batch->name ?? 'Bulk Audit Batch'); ?></h1>
                <p class="text-secondary mt-2 mb-0">
                    <?php echo e($batch->total_count); ?> website(s) &mdash; <?php echo e($batch->mode->label()); ?>

                </p>
            </div>

            <div class="dropdown">
                <button class="btn btn-outline-secondary btn-sm dropdown-toggle" type="button"
                    data-bs-toggle="dropdown" aria-expanded="false">
                    Export
                </button>
                <ul class="dropdown-menu dropdown-menu-end">
                    <li>
                        <a class="dropdown-item" href="<?php echo e(route('bulk-audits.export', ['bulkAuditBatch' => $batch, 'format' => 'excel'])); ?>">
                            Excel (.xlsx)
                        </a>
                    </li>
                    <li>
                        <a class="dropdown-item" href="<?php echo e(route('bulk-audits.export', ['bulkAuditBatch' => $batch, 'format' => 'csv'])); ?>">
                            CSV
                        </a>
                    </li>
                    <li>
                        <a class="dropdown-item" href="<?php echo e(route('bulk-audits.export', ['bulkAuditBatch' => $batch, 'format' => 'json'])); ?>">
                            JSON
                        </a>
                    </li>
                </ul>
            </div>
        </div>

        
        <div class="card mb-4" id="bulk-audit-progress-card"
            style="<?php echo e($batch->status->value === 'completed' ? 'display: none;' : ''); ?>">
            <div class="card-body p-4">
                                <div class="d-flex justify-content-between align-items-center mb-2">
                    <span class="fw-medium" id="bulk-audit-progress-label">
                        <?php echo e($batch->status->label()); ?>

                    </span>
                    <span class="text-secondary small" id="bulk-audit-progress-count">
                        <?php echo e($batch->completed_count + $batch->failed_count); ?> of <?php echo e($batch->total_count); ?> finished
                    </span>
                </div>
                <div class="progress" role="progressbar" aria-valuemin="0" aria-valuemax="100"
                    aria-valuenow="<?php echo e($batch->progressPercent()); ?>">
                    <div class="progress-bar" id="bulk-audit-progress-bar"
                        style="width: <?php echo e($batch->progressPercent()); ?>%;"></div>
                </div>
                
                <p class="text-secondary small fw-medium mt-2 mb-0" id="bulk-audit-progress-eta">
                    Estimating time remaining&hellip;
                </p>
                <p class="text-secondary small mt-1 mb-0">
                    This page updates automatically — no need to refresh.
                </p>
            </div>
        </div>

        <div class="card">
            <div class="card-body p-0">
                <div class="table-responsive">
                    <table class="table table-hover mb-0" id="bulk-audit-results-table">
                        <thead>
                            <tr>
                                <th scope="col" data-sort-key="url">Website</th>
                                <th scope="col" data-sort-key="status">Status</th>
                                <th scope="col" data-sort-key="seo" class="text-end">SEO</th>
                                <th scope="col" data-sort-key="performance" class="text-end">Performance</th>
                                <th scope="col" data-sort-key="security" class="text-end">Security</th>
                                <th scope="col" data-sort-key="accessibility" class="text-end">Accessibility</th>
                                <th scope="col"></th>
                            </tr>
                        </thead>
                        <tbody id="bulk-audit-results-tbody">
                            <?php $__currentLoopData = $batch->audits; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $audit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                    $row = $rows->first(fn ($r) => $r->url === $audit->url);
                                ?>
                                <tr data-url="<?php echo e($audit->url); ?>" data-status="<?php echo e($audit->status->value); ?>"
                                    data-seo="<?php echo e($row->seoScore ?? -1); ?>"
                                    data-performance="<?php echo e($row->performanceScore ?? -1); ?>"
                                    data-security="<?php echo e($row->securityScore ?? -1); ?>"
                                    data-accessibility="<?php echo e($row->accessibilityScore ?? -1); ?>">
                                    <td>
                                        <a href="<?php echo e($audit->url); ?>" target="_blank" rel="noopener noreferrer"
                                            class="text-decoration-none">
                                            <?php echo e($audit->url); ?>

                                        </a>
                                    </td>
                                    <td>
                                        <?php if($audit->status->value === 'completed'): ?>
                                            <span class="badge bg-success">Completed</span>
                                        <?php elseif($audit->status->value === 'failed'): ?>
                                            <span class="badge bg-danger">Failed</span>
                                        <?php else: ?>
                                            <span class="badge bg-secondary"><?php echo e($audit->status->label()); ?></span>
                                        <?php endif; ?>
                                    </td>
                                    <td class="text-end">
                                        <?php if($row?->seoScore !== null): ?>
                                            <span style="color: <?php echo e(audit_score_color_var($row->seoScore)); ?>;">
                                                <?php echo e($row->seoScore); ?>

                                            </span>
                                        <?php else: ?>
                                            <span class="text-secondary">&mdash;</span>
                                        <?php endif; ?>
                                    </td>
                                    <td class="text-end">
                                        <?php if($row?->performanceScore !== null): ?>
                                            <span style="color: <?php echo e(audit_score_color_var($row->performanceScore)); ?>;">
                                                <?php echo e($row->performanceScore); ?> (<?php echo e($row->performanceGrade); ?>)
                                            </span>
                                        <?php else: ?>
                                            <span class="text-secondary">&mdash;</span>
                                        <?php endif; ?>
                                    </td>
                                    <td class="text-end">
                                        <?php if($row?->securityScore !== null): ?>
                                            <span style="color: <?php echo e(audit_score_color_var($row->securityScore)); ?>;">
                                                <?php echo e($row->securityScore); ?> (<?php echo e($row->securityGrade); ?>)
                                            </span>
                                        <?php else: ?>
                                            <span class="text-secondary">&mdash;</span>
                                        <?php endif; ?>
                                    </td>
                                    <td class="text-end">
                                        <?php if($row?->accessibilityScore !== null): ?>
                                            <span style="color: <?php echo e(audit_score_color_var($row->accessibilityScore)); ?>;">
                                                <?php echo e($row->accessibilityScore); ?> (<?php echo e($row->accessibilityGrade); ?>)
                                            </span>
                                        <?php else: ?>
                                            <span class="text-secondary">&mdash;</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php if($audit->status->value === 'completed'): ?>
                                            <a href="<?php echo e(route('audits.show', $audit)); ?>"
                                                class="btn btn-sm btn-outline-primary">
                                                View Full Report
                                            </a>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script src="<?php echo e(asset('js/bulk-audit-progress.js')); ?>?v=<?php echo e(file_exists(public_path('js/bulk-audit-progress.js')) ? filemtime(public_path('js/bulk-audit-progress.js')) : time()); ?>"></script>
    <script>
        // Phase K5 — client-side column sort, no server round-trip: every
        // score/status a column could sort by is already sitting in this
        // row's own data-* attributes (see the <tr> markup above), so
        // re-ordering rows in place is enough; nothing here ever
        // re-fetches or re-renders a row's own content.
        (function () {
            'use strict';

            var table = document.getElementById('bulk-audit-results-table');
            var tbody = document.getElementById('bulk-audit-results-tbody');

            if (!table || !tbody) {
                return;
            }

            var sortState = { key: null, direction: 1 };

            table.querySelectorAll('th[data-sort-key]').forEach(function (header) {
                header.style.cursor = 'pointer';
                header.addEventListener('click', function () {
                    var key = header.getAttribute('data-sort-key');

                    sortState.direction = sortState.key === key ? sortState.direction * -1 : 1;
                    sortState.key = key;

                    var rows = Array.prototype.slice.call(tbody.querySelectorAll('tr'));

                    rows.sort(function (a, b) {
                        var aValue = a.getAttribute('data-' + key);
                        var bValue = b.getAttribute('data-' + key);

                        // url/status are text; seo/performance/security/accessibility
                        // are numeric (-1 standing in for "no score yet", which
                        // naturally sorts lowest — exactly where a still-processing
                        // or failed audit belongs when sorting by score).
                        if (key === 'url' || key === 'status') {
                            return aValue.localeCompare(bValue) * sortState.direction;
                        }

                        return (parseFloat(aValue) - parseFloat(bValue)) * sortState.direction;
                    });

                    rows.forEach(function (row) {
                        tbody.appendChild(row);
                    });
                });
            });
        })();
    </script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\laragon\www\MsnVersionUpdate-09-To-13\analytics\resources\views\audit\bulk\show.blade.php ENDPATH**/ ?>