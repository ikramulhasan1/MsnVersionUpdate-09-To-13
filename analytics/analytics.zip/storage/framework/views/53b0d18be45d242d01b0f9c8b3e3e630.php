
<section class="pdf-section">
    <div class="pdf-section-heading">
        <span class="pdf-eyebrow">04 / Recommendations</span>
        <div class="pdf-section-title-bar">
            <h2 class="pdf-section-title">Recommendations</h2>
        </div>
    </div>

    <?php if($content->recommendationRows->isEmpty()): ?>
        <p class="pdf-empty">No recommendations are available for this audit yet.</p>
    <?php else: ?>
        <?php
            $hasPageUrls = $content->recommendationRows->contains(fn($row) => !empty($row->pageUrl));
        ?>
        <table class="pdf-table">
            <colgroup>
                <col style="width: 5%;">
                <col style="width: 12%;">
                <col style="width: 20%;">
                <col style="width: 10%;">
                <col style="<?php echo e($hasPageUrls ? 'width: 33%;' : 'width: 53%;'); ?>">
                <?php if($hasPageUrls): ?>
                    <col style="width: 20%;">
                <?php endif; ?>
            </colgroup>
            <thead>
                <tr>
                    <th>#</th>
                    <th>Category</th>
                    <th>Issue</th>
                    <th>Severity</th>
                    <th>Recommendation</th>
                    <?php if($hasPageUrls): ?>
                        <th>Page</th>
                    <?php endif; ?>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $content->recommendationRows; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                        $severityColor = match (strtolower($row->severity)) {
                            'critical' => '#b23b32',
                            'warning' => '#b5791f',
                            default => '#5b6270',
                        };
                    ?>
                    <tr>
                        <td><?php echo e($row->priority); ?></td>
                        <td><?php echo e($row->category); ?></td>
                        <td><?php echo e($row->issue); ?></td>
                        <td><span class="pdf-pill"
                                style="background-color: <?php echo e($severityColor); ?>;"><?php echo e(ucfirst($row->severity)); ?></span>
                        </td>
                        <td><?php echo e($row->recommendation ?? 'N/A'); ?></td>
                        <?php if($hasPageUrls): ?>
                            <td class="pdf-table-small"><?php echo e($row->pageUrl ?? '—'); ?></td>
                        <?php endif; ?>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    <?php endif; ?>
</section>
<?php /**PATH D:\laragon\www\MsnVersionUpdate-09-To-13\analytics\resources\views\audit\pdf\partials\recommendations.blade.php ENDPATH**/ ?>