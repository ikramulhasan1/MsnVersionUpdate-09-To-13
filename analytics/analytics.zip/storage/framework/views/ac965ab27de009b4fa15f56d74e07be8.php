
<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <style>
        body {
            font-family: 'DejaVu Sans', sans-serif;
            font-size: 8px;
            color: #15181f;
        }

        h1 {
            font-size: 14px;
            margin-bottom: 4px;
        }

        p.meta {
            font-size: 9px;
            color: #5b6270;
            margin-top: 0;
            margin-bottom: 12px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            table-layout: fixed;
        }

        th,
        td {
            border: 1px solid #e3e1d9;
            padding: 3px 4px;
            word-wrap: break-word;
            overflow-wrap: break-word;
            text-align: left;
            vertical-align: top;
        }

        th {
            background-color: #7c5f2c;
            color: #ffffff;
            font-weight: bold;
        }

        thead {
            display: table-header-group;
        }

        tr {
            page-break-inside: avoid;
        }
    </style>
</head>

<body>
    <h1>Discovered Websites Export</h1>
    <p class="meta"><?php echo e(count($rows)); ?> website(s) &mdash; generated <?php echo e(now()->format('M j, Y g:i A')); ?></p>

    <table>
        <thead>
            <tr>
                <th>Business Name</th>
                <th>Website</th>
                <th>Industry</th>
                <th>Country</th>
                <th>City</th>
                <th>Technology</th>
                <th>CMS</th>
                <th>SEO</th>
                <th>Perf</th>
                <th>Sec</th>
                <th>A11y</th>
                <th>Mobile</th>
                <th>Opp.</th>
                <th>Email</th>
                <th>Phone</th>
                <th>Social Links</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $rows; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($row->businessName); ?></td>
                    <td><?php echo e($row->website); ?></td>
                    <td><?php echo e($row->industry); ?></td>
                    <td><?php echo e($row->country); ?></td>
                    <td><?php echo e($row->city); ?></td>
                    <td><?php echo e($row->technology); ?></td>
                    <td><?php echo e($row->cms); ?></td>
                    <td><?php echo e($row->seoScore); ?></td>
                    <td><?php echo e($row->performanceScore); ?></td>
                    <td><?php echo e($row->securityScore); ?></td>
                    <td><?php echo e($row->accessibilityScore); ?></td>
                    <td><?php echo e($row->mobileScore); ?></td>
                    <td><?php echo e($row->opportunityScore); ?></td>
                    <td><?php echo e($row->email); ?></td>
                    <td><?php echo e($row->phone); ?></td>
                    <td><?php echo e($row->socialLinks); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</body>

</html>
<?php /**PATH D:\laragon\www\MsnVersionUpdate-09-To-13\analytics\resources\views\discovery\pdf\export.blade.php ENDPATH**/ ?>