


<?php $__env->startSection('title', 'Website Discovery'); ?>

<?php $__env->startSection('content'); ?>
    <section class="container dashboard-section">
        <?php if(session('status')): ?>
            <div class="alert alert-success">
                <?php echo e(session('status')); ?>

                <?php if(session('bulkAuditResults')): ?>
                    <ul class="mb-0 mt-2 ps-3">
                        <?php $__currentLoopData = session('bulkAuditResults'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bulkResult): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li>
                                <a href="<?php echo e(route('audits.show', $bulkResult['uuid'])); ?>">
                                    <?php echo e($bulkResult['url']); ?>

                                </a>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                <?php endif; ?>
            </div>
        <?php endif; ?>

        <div class="d-flex flex-wrap align-items-center justify-content-between gap-3 mb-4">
            <div>
                <p class="text-secondary small mb-1">Discover</p>
                <h1 class="h3 mb-0">Website Discovery</h1>
            </div>
            <div class="d-flex align-items-center gap-2">
                <a href="<?php echo e(route('discovery.watchlist')); ?>" class="btn btn-outline-secondary btn-sm">
                    Watchlist
                </a>
                <a href="<?php echo e(route('discovery.searches.index')); ?>" class="btn btn-outline-secondary btn-sm">
                    Saved Searches
                </a>
            </div>
        </div>

        
        <form method="POST" action="<?php echo e(route('discovery.bulk-audit')); ?>" id="discovery-bulk-audit-form" class="d-none">
            <?php echo csrf_field(); ?>
        </form>
        <section class="mb-4" id="discovery-search-panel">
            <span class="report-eyebrow">01 / Search</span>
            <?php echo $__env->make('discovery.partials.search-panel', [
                'industries' => $industries,
                'countries' => $countries,
                'filters' => $filters,
                'websiteStatuses' => $websiteStatuses,
                'websiteTypes' => $websiteTypes,
                'technologyGroups' => $technologyGroups,
                'serverSoftware' => $serverSoftware,
                'seoIssues' => $seoIssues,
                'securityIssues' => $securityIssues,
                'opportunityFilters' => $opportunityFilters,
                'businessSizes' => $businessSizes,
                'lastUpdatedRanges' => $lastUpdatedRanges,
                'trafficRanges' => $trafficRanges,
                'socialPlatforms' => $socialPlatforms,
                'contactAvailabilityOptions' => $contactAvailabilityOptions,
            ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        </section>

        
        <section class="mb-4" id="discovery-analytics">
            <span class="report-eyebrow">02 / Search Analytics</span>

            <div class="row g-3 mb-3">
                <div class="col-12 col-md-4">
                    <div class="card h-100">
                        <div class="card-body p-4 text-center">
                            <p class="text-secondary small mb-1">Total Websites Found</p>
                            <p class="h3 mb-0"><?php echo e(number_format($analytics->totalCount)); ?></p>
                        </div>
                    </div>
                </div>

                <div class="col-12 col-md-4">
                    <div class="card h-100">
                        <div class="card-body p-4 text-center">
                            <p class="text-secondary small mb-1">Poor SEO (score &lt; 50)</p>
                            <p class="h3 mb-0" style="color: var(--audit-danger);">
                                <?php echo e(number_format($analytics->poorSeoCount)); ?>

                            </p>
                        </div>
                    </div>
                </div>

                <div class="col-12 col-md-4">
                    <div class="card h-100">
                        <div class="card-body p-4 text-center">
                            <p class="text-secondary small mb-1">High Opportunity</p>
                            <p class="h3 mb-0" style="color: var(--audit-primary);">
                                <?php echo e(number_format($analytics->highOpportunityCount)); ?>

                            </p>
                        </div>
                    </div>
                </div>
            </div>

            <?php if($analytics->technologyBreakdown !== []): ?>
                <div class="card chart-card">
                    <div class="card-body p-4">
                        <h2 class="h6 mb-3">Technology Breakdown (CMS)</h2>
                        <div class="chart-wrap">
                            <canvas id="discoveryTechnologyChart"
                                data-labels="<?php echo e(json_encode(array_keys($analytics->technologyBreakdown))); ?>"
                                data-counts="<?php echo e(json_encode(array_values($analytics->technologyBreakdown))); ?>"
                                aria-label="Pie chart of detected CMS across the current search results"
                                role="img"></canvas>
                        </div>
                    </div>
                </div>
            <?php endif; ?>

            <?php if($analytics->isSampled()): ?>
                <p class="text-secondary small mt-2 mb-0">
                    Technology breakdown and the Poor SEO/High Opportunity counts above are based on a sample
                    of the first <?php echo e(number_format($analytics->sampledCount)); ?> matching results (out of
                    <?php echo e(number_format($analytics->totalCount)); ?> total).
                </p>
            <?php endif; ?>
        </section>

        
        <section id="discovery-results" data-compare-url="<?php echo e(route('discovery.compare')); ?>">
            <span class="report-eyebrow">03 / Results</span>

            <div class="d-flex flex-wrap align-items-center justify-content-between gap-3 mb-3">
                <p class="mb-0 fw-medium">
                    <?php echo e(number_format($websites->total())); ?>

                    <?php echo e(\Illuminate\Support\Str::plural('Website', $websites->total())); ?> Found
                </p>

                <div class="d-flex align-items-center gap-3">
                    <div class="btn-group btn-group-sm" role="group" aria-label="Results view">
                        <button type="button" class="btn btn-outline-secondary active" id="discovery-view-list">
                            List View
                        </button>
                        <button type="button" class="btn btn-outline-secondary" id="discovery-view-map">
                            Map View
                        </button>
                    </div>

                    
                    <div class="dropdown">
                        <button class="btn btn-outline-secondary btn-sm dropdown-toggle" type="button"
                            data-bs-toggle="dropdown" aria-expanded="false">
                            Export
                        </button>
                        <ul class="dropdown-menu dropdown-menu-end">
                            <li>
                                <a class="dropdown-item"
                                    href="<?php echo e(route('discovery.export', array_merge($filters, ['format' => 'excel']))); ?>">
                                    Excel (.xlsx)
                                </a>
                            </li>
                            <li>
                                <a class="dropdown-item"
                                    href="<?php echo e(route('discovery.export', array_merge($filters, ['format' => 'csv']))); ?>">
                                    CSV
                                </a>
                            </li>
                            <li>
                                <a class="dropdown-item"
                                    href="<?php echo e(route('discovery.export', array_merge($filters, ['format' => 'pdf']))); ?>">
                                    PDF
                                </a>
                            </li>
                            <li>
                                <a class="dropdown-item"
                                    href="<?php echo e(route('discovery.export', array_merge($filters, ['format' => 'json']))); ?>">
                                    JSON
                                </a>
                            </li>
                        </ul>
                    </div>

                    <div class="d-flex align-items-center gap-2">
                        <label for="discovery-sort" class="form-label small fw-medium mb-0">Sort By</label>
                        <select class="form-select form-select-sm" id="discovery-sort" style="width: auto;">
                            <?php $__currentLoopData = $sortOptions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($option->value); ?>" <?php if(($filters['sort'] ?? '') === $option->value): echo 'selected'; endif; ?>>
                                    <?php echo e($option->label()); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>
            </div>

            <div id="discovery-results-list">
                <?php if($websites->isEmpty()): ?>
                    <div class="discovery-placeholder">
                        <p class="mb-0">
                            <?php echo e($filters === [] ? 'No discovered websites yet.' : 'No discovered websites match your filters.'); ?>

                        </p>
                    </div>
                <?php else: ?>
                    <div class="row row-cols-1 row-cols-lg-3 g-3">
                        <?php $__currentLoopData = $websites; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $website): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col">
                                <?php echo $__env->make('discovery.partials.result-card', [
                                    'website' => $website,
                                    'isWatched' => $website->watchlistItem !== null,
                                ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>

                    <div class="mt-4 d-flex justify-content-center">
                        <?php echo e($websites->links()); ?>

                    </div>
                <?php endif; ?>
            </div>

            
            <div id="discovery-map-section" class="d-none" data-map-data-url="<?php echo e(route('discovery.map-data')); ?>">
                <div id="discovery-map" style="height: 500px; border-radius: 0.85rem; overflow: hidden;"></div>
            </div>
        </section>
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('styles'); ?>
    
    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" />
<?php $__env->stopPush(); ?>

<?php $__env->startPush('scripts'); ?>
    
    <script
        src="<?php echo e(asset('js/discovery-search-panel.js')); ?>?v=<?php echo e(file_exists(public_path('js/discovery-search-panel.js')) ? filemtime(public_path('js/discovery-search-panel.js')) : time()); ?>">
    </script>
    <script
        src="<?php echo e(asset('js/discovery-compare.js')); ?>?v=<?php echo e(file_exists(public_path('js/discovery-compare.js')) ? filemtime(public_path('js/discovery-compare.js')) : time()); ?>">
    </script>
    <script
        src="<?php echo e(asset('js/discovery-bulk-audit.js')); ?>?v=<?php echo e(file_exists(public_path('js/discovery-bulk-audit.js')) ? filemtime(public_path('js/discovery-bulk-audit.js')) : time()); ?>">
    </script>
    
    <script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.4/dist/chart.umd.min.js"></script>
    <script
        src="<?php echo e(asset('js/dashboard-charts.js')); ?>?v=<?php echo e(file_exists(public_path('js/dashboard-charts.js')) ? filemtime(public_path('js/dashboard-charts.js')) : time()); ?>">
    </script>
    <script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>
    <script
        src="<?php echo e(asset('js/discovery-map.js')); ?>?v=<?php echo e(file_exists(public_path('js/discovery-map.js')) ? filemtime(public_path('js/discovery-map.js')) : time()); ?>">
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\laragon\www\MsnVersionUpdate-09-To-13\analytics\resources\views/discovery/index.blade.php ENDPATH**/ ?>