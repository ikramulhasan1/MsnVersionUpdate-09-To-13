


<?php $__env->startSection('title', 'Compare Websites'); ?>

<?php
    $metrics = [
        'seo_score' => 'SEO',
        'performance_score' => 'Performance',
        'security_score' => 'Security',
        'accessibility_score' => 'Accessibility',
        'mobile_score' => 'Mobile',
    ];
?>

<?php $__env->startSection('content'); ?>
    <section class="container dashboard-section">
        <div class="d-flex flex-wrap align-items-center justify-content-between gap-3 mb-4">
            <div>
                <p class="text-secondary small mb-1">Discover</p>
                <h1 class="h3 mb-0">Compare Websites</h1>
            </div>
            <a href="<?php echo e(route('discovery.index')); ?>" class="btn btn-outline-secondary btn-sm">
                Back to Results
            </a>
        </div>

        <div class="card">
            <div class="table-responsive">
                <table class="table align-middle mb-0">
                    <thead>
                        <tr>
                            <th scope="col" class="text-secondary small text-uppercase">Metric</th>
                            <?php $__currentLoopData = $websites; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $website): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <th scope="col">
                                    <a href="<?php echo e(route('discovery.show', $website)); ?>" class="text-decoration-none">
                                        <?php echo e($website->business_name ?? $website->domain); ?>

                                    </a>
                                    <p class="text-secondary small mb-0 fw-normal"><?php echo e($website->domain); ?></p>
                                </th>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $metrics; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $column => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php
                                $bestScore = $websites->pluck($column)->filter(fn($score) => $score !== null)->max();
                            ?>
                            <tr>
                                <th scope="row" class="text-secondary small fw-medium"><?php echo e($label); ?></th>
                                <?php $__currentLoopData = $websites; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $website): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php $score = $website->{$column}; ?>
                                    <td class="<?php echo e($score !== null && $score === $bestScore ? 'compare-best' : ''); ?>">
                                        <?php echo e($score ?? '—'); ?>

                                    </td>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\laragon\www\MsnVersionUpdate-09-To-13\analytics\resources\views\discovery\compare.blade.php ENDPATH**/ ?>