
<section class="pdf-section">
    <div class="pdf-section-heading">
        <span class="pdf-eyebrow">03 / Score Analysis</span>
        <div class="pdf-section-title-bar">
            <h2 class="pdf-section-title">Category Score Chart</h2>
        </div>
    </div>

    <?php if($content->scoreRows->isEmpty()): ?>
        <p class="pdf-empty">No score data is available to chart yet.</p>
    <?php else: ?>
        <table class="pdf-chart-table">
            <colgroup>
                <col style="width: 24%;">
                <col style="width: 56%;">
                <col style="width: 20%;">
            </colgroup>
            <tbody>
                <?php $__currentLoopData = $content->scoreRows; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td class="pdf-chart-label"><?php echo e($row->category); ?></td>
                        <td class="pdf-chart-track-cell">
                            <div class="pdf-bar-track">
                                <div class="pdf-bar-fill" style="width: <?php echo e($row->score ?? 0); ?>%;">
                                    <div class="pdf-bar-fill-top"></div>
                                    <div class="pdf-bar-fill-bottom"></div>
                                </div>
                            </div>
                        </td>
                        <td class="pdf-chart-value"><?php echo e($row->score !== null ? $row->score . '/100' : 'N/A'); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    <?php endif; ?>

    <div class="pdf-section-title-bar pdf-section-title-spaced">
        <h2 class="pdf-section-title">Issue Severity Breakdown</h2>
    </div>

    <?php if($content->severityCounts === null): ?>
        <p class="pdf-empty">No issue severity data is available yet.</p>
    <?php else: ?>
        <?php
            $severityTotal = max(array_sum($content->severityCounts), 1);
        ?>
        <div class="pdf-severity-bar">
            <div class="pdf-severity-segment pdf-severity-critical"
                style="width: <?php echo e(($content->severityCounts['critical'] / $severityTotal) * 100); ?>%;"></div>
            <div class="pdf-severity-segment pdf-severity-warning"
                style="width: <?php echo e(($content->severityCounts['warning'] / $severityTotal) * 100); ?>%;"></div>
            <div class="pdf-severity-segment pdf-severity-notice"
                style="width: <?php echo e(($content->severityCounts['notice'] / $severityTotal) * 100); ?>%;"></div>
        </div>
        <table class="pdf-table pdf-severity-legend">
            <colgroup>
                <col style="width: 20px;">
                <col style="width: 30%;">
                <col style="width: 70%;">
            </colgroup>
            <tbody>
                <tr>
                    <td class="pdf-legend-swatch pdf-severity-critical"></td>
                    <td>Critical</td>
                    <td><?php echo e($content->severityCounts['critical']); ?></td>
                </tr>
                <tr>
                    <td class="pdf-legend-swatch pdf-severity-warning"></td>
                    <td>Warning</td>
                    <td><?php echo e($content->severityCounts['warning']); ?></td>
                </tr>
                <tr>
                    <td class="pdf-legend-swatch pdf-severity-notice"></td>
                    <td>Notice</td>
                    <td><?php echo e($content->severityCounts['notice']); ?></td>
                </tr>
            </tbody>
        </table>
    <?php endif; ?>
</section>
<?php /**PATH D:\laragon\www\MsnVersionUpdate-09-To-13\analytics\resources\views\audit\pdf\partials\charts.blade.php ENDPATH**/ ?>