
<aside class="app-sidebar" id="app-sidebar">
    <div class="app-sidebar-header">
        <a href="<?php echo e(route('home')); ?>" class="app-sidebar-brand text-decoration-none">
            <span class="brand-mark">AI</span>
            <span class="app-sidebar-brand-text">Website Audit</span>
        </a>
    </div>

    <nav class="app-sidebar-nav">
        <?php $__currentLoopData = config('sidebar.items', []); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
                // Phase N3/N4 — see config/sidebar.php's own docblock
                // on 'public'/'permission'/'role' for exactly what each
                // means. Only an item with 'public' => true is ever
                // shown to a logged-out visitor; every other item
                // requires at least being logged in, on top of
                // whatever permission/role it also carries.
                $canSeeItem = ! empty($item['public']);

                if (auth()->check()) {
                    $canSeeItem = true;

                    if (! empty($item['permission']) && ! auth()->user()->can($item['permission'])) {
                        $canSeeItem = false;
                    }

                    if (! empty($item['role']) && ! auth()->user()->hasRole($item['role'])) {
                        $canSeeItem = false;
                    }
                }
            ?>
            <?php if(! $canSeeItem) continue; ?>
            <?php
                $isActive = false;
                foreach ($item['active'] ?? [] as $pattern) {
                    if (request()->routeIs($pattern)) {
                        $isActive = true;
                        break;
                    }
                }
            ?>
            <a href="<?php echo e(route($item['route'])); ?>"
                class="app-sidebar-link <?php echo e($isActive ? 'active' : ''); ?>">
                <svg class="app-sidebar-link-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor"
                    stroke-width="2" aria-hidden="true">
                    <?php echo $item['icon']; ?>

                </svg>
                <span class="app-sidebar-link-text"><?php echo e($item['label']); ?></span>
            </a>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </nav>

    <?php if(auth()->guard()->check()): ?>
        <div class="app-sidebar-footer">
            
            <div class="dropup">
                <button type="button" class="app-sidebar-link app-notification-bell w-100 text-start border-0 bg-transparent"
                    id="app-notification-bell-toggle" data-bs-toggle="dropdown" aria-expanded="false">
                    <svg class="app-sidebar-link-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor"
                        stroke-width="2" aria-hidden="true">
                        <path d="M18 8a6 6 0 0 0-12 0c0 7-3 9-3 9h18s-3-2-3-9"
                            stroke-linecap="round" stroke-linejoin="round" />
                        <path d="M13.73 21a2 2 0 0 1-3.46 0" stroke-linecap="round" stroke-linejoin="round" />
                    </svg>
                    <span class="app-sidebar-link-text">Notifications</span>
                    <span class="app-notification-badge d-none" id="app-notification-badge"></span>
                </button>
                <div class="dropdown-menu app-notification-dropdown" aria-labelledby="app-notification-bell-toggle">
                    <div class="app-notification-dropdown-header">
                        <span class="fw-semibold small">Notifications</span>
                        <form method="POST" action="<?php echo e(route('notifications.read-all')); ?>" class="d-inline">
                            <?php echo csrf_field(); ?>
                            <button type="submit" class="btn btn-link btn-sm p-0 app-notification-mark-all">
                                Mark all read
                            </button>
                        </form>
                    </div>
                    <div id="app-notification-list" class="app-notification-list">
                        <p class="text-secondary small text-center py-3 mb-0">Loading&hellip;</p>
                    </div>
                    <a href="<?php echo e(route('notifications.index')); ?>" class="app-notification-dropdown-footer">
                        View all notifications
                    </a>
                </div>
            </div>
        </div>
    <?php endif; ?>
</aside><?php /**PATH D:\laragon\www\MsnVersionUpdate-09-To-13\analytics\resources\views\layouts\partials\sidebar.blade.php ENDPATH**/ ?>