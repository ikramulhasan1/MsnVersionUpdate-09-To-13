

<?php $__env->startSection('title', 'Pricing Plans — Admin'); ?>

<?php $__env->startSection('content'); ?>
    <section class="container py-4">
        <div class="d-flex align-items-center justify-content-between mb-4">
            <div>
                <p class="text-secondary small mb-1">Admin</p>
                <h1 class="h4 fw-semibold mb-0">Pricing Plans</h1>
            </div>
            <a href="<?php echo e(route('admin.plans.create')); ?>" class="btn btn-primary btn-sm">New Plan</a>
        </div>

        <?php echo $__env->make('admin.partials.nav', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

        <?php if(session('status')): ?>
            <div class="alert alert-success small"><?php echo e(session('status')); ?></div>
        <?php endif; ?>

        <div class="card">
            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0">
                    <thead>
                        <tr>
                            <th>Name</th>
                            <th>Price</th>
                            <th>Duration</th>
                            <th>Visibility</th>
                            <th>Features</th>
                            <th class="text-end">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $plans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $plan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td>
                                    <?php echo e($plan->name); ?>

                                    <?php if($plan->is_default_trial): ?>
                                        <span class="badge bg-warning-subtle text-warning-emphasis ms-1">
                                            Default Trial
                                        </span>
                                    <?php endif; ?>
                                </td>
                                <td><?php echo e($plan->priceLabel()); ?></td>
                                <td><?php echo e($plan->duration_days !== null ? $plan->duration_days . ' day(s)' : 'No expiry'); ?></td>
                                <td>
                                    <?php if($plan->is_public): ?>
                                        <span class="badge bg-success-subtle text-success-emphasis">Public</span>
                                    <?php else: ?>
                                        <span class="badge bg-secondary-subtle text-secondary-emphasis">Hidden</span>
                                    <?php endif; ?>
                                </td>
                                <td class="small text-secondary">
                                    <?php $__currentLoopData = \App\Http\Controllers\Admin\PlanController::featureToggles(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($plan->allowsFeature($key)): ?>
                                            <span class="badge bg-secondary-subtle text-secondary-emphasis me-1"><?php echo e($label); ?></span>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </td>
                                <td class="text-end">
                                    <a href="<?php echo e(route('admin.plans.edit', $plan)); ?>"
                                        class="btn btn-sm btn-outline-secondary">Edit</a>
                                    <form method="POST" action="<?php echo e(route('admin.plans.destroy', $plan)); ?>"
                                        class="d-inline" onsubmit="return confirm('Delete this plan?');">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="btn btn-sm btn-outline-danger">Delete</button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\laragon\www\MsnVersionUpdate-09-To-13\analytics\resources\views\admin\plans\index.blade.php ENDPATH**/ ?>