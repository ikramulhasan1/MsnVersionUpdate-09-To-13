
<svg width="16" height="16" viewBox="0 0 24 24" fill="<?php echo e($filled ?? false ? 'currentColor' : 'none'); ?>"
    stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
    <path d="M12 2.5l3.09 6.26 6.91 1.01-5 4.87 1.18 6.86L12 17.77 5.82 21.5 7 14.64l-5-4.87 6.91-1.01L12 2.5z" />
</svg>
<?php /**PATH D:\laragon\www\MsnVersionUpdate-09-To-13\analytics\resources\views\discovery\partials\star-icon.blade.php ENDPATH**/ ?>