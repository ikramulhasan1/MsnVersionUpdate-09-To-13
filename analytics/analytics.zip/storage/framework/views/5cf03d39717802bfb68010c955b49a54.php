
<section class="pdf-section">
    <div class="pdf-section-heading">
        <span class="pdf-eyebrow">02 / Category Breakdown</span>
        <div class="pdf-section-title-bar">
            <h2 class="pdf-section-title">Category Scores</h2>
        </div>
    </div>

    <?php if($content->scoreRows->isEmpty()): ?>
        <p class="pdf-empty">No category scores are available for this audit yet.</p>
    <?php else: ?>
        <table class="pdf-score-grid" role="presentation">
            <colgroup>
                <col style="width: 50%;">
                <col style="width: 50%;">
            </colgroup>
            <tbody>
                <?php $__currentLoopData = $content->scoreRows->chunk(2); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cardRow): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <?php $__currentLoopData = $cardRow; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php
                                $cardColor = match (true) {
                                    $row->grade === null => '#9ea3ad',
                                    in_array($row->grade, ['A', 'B'], true) => '#2f8f5e',
                                    in_array($row->grade, ['C', 'D'], true) => '#b5791f',
                                    default => '#b23b32',
                                };
                            ?>
                            <td class="pdf-score-card-cell" <?php if($cardRow->count() === 1): ?> colspan="2" <?php endif; ?>>
                                <div class="pdf-score-card" style="border-bottom-color: <?php echo e($cardColor); ?>;">
                                    <div class="pdf-score-card-category"><?php echo e($row->category); ?></div>
                                    <div class="pdf-score-card-number" style="color: <?php echo e($cardColor); ?>;">
                                        <?php echo e($row->score !== null ? $row->score : 'N/A'); ?><?php if($row->score !== null): ?>
                                            <span class="pdf-score-card-max">/100</span>
                                        <?php endif; ?>
                                    </div>
                                    <div class="pdf-score-card-meta">
                                        <span class="pdf-score-card-grade"
                                            style="color: <?php echo e($cardColor); ?>;"><?php echo e($row->grade ?? '—'); ?></span>
                                        <span class="pdf-score-card-date"><?php echo e($row->analyzedAt); ?></span>
                                    </div>
                                </div>
                            </td>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    <?php endif; ?>
</section>
<?php /**PATH D:\laragon\www\MsnVersionUpdate-09-To-13\analytics\resources\views\audit\pdf\partials\scores.blade.php ENDPATH**/ ?>