


<?php $__env->startSection('title', 'Bulk Website Audit'); ?>

<?php $__env->startSection('content'); ?>
    <section class="container dashboard-section">
        <div class="mb-4">
            <p class="text-secondary small mb-1">Website Audit</p>
            <h1 class="h3 mb-0">Audit Multiple Websites</h1>
            <p class="text-secondary mt-2 mb-0">
                Paste a list of URLs (one per line) or upload a CSV file, and every one will be queued for
                audit together.
            </p>
        </div>

        <?php if(session('status')): ?>
            <div class="alert alert-success"><?php echo e(session('status')); ?></div>
        <?php endif; ?>

        <?php if($errors->any()): ?>
            <div class="alert alert-danger" role="alert">
                <ul class="mb-0 ps-3">
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>

        <div class="card">
            <div class="card-body p-4">
                <form method="POST" action="<?php echo e(route('bulk-audits.store')); ?>" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>

                    <div class="mb-4">
                        <label for="bulk-audit-name" class="form-label small fw-medium">
                            Batch Name <span class="text-secondary fw-normal">(optional)</span>
                        </label>
                        <input type="text" class="form-control" id="bulk-audit-name" name="name"
                            value="<?php echo e(old('name')); ?>" placeholder="e.g. Client A — Q3 Review" maxlength="255">
                    </div>

                    
                    <div class="mb-4">
                        <p class="form-label small fw-medium mb-2">Audit Mode</p>
                        <div class="d-flex gap-4">
                            <div class="form-check">
                                <input class="form-check-input" type="radio" name="mode" id="bulk-mode-quick"
                                    value="quick" <?php if(old('mode', 'quick') === 'quick'): echo 'checked'; endif; ?>>
                                <label class="form-check-label" for="bulk-mode-quick"
                                    title="<?php echo e(\App\Audit\Enums\AuditMode::QUICK->description()); ?>">
                                    Quick Scan
                                </label>
                            </div>
                            <div class="form-check">
                                <input class="form-check-input" type="radio" name="mode" id="bulk-mode-full"
                                    value="full" <?php if(old('mode') === 'full'): echo 'checked'; endif; ?>>
                                <label class="form-check-label" for="bulk-mode-full"
                                    title="<?php echo e(\App\Audit\Enums\AuditMode::FULL->description()); ?>">
                                    Full Audit
                                </label>
                            </div>
                        </div>
                        <p class="text-secondary small mt-2 mb-0" id="bulk-mode-hint">
                            <?php echo e(old('mode') === 'full' ? \App\Audit\Enums\AuditMode::FULL->description() : \App\Audit\Enums\AuditMode::QUICK->description()); ?>

                        </p>
                    </div>

                    <div class="row g-4">
                        <div class="col-12 col-md-6">
                            <label for="bulk-audit-urls" class="form-label small fw-medium">
                                Paste URLs <span class="text-secondary fw-normal">(one per line)</span>
                            </label>
                            <textarea class="form-control" id="bulk-audit-urls" name="urls" rows="10"
                                placeholder="https://example.com&#10;https://another-site.com"><?php echo e(old('urls')); ?></textarea>
                        </div>

                        <div class="col-12 col-md-6">
                            <label for="bulk-audit-csv" class="form-label small fw-medium">
                                Or Upload a CSV File
                            </label>
                            <input type="file" class="form-control" id="bulk-audit-csv" name="csv"
                                accept=".csv,.txt">
                            <p class="text-secondary small mt-2 mb-0">
                                The first column of every row is read as a URL — a header row (or any other
                                row whose first cell isn't a URL) is skipped automatically.
                            </p>
                        </div>
                    </div>

                    <div class="mt-4">
                        <button type="submit" class="btn btn-primary px-4">Queue Audits</button>
                    </div>
                </form>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script>
        // Mirrors home/index.blade.php's own hint-update handler (Phase
        // K1) — see that file's own docblock for why these two strings
        // are duplicated in plain JS rather than round-tripping to the
        // server.
        const BULK_AUDIT_MODE_HINTS = {
            full: 'Crawls multiple pages and includes real PageSpeed Insights data. Takes longer, most complete.',
            quick: 'Homepage only, no PageSpeed Insights call. Much faster, less depth.',
        };

        document.querySelectorAll('input[name="mode"]').forEach(function (radio) {
            radio.addEventListener('change', function () {
                const hint = document.getElementById('bulk-mode-hint');
                if (hint && BULK_AUDIT_MODE_HINTS[radio.value]) {
                    hint.textContent = BULK_AUDIT_MODE_HINTS[radio.value];
                }
            });
        });
    </script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\laragon\www\MsnVersionUpdate-09-To-13\analytics\resources\views\audit\bulk\create.blade.php ENDPATH**/ ?>