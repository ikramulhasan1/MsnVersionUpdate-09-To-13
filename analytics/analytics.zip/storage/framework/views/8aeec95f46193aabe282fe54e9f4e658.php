

<?php $__env->startSection('title', 'Upgrade Subscription — Website Audit & Analysis Platform'); ?>

<?php $__env->startSection('content'); ?>
    <section class="container py-4">
        <h1 class="h4 fw-semibold mb-1">Upgrade Subscription</h1>
        <p class="text-secondary mb-4">
            <?php if($currentPlan !== null): ?>
                You're currently on <strong><?php echo e($currentPlan->name); ?></strong>.
            <?php else: ?>
                You don't have a plan assigned yet.
            <?php endif; ?>
        </p>

        <?php if(session('status')): ?>
            <div class="alert alert-success small"><?php echo e(session('status')); ?></div>
        <?php endif; ?>

        <?php if($pendingRequests->isNotEmpty()): ?>
            <div class="alert alert-info small">
                You have a pending request to upgrade to
                <?php $__currentLoopData = $pendingRequests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $request): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <strong><?php echo e($request->plan->name); ?></strong><?php echo e(! $loop->last ? ', ' : ''); ?>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                — we'll be in touch shortly.
            </div>
        <?php endif; ?>

        <?php if($plans->isEmpty()): ?>
            <div class="card">
                <div class="card-body p-4 text-center text-secondary">
                    No other plans are available to upgrade to right now.
                </div>
            </div>
        <?php else: ?>
            <div class="row g-4">
                <?php $__currentLoopData = $plans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $plan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-12 col-md-6 col-lg-4">
                        <div class="n15-pricing-card">
                            <h2 class="n15-feature-title"><?php echo e($plan->name); ?></h2>
                            <p class="n15-pricing-price"><?php echo e($plan->priceLabel()); ?></p>
                            <p class="text-secondary small mb-3"><?php echo e($plan->description); ?></p>
                            <ul class="n15-pricing-list">
                                <li><?php echo e($plan->allowsFeature('run-audit') ? 'Website Audit' : 'No Website Audit'); ?></li>
                                <li><?php echo e($plan->allowsFeature('run-bulk-audit') ? 'Bulk Audit' : 'No Bulk Audit'); ?></li>
                                <li><?php echo e($plan->allowsFeature('export-data') ? 'PDF/Excel export' : 'No export'); ?></li>
                                <li>
                                    <?php echo e($plan->dailyAuditLimit() !== null ? $plan->dailyAuditLimit() . ' audits/day' : 'Unlimited audits'); ?>

                                </li>
                            </ul>

                            <?php
                                $alreadyRequested = $pendingRequests->contains(fn ($r) => $r->plan_id === $plan->id);
                            ?>

                            <form method="POST" action="<?php echo e(route('subscription.request-upgrade')); ?>">
                                <?php echo csrf_field(); ?>
                                <input type="hidden" name="plan_id" value="<?php echo e($plan->id); ?>">
                                <button type="submit" class="btn btn-primary w-100" <?php if($alreadyRequested): echo 'disabled'; endif; ?>>
                                    <?php echo e($alreadyRequested ? 'Requested' : 'Request This Plan'); ?>

                                </button>
                            </form>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

            <p class="text-secondary small mt-4">
                Requesting a plan sends a request to our team — payment and instant checkout are coming
                soon.
            </p>
        <?php endif; ?>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\laragon\www\MsnVersionUpdate-09-To-13\analytics\resources\views\subscription\upgrade.blade.php ENDPATH**/ ?>