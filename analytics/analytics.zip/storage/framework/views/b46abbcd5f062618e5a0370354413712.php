
<section class="pdf-section">
    <div class="pdf-section-heading">
        <span class="pdf-eyebrow">05 / Summary</span>
        <div class="pdf-section-title-bar">
            <h2 class="pdf-section-title">Summary</h2>
        </div>
    </div>

    <?php if($content->summaryRows->isEmpty()): ?>
        <p class="pdf-empty">No summary data is available for this audit yet.</p>
    <?php else: ?>
        <table class="pdf-table pdf-summary-table">
            <colgroup>
                <col style="width: 32%;">
                <col style="width: 68%;">
            </colgroup>
            <tbody>
                <?php $__currentLoopData = $content->summaryRows; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                        $isPriorityRow = in_array(
                            $row->label,
                            ['Recommendation Priority', 'Opportunity Priority'],
                            true,
                        );

                        $pillColor = match (true) {
                            $isPriorityRow => match (strtolower($row->value)) {
                                'high' => '#b23b32',
                                'medium' => '#b5791f',
                                'low' => '#2f8f5e',
                                default => null,
                            },
                            $row->label === 'Overall Grade' => match (true) {
                                in_array($row->value, ['A', 'B'], true) => '#2f8f5e',
                                in_array($row->value, ['C', 'D'], true) => '#b5791f',
                                $row->value === 'F' => '#b23b32',
                                default => null,
                            },
                            default => null,
                        };
                    ?>
                    <tr>
                        <th><?php echo e($row->label); ?></th>
                        <td>
                            <?php if($pillColor !== null): ?>
                                <span class="pdf-pill"
                                    style="background-color: <?php echo e($pillColor); ?>;"><?php echo e($row->value); ?></span>
                            <?php else: ?>
                                <?php echo e($row->value); ?>

                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    <?php endif; ?>
</section>
<?php /**PATH D:\laragon\www\MsnVersionUpdate-09-To-13\analytics\resources\views\audit\pdf\partials\summary.blade.php ENDPATH**/ ?>