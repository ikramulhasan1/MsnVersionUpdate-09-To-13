
<div class="dashboard-components mt-4">

    
    <section class="mb-4">
        <span class="report-eyebrow">03 / Score Analysis</span>

        <div class="row g-4">
            <div class="col-12 col-lg-7">
                <div class="card chart-card h-100">
                    <div class="card-body p-4">
                        <h2 class="h6 mb-3">Score Comparison</h2>
                        <div class="chart-wrap">
                            <canvas id="scoreComparisonChart"
                                data-labels="<?php echo e(json_encode(array_column($categories, 'label'))); ?>"
                                data-scores="<?php echo e(json_encode(array_column($categories, 'score'))); ?>"
                                aria-label="Bar chart comparing the score of every audited category"
                                role="img"></canvas>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-12 col-lg-5">
                <div class="card chart-card h-100">
                    <div class="card-body p-4">
                        <h2 class="h6 mb-3">Category Overview</h2>
                        <div class="chart-wrap">
                            <canvas id="categoryRadarChart"
                                data-labels="<?php echo e(json_encode(array_column($categories, 'abbr'))); ?>"
                                data-scores="<?php echo e(json_encode(array_column($categories, 'score'))); ?>"
                                aria-label="Radar chart comparing every audited category at a glance"
                                role="img"></canvas>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    
    <section class="mb-4">
        <span class="report-eyebrow">04 / Checks Overview</span>

        <div class="card chart-card">
            <div class="card-body p-4">
                <div class="d-flex align-items-center justify-content-between mb-3 flex-wrap gap-2">
                    <h2 class="h6 mb-0">Pass / Warning / Fail by Category</h2>
                    <div class="d-flex gap-3">
                        <span class="checks-overview-legend"><span class="dot bg-success"></span> Pass</span>
                        <span class="checks-overview-legend"><span class="dot bg-warning"></span> Warning</span>
                        <span class="checks-overview-legend"><span class="dot bg-danger"></span> Fail</span>
                    </div>
                </div>

                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                        $total = max(count($category['checks']), 1);
                        $passCount = count(
                            array_filter(
                                $category['checks'],
                                fn($c) => audit_check_variant($c['status']) === 'success',
                            ),
                        );
                        $warnCount = count(
                            array_filter(
                                $category['checks'],
                                fn($c) => audit_check_variant($c['status']) === 'warning',
                            ),
                        );
                        $failCount = count(
                            array_filter($category['checks'], fn($c) => audit_check_variant($c['status']) === 'danger'),
                        );
                    ?>
                    <div class="checks-overview-row <?php echo e(!$loop->last ? 'mb-3' : ''); ?>">
                        <div class="d-flex align-items-center justify-content-between mb-1">
                            <span class="fw-medium small"><?php echo e($category['label']); ?></span>
                            <span class="text-secondary small font-mono"><?php echo e($passCount); ?>/<?php echo e($total); ?>

                                passed</span>
                        </div>
                        <div class="progress progress-thin" role="progressbar"
                            aria-label="<?php echo e($category['label']); ?> checks breakdown" aria-valuenow="<?php echo e($passCount); ?>"
                            aria-valuemin="0" aria-valuemax="<?php echo e($total); ?>">
                            <div class="progress-bar bg-success" style="width: <?php echo e(($passCount / $total) * 100); ?>%"
                                title="Pass: <?php echo e($passCount); ?>"></div>
                            <div class="progress-bar bg-warning" style="width: <?php echo e(($warnCount / $total) * 100); ?>%"
                                title="Warning: <?php echo e($warnCount); ?>"></div>
                            <div class="progress-bar bg-danger" style="width: <?php echo e(($failCount / $total) * 100); ?>%"
                                title="Fail: <?php echo e($failCount); ?>"></div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </section>

    
    <section class="mb-4">
        <span class="report-eyebrow">05 / Detailed Results</span>

        <div class="accordion" id="categoryAccordion">
            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php $variant = audit_score_variant($category['score']); ?>
                <div class="accordion-item">
                    <h3 class="accordion-header" id="heading-<?php echo e($category['key']); ?>">
                        <button class="accordion-button <?php echo e(!$loop->first ? 'collapsed' : ''); ?>" type="button"
                            data-bs-toggle="collapse" data-bs-target="#collapse-<?php echo e($category['key']); ?>"
                            aria-expanded="<?php echo e($loop->first ? 'true' : 'false'); ?>"
                            aria-controls="collapse-<?php echo e($category['key']); ?>">
                            <span
                                class="summary-card-icon bg-<?php echo e($variant); ?>-subtle text-<?php echo e($variant); ?>-emphasis me-3">
                                <?php echo e($category['abbr']); ?>

                            </span>
                            <span class="flex-grow-1"><?php echo e($category['label']); ?></span>
                            <span
                                class="badge font-mono bg-<?php echo e($variant); ?>-subtle text-<?php echo e($variant); ?>-emphasis me-3">
                                <?php echo e($category['score'] ?? '—'); ?>/100
                            </span>
                        </button>
                    </h3>
                    <div id="collapse-<?php echo e($category['key']); ?>"
                        class="accordion-collapse collapse <?php echo e($loop->first ? 'show' : ''); ?>"
                        aria-labelledby="heading-<?php echo e($category['key']); ?>" data-bs-parent="#categoryAccordion">
                        <div class="accordion-body">
                            <p class="text-secondary"><?php echo e($category['summary']); ?></p>

                            <ul class="list-group list-group-flush mb-3">
                                <?php $__currentLoopData = $category['checks']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $check): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php
                                        $location = $check['location'] ?? null;
                                        $pageUrl = $location['page_url'] ?? null;
                                        $affectedElements = $location['affected_elements'] ?? [];
                                        $checkUid = $category['key'] . '-' . $loop->index;
                                    ?>
                                    <li
                                        class="check-item check-item-<?php echo e(audit_check_variant($check['status'])); ?> list-group-item d-flex align-items-start justify-content-between gap-3 ps-3 pe-2 py-3">
                                        <div class="flex-grow-1">
                                            <p class="fw-medium mb-0"><?php echo e($check['name']); ?></p>
                                            <p class="text-secondary small mb-0"><?php echo e($check['note']); ?></p>

                                            
                                            <?php if(!empty($pageUrl)): ?>
                                                <p class="text-secondary small mb-0">
                                                    <a href="<?php echo e($pageUrl); ?>" target="_blank"
                                                        rel="noopener noreferrer"
                                                        class="check-location-link"><?php echo e($pageUrl); ?></a>
                                                </p>
                                            <?php endif; ?>

                                            
                                            <?php if(!empty($affectedElements)): ?>
                                                <button class="btn btn-link btn-sm p-0 mt-1 small text-decoration-none"
                                                    type="button" data-bs-toggle="collapse"
                                                    data-bs-target="#check-location-<?php echo e($checkUid); ?>"
                                                    aria-expanded="false"
                                                    aria-controls="check-location-<?php echo e($checkUid); ?>">
                                                    <?php echo e(count($affectedElements)); ?>

                                                    affected element<?php echo e(count($affectedElements) > 1 ? 's' : ''); ?>

                                                </button>
                                                <div class="collapse mt-1" id="check-location-<?php echo e($checkUid); ?>">
                                                    <ul class="mb-0 ps-3 check-location-list">
                                                        <?php $__currentLoopData = $affectedElements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $element): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <?php
                                                                $bits = array_filter([
                                                                    $element['domPath'] ?? null,
                                                                    $element['detail'] ?? null,
                                                                ]);
                                                            ?>
                                                            <?php if(!empty($bits) || !empty($element['url'])): ?>
                                                                <li class="text-secondary small">
                                                                    <?php if(!empty($bits)): ?>
                                                                        <?php echo e(implode(' — ', $bits)); ?>

                                                                    <?php endif; ?>
                                                                    <?php if(!empty($element['url'])): ?>
                                                                        <a href="<?php echo e($element['url']); ?>" target="_blank"
                                                                            rel="noopener noreferrer"><?php echo e($element['url']); ?></a>
                                                                    <?php endif; ?>
                                                                </li>
                                                            <?php endif; ?>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </ul>
                                                </div>
                                            <?php endif; ?>
                                        </div>
                                        <span
                                            class="badge check-status-pill bg-<?php echo e(audit_check_variant($check['status'])); ?>-subtle text-<?php echo e(audit_check_variant($check['status'])); ?>-emphasis text-capitalize flex-shrink-0">
                                            <?php $checkVariant = audit_check_variant($check['status']); ?>
                                            <?php if($checkVariant === 'success'): ?>
                                                <svg width="11" height="11" viewBox="0 0 16 16"
                                                    fill="none" aria-hidden="true">
                                                    <path d="M13.5 4.5L6.5 12L2.5 8.2" stroke="currentColor"
                                                        stroke-width="2" stroke-linecap="round"
                                                        stroke-linejoin="round" />
                                                </svg>
                                            <?php elseif($checkVariant === 'warning'): ?>
                                                <svg width="11" height="11" viewBox="0 0 16 16"
                                                    fill="none" aria-hidden="true">
                                                    <path d="M8 1.5L15 14H1L8 1.5Z" stroke="currentColor"
                                                        stroke-width="1.4" stroke-linejoin="round" />
                                                    <path d="M8 6.25V9.75" stroke="currentColor" stroke-width="1.4"
                                                        stroke-linecap="round" />
                                                    <circle cx="8" cy="11.75" r="0.85"
                                                        fill="currentColor" />
                                                </svg>
                                            <?php else: ?>
                                                <svg width="11" height="11" viewBox="0 0 16 16"
                                                    fill="none" aria-hidden="true">
                                                    <path d="M3 3L13 13M13 3L3 13" stroke="currentColor"
                                                        stroke-width="2" stroke-linecap="round" />
                                                </svg>
                                            <?php endif; ?>
                                            <?php echo e($check['status']); ?>

                                        </span>
                                    </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>

                            
                            <?php if(!empty($category['recommendations'])): ?>
                                <button class="btn btn-sm btn-outline-secondary" type="button"
                                    data-bs-toggle="collapse"
                                    data-bs-target="#recommendations-<?php echo e($category['key']); ?>" aria-expanded="false"
                                    aria-controls="recommendations-<?php echo e($category['key']); ?>">
                                    View recommendations (<?php echo e(count($category['recommendations'])); ?>)
                                </button>
                                <div class="collapse mt-3" id="recommendations-<?php echo e($category['key']); ?>">
                                    <ul class="mb-0 ps-3">
                                        <?php $__currentLoopData = $category['recommendations']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $recommendation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li class="small mb-1"><?php echo e($recommendation); ?></li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </section>

</div>
<?php /**PATH D:\laragon\www\MsnVersionUpdate-09-To-13\analytics\resources\views\audit\partials\dashboard-components.blade.php ENDPATH**/ ?>