

<?php $__env->startSection('title', 'Verify Email — Website Audit & Analysis Platform'); ?>

<?php $__env->startSection('content'); ?>
    <h1 class="h4 fw-semibold mb-1">Verify your email</h1>
    <p class="text-secondary mb-4">
        Thanks for signing up! Before getting started, please verify your email address by clicking the link
        we just emailed to you. If you didn't receive it, we can send another.
    </p>

    <?php if(session('status') === 'verification-link-sent'): ?>
        <div class="alert alert-success small">
            A new verification link has been sent to the email address you provided during registration.
        </div>
    <?php endif; ?>

    <div class="d-flex flex-column flex-sm-row gap-2">
        <form method="POST" action="<?php echo e(route('verification.send')); ?>" class="flex-grow-1">
            <?php echo csrf_field(); ?>
            <button type="submit" class="btn btn-primary w-100">Resend Verification Email</button>
        </form>

        <form method="POST" action="<?php echo e(route('logout')); ?>">
            <?php echo csrf_field(); ?>
            <button type="submit" class="btn btn-outline-secondary w-100">Log Out</button>
        </form>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.guest', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\laragon\www\MsnVersionUpdate-09-To-13\analytics\resources\views\auth\verify-email.blade.php ENDPATH**/ ?>