
<div class="dashboard">

    
    <section class="mb-4">
        <span class="report-eyebrow">01 / Overall Score</span>

        <div class="card overall-score-card" style="position: relative; overflow: hidden;">
            
            <svg class="overall-score-watermark" viewBox="0 0 200 200" fill="none" xmlns="http://www.w3.org/2000/svg"
                aria-hidden="true" focusable="false"
                style="position: absolute; top: -3rem; right: -3rem; width: 17rem; height: 17rem; max-width: 40%; color: var(--audit-primary); opacity: 0.04; pointer-events: none; z-index: 0;">
                <path d="M100 6 L178 34 V96 C178 140 145 176 100 194 C55 176 22 140 22 96 V34 Z" fill="currentColor" />
                <path d="M64 100 L88 126 L138 72" stroke="var(--audit-surface)" stroke-width="14" stroke-linecap="round"
                    stroke-linejoin="round" fill="none" />
            </svg>
            <div class="card-body p-4 p-lg-5" style="position: relative; z-index: 1;">
                <div class="row g-4 align-items-center">
                    <div class="col-12 col-lg-4 text-center">
                        <div class="score-gauge"
                            style="--gauge-pct: <?php echo e($overallScore ?? 0); ?>; --gauge-color: <?php echo e(audit_score_color_var($overallScore)); ?>;"
                            role="img" aria-label="Overall score <?php echo e($overallScore ?? 'not available'); ?> out of 100">
                            <div class="score-gauge-inner">
                                <span class="score-gauge-value"><?php echo e($overallScore ?? '—'); ?></span>
                                <span class="score-gauge-max">/ 100</span>
                            </div>
                        </div>

                        <div class="d-flex align-items-center justify-content-center gap-2 mt-3">
                            <span class="grade-seal" style="color: <?php echo e(audit_score_color_var($overallScore)); ?>;">
                                <?php echo e(audit_score_grade_letter($overallScore)); ?>

                            </span>
                            <span
                                class="badge rounded-pill bg-<?php echo e(audit_score_variant($overallScore)); ?>-subtle text-<?php echo e(audit_score_variant($overallScore)); ?>-emphasis px-3 py-2">
                                <?php echo e(audit_score_label($overallScore)); ?>

                            </span>
                        </div>
                    </div>

                    <div class="col-12 col-lg-8">
                        <div class="row row-cols-2 row-cols-md-4 g-3">
                            <div class="col overall-score-meta">
                                <dt>Website</dt>
                                <dd class="text-truncate" title="<?php echo e(display_host($audit->url)); ?>">
                                    <?php echo e(display_host($audit->url)); ?></dd>
                            </div>
                            <div class="col overall-score-meta">
                                <dt>Status</dt>
                                <dd>
                                    <span class="badge <?php echo e(audit_status_badge_class($audit->status)); ?>">
                                        <?php echo e(audit_status_label($audit->status)); ?>

                                    </span>
                                </dd>
                            </div>
                            <div class="col overall-score-meta">
                                <dt>Categories Audited</dt>
                                <dd class="font-mono"><?php echo e(count($categories)); ?></dd>
                            </div>
                            <div class="col overall-score-meta">
                                <dt>Generated</dt>
                                <dd><?php echo e($generatedAt); ?></dd>
                            </div>
                        </div>

                        <hr class="my-4" style="border-color: var(--audit-border);">

                        <div class="row row-cols-2 row-cols-sm-3 g-3">
                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="col">
                                    <div class="d-flex align-items-center gap-2">
                                        <span class="rounded-circle flex-shrink-0"
                                            style="width: 0.55rem; height: 0.55rem; background: <?php echo e(audit_score_color_var($category['score'])); ?>;"></span>
                                        <span class="small text-truncate"><?php echo e($category['label']); ?></span>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    
    <section>
        <span class="report-eyebrow">02 / Category Breakdown</span>

        <div class="row row-cols-1 row-cols-sm-2 row-cols-lg-4 g-4">
            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php $variant = audit_score_variant($category['score']); ?>
                <div class="col">
                    <div class="card summary-card h-100"
                        style="--gauge-color: <?php echo e(audit_score_color_var($category['score'])); ?>;">
                        <div class="card-body d-flex flex-column">
                            <div class="d-flex align-items-start justify-content-between mb-3">
                                <div>
                                    <span
                                        class="summary-card-icon bg-<?php echo e($variant); ?>-subtle text-<?php echo e($variant); ?>-emphasis">
                                        <?php echo e($category['abbr']); ?>

                                    </span>
                                    <h3 class="h6 mt-2 mb-0"><?php echo e($category['label']); ?></h3>
                                    <?php if($category['grade']): ?>
                                        <span class="text-secondary small">Grade <?php echo e($category['grade']); ?></span>
                                    <?php endif; ?>
                                </div>

                                <div class="mini-ring"
                                    style="--ring-pct: <?php echo e($category['score'] ?? 0); ?>; --gauge-color: <?php echo e(audit_score_color_var($category['score'])); ?>;"
                                    role="img"
                                    aria-label="<?php echo e($category['label']); ?> score <?php echo e($category['score'] ?? 'not available'); ?> out of 100">
                                    <span class="mini-ring-value"><?php echo e($category['score'] ?? '—'); ?></span>
                                </div>
                            </div>

                            <p class="summary-card-summary mb-0 mt-auto"><?php echo e($category['summary']); ?></p>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </section>

</div>
<?php /**PATH D:\laragon\www\MsnVersionUpdate-09-To-13\analytics\resources\views\audit\partials\dashboard.blade.php ENDPATH**/ ?>