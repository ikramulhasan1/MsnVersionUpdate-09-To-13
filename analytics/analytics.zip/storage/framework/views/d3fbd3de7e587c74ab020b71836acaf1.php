

<?php $__env->startSection('title', 'Edit Access — ' . $targetUser->name); ?>

<?php $__env->startSection('content'); ?>
    <section class="container py-4" style="max-width: 680px;">
        <p class="text-secondary small mb-1">Admin</p>
        <h1 class="h4 fw-semibold mb-1">Edit Access</h1>
        <p class="text-secondary mb-4"><?php echo e($targetUser->name); ?> &middot; <?php echo e($targetUser->email); ?></p>

        <form method="POST" action="<?php echo e(route('admin.users.update', $targetUser)); ?>">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>

            <div class="card mb-4">
                <div class="card-body p-4">
                    <h2 class="h6 fw-semibold mb-1">Role</h2>
                    
                    <p class="text-secondary small mb-3">
                        Admin has every permission automatically. Employee starts with none — grant exactly
                        what this person needs below. User gets the standard customer feature set.
                    </p>

                    <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="form-check mb-2">
                            <input class="form-check-input" type="radio" name="role" id="role-<?php echo e($role->id); ?>"
                                value="<?php echo e($role->name); ?>" <?php if(in_array($role->name, $userRoleNames, true)): echo 'checked'; endif; ?>
                                required>
                            <label class="form-check-label" for="role-<?php echo e($role->id); ?>">
                                <?php echo e($role->name); ?>

                            </label>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>

            <div class="card mb-4">
                <div class="card-body p-4">
                    <h2 class="h6 fw-semibold mb-1">Individual Permissions</h2>
                    <p class="text-secondary small mb-3">
                        These apply on top of the role above — useful mainly for an Employee, whose role
                        grants nothing by default. Admin already has everything regardless of what's checked
                        here.
                    </p>

                    <?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="form-check mb-2">
                            <input class="form-check-input" type="checkbox" name="permissions[]"
                                id="permission-<?php echo e($permission->id); ?>" value="<?php echo e($permission->name); ?>"
                                <?php if(in_array($permission->name, $userPermissionNames, true)): echo 'checked'; endif; ?>>
                            <label class="form-check-label" for="permission-<?php echo e($permission->id); ?>">
                                <?php echo e(ucwords(str_replace('-', ' ', $permission->name))); ?>

                            </label>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>

            <div class="d-flex gap-2">
                <button type="submit" class="btn btn-primary">Save Changes</button>
                <a href="<?php echo e(route('admin.users.index')); ?>" class="btn btn-outline-secondary">Cancel</a>
            </div>
        </form>

        
        <?php if($pendingUpgradeRequests->isNotEmpty()): ?>
            <div class="alert alert-warning small mb-4">
                <strong><?php echo e($targetUser->name); ?></strong> has requested:
                <?php $__currentLoopData = $pendingUpgradeRequests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $request): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php echo e($request->plan->name); ?><?php echo e(! $loop->last ? ', ' : ''); ?>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                — assigning that plan below marks the request fulfilled automatically.
            </div>
        <?php endif; ?>

        <div class="card mb-4">
            <div class="card-body p-4">
                <h2 class="h6 fw-semibold mb-1">Plan</h2>
                <p class="text-secondary small mb-3">
                    Assign any plan directly — including a custom expiry below, independent of that
                    plan's own default duration. Leave "No Plan" selected to remove this person's plan
                    entirely.
                </p>

                <form method="POST" action="<?php echo e(route('admin.users.update-plan', $targetUser)); ?>">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>

                    <div class="mb-3">
                        <label for="plan_id" class="form-label">Plan</label>
                        <select class="form-select" id="plan_id" name="plan_id">
                            <option value="" <?php if($targetUser->plan_id === null): echo 'selected'; endif; ?>>No Plan</option>
                            <?php $__currentLoopData = $plans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $plan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($plan->id); ?>" <?php if($targetUser->plan_id === $plan->id): echo 'selected'; endif; ?>>
                                    <?php echo e($plan->name); ?> (<?php echo e($plan->priceLabel()); ?>)
                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                    <div class="mb-3">
                        <label for="trial_ends_at" class="form-label">
                            Expires On <span class="text-secondary small">(blank = use the plan's own default, or never expires for a plan with no duration)</span>
                        </label>
                        <input type="date" class="form-control" id="trial_ends_at" name="trial_ends_at"
                            value="<?php echo e($targetUser->trial_ends_at?->format('Y-m-d')); ?>" style="max-width: 220px;">
                    </div>

                    <?php if($targetUser->plan !== null): ?>
                        <p class="text-secondary small mb-3">
                            Current: <strong><?php echo e($targetUser->plan->name); ?></strong>
                            <?php if($targetUser->trial_ends_at !== null): ?>
                                &mdash; expires <?php echo e($targetUser->trial_ends_at->diffForHumans()); ?>

                            <?php endif; ?>
                        </p>
                    <?php endif; ?>

                    <button type="submit" class="btn btn-primary btn-sm">Save Plan</button>
                </form>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\laragon\www\MsnVersionUpdate-09-To-13\analytics\resources\views\admin\users\edit.blade.php ENDPATH**/ ?>