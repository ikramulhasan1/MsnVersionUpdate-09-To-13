<?php $__env->startSection('title', 'Audit Result — ' . display_host($audit->url)); ?>

<?php $__env->startSection('content'); ?>
    <section class="result-header">
        <div class="container">
            <?php if(session('status')): ?>
                <div class="alert alert-success"><?php echo e(session('status')); ?></div>
            <?php endif; ?>

            <div class="d-flex flex-wrap align-items-center justify-content-between gap-3">
                <div>
                    <p class="text-secondary small mb-1">Audit for</p>
                    <h1 class="h3 mb-0"><?php echo e(display_host($audit->url)); ?></h1>
                    <a href="<?php echo e($audit->url); ?>" target="_blank" rel="noopener noreferrer" class="small text-decoration-none">
                        <?php echo e($audit->url); ?>

                    </a>
                </div>
                <div class="d-flex align-items-center gap-2">
                    <span class="badge <?php echo e(audit_status_badge_class($audit->status)); ?> fs-6 px-3 py-2">
                        <?php echo e(audit_status_label($audit->status)); ?>

                    </span>
                    <button type="button" class="btn btn-outline-secondary btn-sm d-print-none" onclick="window.print()">
                        Print Report
                    </button>
                    <?php if($audit->status === \App\Audit\Enums\AuditStatus::COMPLETED): ?>
                        <a href="<?php echo e(route('audits.export.excel', $audit)); ?>"
                            class="btn btn-outline-secondary btn-sm d-print-none">
                            Download Excel Report
                        </a>
                    <?php else: ?>
                        <button type="button" class="btn btn-outline-secondary btn-sm d-print-none" disabled
                            title="Available once the audit finishes">
                            Download Excel Report
                        </button>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </section>

    <section class="container dashboard-section">
        <?php if(!$audit->status->isFinished()): ?>
            <div class="card audit-pending-card mx-auto text-center" id="audit-progress-card"
                data-audit-progress-url="<?php echo e(route('audits.progress', $audit)); ?>"
                data-audit-show-url="<?php echo e(route('audits.show', $audit)); ?>">
                <div class="card-body py-5">
                    <div class="progress mb-3" role="progressbar" aria-label="Audit progress" aria-valuenow="0"
                        aria-valuemin="0" aria-valuemax="100" style="height: 0.75rem;">
                        <div id="audit-progress-bar" class="progress-bar progress-bar-striped progress-bar-animated"
                            style="width: 0%"></div>
                    </div>
                    <p class="fw-semibold mb-1"><span id="audit-progress-percent">0</span>%</p>
                    <h2 class="h5" id="audit-progress-label">
                        <?php echo e(audit_status_label($audit->status)); ?>&hellip;
                    </h2>
                    
                    <p class="text-secondary small fw-medium mb-2" id="audit-progress-eta">
                        Estimating time remaining&hellip;
                    </p>
                    <p class="text-secondary mb-0">
                        This usually takes a few seconds. The page updates automatically &mdash; no need to refresh.
                    </p>
                    <p class="text-warning small mt-3 mb-0 d-none" id="audit-progress-stall-hint">
                        This is taking much longer than usual. It may be stuck &mdash; you're welcome to keep
                        waiting, or check back later.
                    </p>
                </div>
            </div>


            <?php $__env->startPush('scripts'); ?>
                <script src="<?php echo e(asset('js/audit-progress.js')); ?>"></script>
            <?php $__env->stopPush(); ?>
        <?php elseif($audit->status === \App\Audit\Enums\AuditStatus::FAILED): ?>
            <div class="card mx-auto text-center">
                <div class="card-body py-5">
                    <h2 class="h5">This audit couldn't be completed</h2>
                    <p class="text-secondary mb-0">Something went wrong while analyzing this website.</p>
                </div>
            </div>
        <?php else: ?>
            <?php echo $__env->make('audit.partials.dashboard', [
                'audit' => $audit,
                'overallScore' => $overallScore,
                'categories' => $categories,
                'generatedAt' => $audit->updated_at?->format('M j, Y \a\t g:i A') ?? 'just now',
            ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

            <?php echo $__env->make('audit.partials.dashboard-components', [
                'categories' => $categories,
            ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

            
            <?php if($prospectQualification): ?>
                <?php
                    $qualificationVariant = audit_score_variant($prospectQualification->score);
                    $bucketMaxPoints = [
                        'website_issues' => 60,
                        'business_signals' => 25,
                        'technology_upgrade_opportunities' => 15,
                    ];
                ?>
                <section class="mt-4">
                    <div class="card">
                        <div class="card-body p-4">
                            <div class="d-flex flex-wrap align-items-center justify-content-between gap-2 mb-3">
                                <h2 class="h5 mb-0">Prospect Qualification</h2>
                                <div class="d-flex align-items-center gap-3">
                                    <span
                                        class="badge bg-<?php echo e($qualificationVariant); ?>-subtle text-<?php echo e($qualificationVariant); ?>-emphasis">
                                        <?php echo e($prospectQualification->priority()); ?> priority
                                    </span>
                                    <span
                                        class="badge bg-<?php echo e($qualificationVariant); ?>-subtle text-<?php echo e($qualificationVariant); ?>-emphasis">
                                        <?php echo e($prospectQualification->score); ?>/100
                                    </span>
                                    <?php if($prospectQualification->grade): ?>
                                        <span class="grade-seal"
                                            style="color: <?php echo e(audit_score_color_var($prospectQualification->score)); ?>;">
                                            <?php echo e($prospectQualification->grade); ?>

                                        </span>
                                    <?php endif; ?>
                                </div>
                            </div>

                            <p class="text-secondary"><?php echo e($prospectQualification->summary); ?></p>

                            <ul class="list-group list-group-flush mb-0">
                                <?php $__currentLoopData = $prospectQualification->breakdown; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bucket => $points): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php
                                        $bucketMax = $bucketMaxPoints[$bucket] ?? max($points, 1);
                                        $bucketPct = $bucketMax > 0 ? min(100, ($points / $bucketMax) * 100) : 0;
                                        $bucketLabel = ucwords(str_replace('_', ' ', $bucket));
                                    ?>
                                    <li class="list-group-item d-flex flex-column gap-1 px-0 py-2">
                                        <div class="d-flex align-items-center justify-content-between">
                                            <span class="fw-medium small"><?php echo e($bucketLabel); ?></span>
                                            <span class="text-secondary small font-mono"><?php echo e($points); ?>

                                                / <?php echo e($bucketMax); ?> pts</span>
                                        </div>
                                        <div class="progress progress-thin" role="progressbar"
                                            aria-label="<?php echo e($bucketLabel); ?> points" aria-valuenow="<?php echo e($points); ?>"
                                            aria-valuemin="0" aria-valuemax="<?php echo e($bucketMax); ?>">
                                            <div class="progress-bar bg-<?php echo e($qualificationVariant); ?>"
                                                style="width: <?php echo e($bucketPct); ?>%"></div>
                                        </div>
                                    </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    </div>
                </section>
            <?php endif; ?>

            <?php if($outreachDraft): ?>
                <section class="mt-4">
                    <div class="card outreach-card">
                        <div
                            class="outreach-card-header d-flex flex-wrap align-items-center justify-content-between gap-2 px-4 py-3">
                            <div class="d-flex align-items-center gap-2">
                                <h2 class="h5 mb-0">Outreach Draft</h2>
                                <span class="badge bg-secondary-subtle text-secondary-emphasis">
                                    Draft — for human review, never sent automatically
                                </span>
                            </div>
                            <button type="button" class="btn btn-sm btn-outline-secondary outreach-copy-btn"
                                data-outreach-subject="<?php echo e($outreachDraft->subject); ?>"
                                data-outreach-body="<?php echo e($outreachDraft->body); ?>">
                                <svg width="13" height="13" viewBox="0 0 16 16" fill="none" aria-hidden="true"
                                    class="me-1">
                                    <rect x="5.5" y="5.5" width="8.5" height="8.5" rx="1.3" stroke="currentColor"
                                        stroke-width="1.3" />
                                    <path
                                        d="M10.5 5.5V3.8A1.3 1.3 0 0 0 9.2 2.5H3.3A1.3 1.3 0 0 0 2 3.8v6a1.3 1.3 0 0 0 1.3 1.3H5.5"
                                        stroke="currentColor" stroke-width="1.3" />
                                </svg>
                                <span class="outreach-copy-label">Copy</span>
                            </button>
                        </div>

                        <div class="outreach-card-subject-row px-4 py-2">
                            <span class="outreach-card-field-label">Subject</span>
                            <span class="outreach-card-field-value"><?php echo e($outreachDraft->subject); ?></span>
                        </div>

                        <div class="card-body p-4">
                            <pre class="outreach-draft-body mb-3"><?php echo e($outreachDraft->body); ?></pre>

                            <?php if(!empty($outreachDraft->basedOnIssues)): ?>
                                <p class="text-secondary small mb-1">Based on:</p>
                                <ul class="mb-0 ps-3">
                                    <?php $__currentLoopData = $outreachDraft->basedOnIssues; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $issue): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li class="small mb-1"><?php echo e($issue); ?></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            <?php endif; ?>
                        </div>
                    </div>
                </section>
            <?php endif; ?>
        <?php endif; ?>
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.4/dist/chart.umd.min.js"></script>
    <script src="<?php echo e(asset('js/dashboard-charts.js')); ?>"></script>
    <?php if($outreachDraft): ?>
        <script src="<?php echo e(asset('js/outreach-copy.js')); ?>"></script>
    <?php endif; ?>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\laragon\www\MsnVersionUpdate-09-To-13\analytics\resources\views\audit\result.blade.php ENDPATH**/ ?>