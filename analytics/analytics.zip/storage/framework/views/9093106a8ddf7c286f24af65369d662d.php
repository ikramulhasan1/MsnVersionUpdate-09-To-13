<?php $__env->startSection('title', 'Audit Result — ' . display_host($audit->url)); ?>

<?php $__env->startSection('content'); ?>
    <section class="result-header">
        <div class="container">
            <?php if(session('status')): ?>
                <div class="alert alert-success"><?php echo e(session('status')); ?></div>
            <?php endif; ?>

            <div class="d-flex flex-wrap align-items-center justify-content-between gap-3">
                <div>
                    <p class="text-secondary small mb-1">Audit for</p>
                    <h1 class="h3 mb-0"><?php echo e(display_host($audit->url)); ?></h1>
                    <a href="<?php echo e($audit->url); ?>" target="_blank" rel="noopener noreferrer" class="small text-decoration-none">
                        <?php echo e($audit->url); ?>

                    </a>
                </div>
                <div class="d-flex align-items-center gap-2">
                    <span class="badge <?php echo e(audit_status_badge_class($audit->status)); ?> fs-6 px-3 py-2">
                        <?php echo e(audit_status_label($audit->status)); ?>

                    </span>
                    
                    <button type="button" class="btn btn-outline-secondary btn-sm d-print-none" onclick="window.print()">
                        Print Report
                    </button>
                    <?php if($audit->status === \App\Audit\Enums\AuditStatus::COMPLETED): ?>
                        <a href="<?php echo e(route('audits.export', $audit)); ?>"
                            class="btn btn-outline-secondary btn-sm d-print-none">
                            Download PDF Report
                        </a>
                        <a href="<?php echo e(route('audits.export.excel', $audit)); ?>"
                            class="btn btn-outline-secondary btn-sm d-print-none">
                            Download Excel Report
                        </a>
                    <?php else: ?>
                        <button type="button" class="btn btn-outline-secondary btn-sm d-print-none" disabled
                            title="Available once the audit finishes">
                            Download PDF Report
                        </button>
                        <button type="button" class="btn btn-outline-secondary btn-sm d-print-none" disabled
                            title="Available once the audit finishes">
                            Download Excel Report
                        </button>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </section>

    <section class="container dashboard-section">
        <?php if(!$audit->status->isFinished()): ?>
            <div class="card audit-pending-card mx-auto text-center" id="audit-progress-card"
                data-audit-progress-url="<?php echo e(route('audits.progress', $audit)); ?>"
                data-audit-show-url="<?php echo e(route('audits.show', $audit)); ?>">
                <div class="card-body py-5">
                    <div class="progress mb-3" role="progressbar" aria-label="Audit progress" aria-valuenow="0"
                        aria-valuemin="0" aria-valuemax="100" style="height: 0.75rem;">
                        <div id="audit-progress-bar" class="progress-bar progress-bar-striped progress-bar-animated"
                            style="width: 0%"></div>
                    </div>
                    <p class="fw-semibold mb-1"><span id="audit-progress-percent">0</span>%</p>
                    <h2 class="h5" id="audit-progress-label">
                        <?php echo e(audit_status_label($audit->status)); ?>&hellip;
                    </h2>
                    
                    <p class="text-secondary small fw-medium mb-2" id="audit-progress-eta">
                        Estimating time remaining&hellip;
                    </p>
                    <p class="text-secondary mb-0">
                        This usually takes a few seconds. The page updates automatically &mdash; no need to refresh.
                    </p>
                    <p class="text-warning small mt-3 mb-0 d-none" id="audit-progress-stall-hint">
                        This is taking much longer than usual. It may be stuck &mdash; you're welcome to keep
                        waiting, or check back later.
                    </p>
                </div>
            </div>


            <?php $__env->startPush('scripts'); ?>
                <script src="<?php echo e(asset('js/audit-progress.js')); ?>"></script>
            <?php $__env->stopPush(); ?>
        <?php elseif($audit->status === \App\Audit\Enums\AuditStatus::FAILED): ?>
            <div class="card mx-auto text-center">
                <div class="card-body py-5">
                    <h2 class="h5">This audit couldn't be completed</h2>
                    <p class="text-secondary mb-0">Something went wrong while analyzing this website.</p>
                </div>
            </div>
        <?php else: ?>
            
            <?php echo $__env->make('audit.partials.full-report', [
                'audit' => $audit,
                'categories' => $categories,
                'overallScore' => $overallScore,
                'prospectQualification' => $prospectQualification,
                'outreachDraft' => $outreachDraft,
                'generatedAt' => $audit->updated_at?->format('M j, Y \a\t g:i A') ?? 'just now',
            ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <?php endif; ?>
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.4/dist/chart.umd.min.js"></script>
    <script src="<?php echo e(asset('js/dashboard-charts.js')); ?>"></script>
    <?php if($outreachDraft): ?>
        <script src="<?php echo e(asset('js/outreach-copy.js')); ?>"></script>
    <?php endif; ?>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\laragon\www\MsnVersionUpdate-09-To-13\analytics\resources\views\audit\result.blade.php ENDPATH**/ ?>