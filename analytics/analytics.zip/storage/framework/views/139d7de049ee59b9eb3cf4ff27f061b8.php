
<?php
    $displayName = $website->business_name ?? $website->domain;

    $opportunityResult = (new \App\Discovery\Scoring\OpportunityScorer())->score($website);
    $opportunityLevel = \App\Discovery\Enums\OpportunityLevel::fromScore($opportunityResult->score);
    $opportunityColor = match ($opportunityLevel) {
        \App\Discovery\Enums\OpportunityLevel::HIGH => 'var(--audit-danger)',
        \App\Discovery\Enums\OpportunityLevel::MEDIUM => 'var(--audit-warning)',
        \App\Discovery\Enums\OpportunityLevel::LOW => 'var(--audit-success)',
    };

    // Each technology column can hold several comma-joined display
    // names (see App\Discovery\Jobs\EnrichDiscoveredWebsiteJob::technologyColumnValue()
    // — e.g. framework might be "React, Bootstrap") — split every
    // column back into individual pills rather than showing the raw
    // joined string as one long pill.
    $technologies = collect([$website->cms, $website->framework, $website->ecommerce_platform, $website->cdn])
        ->filter()
        ->flatMap(fn (string $value): array => array_map('trim', explode(',', $value)))
        ->filter()
        ->unique()
        ->values();

    $scoreRings = [
        'SEO' => $website->seo_score,
        'Perf' => $website->performance_score,
        'Sec' => $website->security_score,
        'A11y' => $website->accessibility_score,
    ];
?>
<div class="card result-card">
    <div class="card-body p-4">
        <div class="d-flex flex-wrap align-items-start justify-content-between gap-3 mb-3">
            <div>
                <h3 class="h6 mb-1">
                    <a href="<?php echo e(route('discovery.show', $website)); ?>" class="text-decoration-none">
                        <?php echo e($displayName); ?>

                    </a>
                </h3>
                <?php if($website->business_name): ?>
                    <p class="text-secondary small mb-2"><?php echo e($website->domain); ?></p>
                <?php endif; ?>

                <div class="d-flex flex-wrap gap-2">
                    <?php if($website->industry): ?>
                        <span class="badge bg-secondary-subtle text-secondary-emphasis">
                            <?php echo e($website->industry); ?>

                        </span>
                    <?php endif; ?>
                    <?php if($website->country): ?>
                        <span class="badge bg-secondary-subtle text-secondary-emphasis">
                            <?php echo e($website->country); ?>

                        </span>
                    <?php endif; ?>
                    <?php if($website->city): ?>
                        <span class="badge bg-secondary-subtle text-secondary-emphasis">
                            <?php echo e($website->city); ?>

                        </span>
                    <?php endif; ?>
                </div>
            </div>

            <div class="d-flex align-items-center gap-2 flex-shrink-0"
                title="<?php echo e($opportunityResult->summary); ?>">
                <span class="opportunity-dot" style="background-color: <?php echo e($opportunityColor); ?>;"></span>
                <span class="small fw-medium"><?php echo e($opportunityLevel->label()); ?> Opportunity
                    (<?php echo e($opportunityResult->score); ?>/100)</span>
            </div>
        </div>

        <?php if($technologies->isNotEmpty()): ?>
            <div class="d-flex flex-wrap gap-2 mb-3">
                <?php $__currentLoopData = $technologies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $technology): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <span class="tech-pill"><?php echo e($technology); ?></span>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        <?php endif; ?>

        <div class="result-card-rings mb-3">
            <?php $__currentLoopData = $scoreRings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $label => $score): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="text-center">
                    <div class="mini-ring"
                        style="--ring-pct: <?php echo e($score ?? 0); ?>; --gauge-color: <?php echo e(audit_score_color_var($score)); ?>;"
                        role="img"
                        aria-label="<?php echo e($label); ?> score <?php echo e($score ?? 'not available'); ?> out of 100">
                        <span class="mini-ring-value"><?php echo e($score ?? '—'); ?></span>
                    </div>
                    <p class="result-card-ring-label mb-0"><?php echo e($label); ?></p>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

        <div class="d-flex flex-wrap align-items-center gap-2 pt-3"
            style="border-top: 1px solid var(--audit-border);">
            <a href="<?php echo e($website->url); ?>" target="_blank" rel="noopener noreferrer"
                class="btn btn-sm btn-outline-secondary">
                View Website
            </a>

            
            <form method="POST" action="<?php echo e(route('audits.store')); ?>" class="d-inline">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="url" value="<?php echo e($website->url); ?>">
                <button type="submit" class="btn btn-sm btn-outline-primary">Audit Website</button>
            </form>

            <a href="<?php echo e(route('discovery.show', $website)); ?>" class="btn btn-sm btn-outline-secondary">
                View Details
            </a>

            <?php if($isWatched): ?>
                <form method="POST" action="<?php echo e(route('discovery.unwatch', $website)); ?>" class="d-inline">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button type="submit"
                        class="btn btn-sm btn-outline-secondary discovery-star-btn discovery-star-btn-active"
                        aria-pressed="true">
                        <?php echo $__env->make('discovery.partials.star-icon', ['filled' => true], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                        <span class="ms-1">Saved</span>
                    </button>
                </form>
            <?php else: ?>
                <a href="<?php echo e(route('discovery.watch', $website)); ?>"
                    class="btn btn-sm btn-outline-secondary discovery-star-btn" aria-pressed="false">
                    <?php echo $__env->make('discovery.partials.star-icon', ['filled' => false], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                    <span class="ms-1">Save</span>
                </a>
            <?php endif; ?>

            
            <div class="form-check ms-auto mb-0">
                <input class="form-check-input" type="checkbox" name="compare[]" value="<?php echo e($website->uuid); ?>"
                    id="discovery-compare-<?php echo e($website->uuid); ?>">
                <label class="form-check-label small" for="discovery-compare-<?php echo e($website->uuid); ?>">
                    Compare
                </label>
            </div>

            
                        
            <div class="form-check mb-0">
                <input class="form-check-input" type="checkbox" name="bulk_audit[]" value="<?php echo e($website->uuid); ?>"
                    id="discovery-bulk-audit-<?php echo e($website->uuid); ?>">
                <label class="form-check-label small" for="discovery-bulk-audit-<?php echo e($website->uuid); ?>">
                    Audit
                </label>
            </div>

            
            <form method="POST" action="<?php echo e(route('discovery.destroy', $website)); ?>" class="d-inline"
                onsubmit="return confirm('Permanently remove <?php echo e($website->domain); ?> from Website Discovery? This cannot be undone.');">
                <?php echo csrf_field(); ?>
                <?php echo method_field('DELETE'); ?>
                <button type="submit" class="btn btn-sm btn-outline-danger" title="Remove this website"
                    aria-label="Remove <?php echo e($website->domain); ?> from Website Discovery">
                    <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24"
                        fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"
                        stroke-linejoin="round" aria-hidden="true">
                        <polyline points="3 6 5 6 21 6"></polyline>
                        <path d="M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6"></path>
                        <path d="M10 11v6"></path>
                        <path d="M14 11v6"></path>
                        <path d="M9 6V4a2 2 0 0 1 2-2h2a2 2 0 0 1 2 2v2"></path>
                    </svg>
                </button>
            </form>
        </div>
    </div>
</div><?php /**PATH D:\laragon\www\MsnVersionUpdate-09-To-13\analytics\resources\views\discovery\partials\result-card.blade.php ENDPATH**/ ?>