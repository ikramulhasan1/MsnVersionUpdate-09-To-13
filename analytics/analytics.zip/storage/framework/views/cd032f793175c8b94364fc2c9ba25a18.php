

<?php $__env->startSection('title', $website->business_name ?? $website->domain); ?>

<?php
    $opportunityResult = (new \App\Discovery\Scoring\OpportunityScorer())->score($website);
    $serviceOpportunities = (new \App\Discovery\Scoring\ServiceOpportunityDetector())->detect($website);
    $opportunityLevel = \App\Discovery\Enums\OpportunityLevel::fromScore($opportunityResult->score);
    $opportunityColor = match ($opportunityLevel) {
        \App\Discovery\Enums\OpportunityLevel::HIGH => 'var(--audit-danger)',
        \App\Discovery\Enums\OpportunityLevel::MEDIUM => 'var(--audit-warning)',
        \App\Discovery\Enums\OpportunityLevel::LOW => 'var(--audit-success)',
    };

    $technologies = collect([$website->cms, $website->framework, $website->ecommerce_platform, $website->cdn])
        ->filter()
        ->flatMap(fn(string $value): array => array_map('trim', explode(',', $value)))
        ->filter()
        ->unique()
        ->values();

    $scoreRings = [
        'SEO' => $website->seo_score,
        'Performance' => $website->performance_score,
        'Security' => $website->security_score,
        'Accessibility' => $website->accessibility_score,
    ];
?>

<?php $__env->startSection('content'); ?>
    <section class="result-header">
        <div class="container">
            <?php if(session('status')): ?>
                <div class="alert alert-success"><?php echo e(session('status')); ?></div>
            <?php endif; ?>

            <div class="d-flex flex-wrap align-items-center justify-content-between gap-3">
                <div>
                    <p class="text-secondary small mb-1">Discovered Website</p>
                    <h1 class="h3 mb-0"><?php echo e($website->business_name ?? $website->domain); ?></h1>
                    <?php if($website->business_name): ?>
                        <p class="text-secondary small mb-0"><?php echo e($website->domain); ?></p>
                    <?php endif; ?>
                    <a href="<?php echo e($website->url); ?>" target="_blank" rel="noopener noreferrer" class="small text-decoration-none">
                        <?php echo e($website->url); ?>

                    </a>
                </div>
                <div class="d-flex align-items-center gap-2">
                    <form method="POST" action="<?php echo e(route('audits.store')); ?>" class="d-inline">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="url" value="<?php echo e($website->url); ?>">
                        <button type="submit" class="btn btn-outline-primary btn-sm">Audit Website</button>
                    </form>

                    <?php if($isWatched): ?>
                        <form method="POST" action="<?php echo e(route('discovery.unwatch', $website)); ?>">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit"
                                class="btn btn-outline-secondary btn-sm discovery-star-btn discovery-star-btn-active"
                                aria-pressed="true">
                                <?php echo $__env->make('discovery.partials.star-icon', ['filled' => true], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                                <span class="ms-1">Remove from Watchlist</span>
                            </button>
                        </form>
                    <?php else: ?>
                        <a href="<?php echo e(route('discovery.watch', $website)); ?>"
                            class="btn btn-outline-secondary btn-sm discovery-star-btn" aria-pressed="false">
                            <?php echo $__env->make('discovery.partials.star-icon', ['filled' => false], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                            <span class="ms-1">Add to Watchlist</span>
                        </a>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </section>

    <section class="container dashboard-section">
        <ul class="nav nav-tabs" id="discoveryDetailTabs" role="tablist">
            <li class="nav-item" role="presentation">
                <button class="nav-link active" id="discovery-tab-overview" data-bs-toggle="tab"
                    data-bs-target="#discovery-pane-overview" type="button" role="tab"
                    aria-controls="discovery-pane-overview" aria-selected="true">
                    Overview
                </button>
            </li>
            <li class="nav-item" role="presentation">
                <button class="nav-link" id="discovery-tab-seo" data-bs-toggle="tab" data-bs-target="#discovery-pane-seo"
                    type="button" role="tab" aria-controls="discovery-pane-seo" aria-selected="false">
                    SEO
                </button>
            </li>
            <li class="nav-item" role="presentation">
                <button class="nav-link" id="discovery-tab-performance" data-bs-toggle="tab"
                    data-bs-target="#discovery-pane-performance" type="button" role="tab"
                    aria-controls="discovery-pane-performance" aria-selected="false">
                    Performance
                </button>
            </li>
            <li class="nav-item" role="presentation">
                <button class="nav-link" id="discovery-tab-security" data-bs-toggle="tab"
                    data-bs-target="#discovery-pane-security" type="button" role="tab"
                    aria-controls="discovery-pane-security" aria-selected="false">
                    Security
                </button>
            </li>
            <li class="nav-item" role="presentation">
                <button class="nav-link" id="discovery-tab-technology" data-bs-toggle="tab"
                    data-bs-target="#discovery-pane-technology" type="button" role="tab"
                    aria-controls="discovery-pane-technology" aria-selected="false">
                    Technology
                </button>
            </li>
            <li class="nav-item" role="presentation">
                <button class="nav-link" id="discovery-tab-bi" data-bs-toggle="tab" data-bs-target="#discovery-pane-bi"
                    type="button" role="tab" aria-controls="discovery-pane-bi" aria-selected="false">
                    Business Intelligence
                </button>
            </li>
            
            <li class="nav-item" role="presentation">
                <button class="nav-link" id="discovery-tab-full-audit" data-bs-toggle="tab"
                    data-bs-target="#discovery-pane-full-audit" type="button" role="tab"
                    aria-controls="discovery-pane-full-audit" aria-selected="false">
                    Full Audit Report
                </button>
            </li>
        </ul>

        <div class="tab-content pt-4" id="discoveryDetailTabsContent">
            
            <div class="tab-pane fade show active" id="discovery-pane-overview" role="tabpanel"
                aria-labelledby="discovery-tab-overview" tabindex="0">
                <div class="card mb-4">
                    <div class="card-body p-4">
                        <div class="d-flex flex-wrap align-items-start justify-content-between gap-3 mb-3">
                            <div class="d-flex flex-wrap gap-2">
                                <?php if($website->industry): ?>
                                    <span class="badge bg-secondary-subtle text-secondary-emphasis">
                                        <?php echo e($website->industry); ?>

                                    </span>
                                <?php endif; ?>
                                <?php if($website->sub_niche): ?>
                                    <span class="badge bg-secondary-subtle text-secondary-emphasis">
                                        <?php echo e($website->sub_niche); ?>

                                    </span>
                                <?php endif; ?>
                                <?php if($website->country): ?>
                                    <span class="badge bg-secondary-subtle text-secondary-emphasis">
                                        <?php echo e($website->country); ?>

                                    </span>
                                <?php endif; ?>
                                <?php if($website->region): ?>
                                    <span class="badge bg-secondary-subtle text-secondary-emphasis">
                                        <?php echo e($website->region); ?>

                                    </span>
                                <?php endif; ?>
                                <?php if($website->city): ?>
                                    <span class="badge bg-secondary-subtle text-secondary-emphasis">
                                        <?php echo e($website->city); ?>

                                    </span>
                                <?php endif; ?>
                            </div>

                            <div class="d-flex align-items-center gap-2 flex-shrink-0"
                                title="<?php echo e($opportunityResult->summary); ?>">
                                <span class="opportunity-dot" style="background-color: <?php echo e($opportunityColor); ?>;"></span>
                                <span class="small fw-medium">
                                    <?php echo e($opportunityLevel->label()); ?> Opportunity
                                    (<?php echo e($opportunityResult->score); ?>/100)
                                </span>
                            </div>
                        </div>

                        <div class="result-card-rings mb-3">
                            <?php $__currentLoopData = $scoreRings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $label => $score): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="text-center">
                                    <div class="mini-ring"
                                        style="--ring-pct: <?php echo e($score ?? 0); ?>; --gauge-color: <?php echo e(audit_score_color_var($score)); ?>;"
                                        role="img"
                                        aria-label="<?php echo e($label); ?> score <?php echo e($score ?? 'not available'); ?> out of 100">
                                        <span class="mini-ring-value"><?php echo e($score ?? '—'); ?></span>
                                    </div>
                                    <p class="result-card-ring-label mb-0"><?php echo e($label); ?></p>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>

                        <?php if($technologies->isNotEmpty()): ?>
                            <div class="d-flex flex-wrap gap-2">
                                <?php $__currentLoopData = $technologies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $technology): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <span class="tech-pill"><?php echo e($technology); ?></span>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>

                <div class="row g-4">
                    <div class="col-12 col-md-6">
                        <div class="card h-100">
                            <div class="card-body p-4">
                                <h2 class="h6">Contact Information</h2>
                                <?php if($website->email || $website->phone || $website->contact_page_url): ?>
                                    <ul class="list-unstyled mb-0">
                                        <?php if($website->email): ?>
                                            <li class="mb-2">
                                                <span class="text-secondary small d-block">Email</span>
                                                <a href="mailto:<?php echo e($website->email); ?>"><?php echo e($website->email); ?></a>
                                            </li>
                                        <?php endif; ?>
                                        <?php if($website->phone): ?>
                                            <li class="mb-2">
                                                <span class="text-secondary small d-block">Phone</span>
                                                <?php echo e($website->phone); ?>

                                            </li>
                                        <?php endif; ?>
                                        <?php if($website->contact_page_url): ?>
                                            <li class="mb-0">
                                                <span class="text-secondary small d-block">Contact Page</span>
                                                <a href="<?php echo e($website->contact_page_url); ?>" target="_blank"
                                                    rel="noopener noreferrer">
                                                    <?php echo e($website->contact_page_url); ?>

                                                </a>
                                            </li>
                                        <?php endif; ?>
                                    </ul>
                                <?php else: ?>
                                    <p class="text-secondary small mb-0">No contact information detected yet.</p>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>

                    <div class="col-12 col-md-6">
                        <div class="card h-100">
                            <div class="card-body p-4">
                                <h2 class="h6">Social Media</h2>
                                <?php if(!empty($website->social_profiles)): ?>
                                    <ul class="list-unstyled mb-0">
                                        <?php $__currentLoopData = $website->social_profiles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $platform => $profileUrl): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li class="mb-2">
                                                <span class="text-secondary small d-block">
                                                    <?php echo e(ucfirst($platform)); ?>

                                                </span>
                                                <a href="<?php echo e($profileUrl); ?>" target="_blank" rel="noopener noreferrer">
                                                    <?php echo e($profileUrl); ?>

                                                </a>
                                            </li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                <?php else: ?>
                                    <p class="text-secondary small mb-0">No social profiles detected yet.</p>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            
            <?php $__currentLoopData = [
            'seo' => ['label' => 'SEO', 'score' => $website->seo_score, 'grade' => $website->seo_grade],
            'performance' => ['label' => 'Performance', 'score' => $website->performance_score, 'grade' => $website->performance_grade],
        ]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tabKey => $tabData): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="tab-pane fade" id="discovery-pane-<?php echo e($tabKey); ?>" role="tabpanel"
                    aria-labelledby="discovery-tab-<?php echo e($tabKey); ?>" tabindex="0">
                    <div class="card">
                        <div class="card-body p-4 text-center">
                            <?php if($tabData['score'] !== null): ?>
                                <span class="grade-seal mb-3"
                                    style="color: <?php echo e(audit_score_color_var($tabData['score'])); ?>;">
                                    <?php echo e($tabData['grade'] ?? audit_score_grade_letter($tabData['score'])); ?>

                                </span>
                                <p class="h4 mb-1"><?php echo e($tabData['score']); ?> / 100</p>
                                <p class="text-secondary small mb-4"><?php echo e($tabData['label']); ?> score</p>
                            <?php else: ?>
                                <p class="text-secondary mb-4">
                                    <?php echo e($tabData['label']); ?> score not available yet for this site.
                                </p>
                            <?php endif; ?>

                            <p class="text-secondary small mb-3">
                                This is a lightweight, homepage-only score — not the full checklist a real audit
                                produces.
                            </p>
                            <form method="POST" action="<?php echo e(route('audits.store')); ?>" class="d-inline">
                                <?php echo csrf_field(); ?>
                                <input type="hidden" name="url" value="<?php echo e($website->url); ?>">
                                <button type="submit" class="btn btn-outline-primary btn-sm">
                                    Run a Full Audit
                                </button>
                            </form>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            
            <div class="tab-pane fade" id="discovery-pane-security" role="tabpanel"
                aria-labelledby="discovery-tab-security" tabindex="0">
                <div class="card">
                    <div class="card-body p-4 text-center">
                        <?php if($website->security_score !== null): ?>
                            <span class="grade-seal mb-3"
                                style="color: <?php echo e(audit_score_color_var($website->security_score)); ?>;">
                                <?php echo e($website->security_grade ?? audit_score_grade_letter($website->security_score)); ?>

                            </span>
                            <p class="h4 mb-1"><?php echo e($website->security_score); ?> / 100</p>
                            <p class="text-secondary small mb-3">Security score</p>
                        <?php else: ?>
                            <p class="text-secondary mb-3">Security score not available yet for this site.</p>
                        <?php endif; ?>

                        <?php if($website->ssl_status): ?>
                            <p class="mb-3">
                                <span class="badge bg-secondary-subtle text-secondary-emphasis">
                                    SSL: <?php echo e(ucfirst($website->ssl_status)); ?>

                                </span>
                            </p>
                        <?php endif; ?>

                        <p class="text-secondary small mb-3">
                            This is a lightweight, homepage-only score — not the full checklist a real audit
                            produces.
                        </p>
                        <form method="POST" action="<?php echo e(route('audits.store')); ?>" class="d-inline">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="url" value="<?php echo e($website->url); ?>">
                            <button type="submit" class="btn btn-outline-primary btn-sm">
                                Run a Full Audit
                            </button>
                        </form>
                    </div>
                </div>
            </div>

            
            <div class="tab-pane fade" id="discovery-pane-technology" role="tabpanel"
                aria-labelledby="discovery-tab-technology" tabindex="0">
                <div class="card">
                    <div class="card-body p-4">
                        <dl class="row mb-0">
                            <dt class="col-sm-3">CMS</dt>
                            <dd class="col-sm-9"><?php echo e($website->cms ?? 'Not detected yet'); ?></dd>

                            <dt class="col-sm-3">Framework</dt>
                            <dd class="col-sm-9"><?php echo e($website->framework ?? 'Not detected yet'); ?></dd>

                            <dt class="col-sm-3">E-commerce Platform</dt>
                            <dd class="col-sm-9"><?php echo e($website->ecommerce_platform ?? 'Not detected yet'); ?></dd>

                            <dt class="col-sm-3">Server</dt>
                            <dd class="col-sm-9"><?php echo e($website->server ?? 'Not detected yet'); ?></dd>

                            <dt class="col-sm-3">CDN</dt>
                            <dd class="col-sm-9 mb-0"><?php echo e($website->cdn ?? 'Not detected yet'); ?></dd>
                        </dl>
                    </div>
                </div>
            </div>

            
            <div class="tab-pane fade" id="discovery-pane-bi" role="tabpanel" aria-labelledby="discovery-tab-bi"
                tabindex="0">
                <div class="card">
                    <div class="card-body p-4">
                        <dl class="row mb-0">
                            <dt class="col-sm-4">Business Size</dt>
                            <dd class="col-sm-8"><?php echo e($website->business_size?->label() ?? 'Unknown'); ?></dd>

                            <dt class="col-sm-4">Website Type</dt>
                            <dd class="col-sm-8"><?php echo e($website->website_type?->label() ?? 'Unknown'); ?></dd>

                            <dt class="col-sm-4">Domain Age</dt>
                            <dd class="col-sm-8">
                                <?php if($website->domain_age_days !== null): ?>
                                    <?php echo e(intdiv($website->domain_age_days, 365)); ?> years
                                <?php else: ?>
                                    Unknown
                                <?php endif; ?>
                            </dd>

                            <dt class="col-sm-4">Est. Traffic</dt>
                            <dd class="col-sm-8"><?php echo e($website->estimated_traffic_range ?? 'Not available yet'); ?></dd>

                            <dt class="col-sm-4">Opportunity</dt>
                            <dd class="col-sm-8 d-flex align-items-center gap-2">
                                <span class="opportunity-dot" style="background-color: <?php echo e($opportunityColor); ?>;"></span>
                                <?php echo e($opportunityLevel->label()); ?>

                                (<?php echo e($opportunityResult->score); ?>/100, grade <?php echo e($opportunityResult->grade); ?>)
                            </dd>

                            <dt class="col-sm-4">Opportunity Breakdown</dt>
                            <dd class="col-sm-8">
                                <ul class="list-unstyled mb-0 small">
                                    <li>SEO: <?php echo e($opportunityResult->breakdown['seo']); ?> / 25 pts</li>
                                    <li>Performance: <?php echo e($opportunityResult->breakdown['performance']); ?> / 25 pts</li>
                                    <li>Mobile: <?php echo e($opportunityResult->breakdown['mobile']); ?> / 20 pts</li>
                                    <li>
                                        Accessibility: <?php echo e($opportunityResult->breakdown['accessibility']); ?> / 15 pts
                                    </li>
                                    <li>
                                        Technology Age: <?php echo e($opportunityResult->breakdown['technology_age']); ?> / 15 pts
                                    </li>
                                </ul>
                                <p class="text-secondary small mb-0 mt-1">
                                    Mobile and Technology Age currently read 0 for most sites — neither
                                    mobile_score nor last_updated_at is populated by any enrichment job yet, so
                                    those buckets have no real data to score from.
                                </p>
                            </dd>

                            <dt class="col-sm-4">Recommended Services</dt>
                            <dd class="col-sm-8">
                                <?php if($serviceOpportunities === []): ?>
                                    <span class="text-secondary small">
                                        None detected yet — either this site doesn't meet any of the six
                                        opportunity rules below its current data, or that data isn't available
                                        yet (see the note above about Mobile/Technology Age).
                                    </span>
                                <?php else: ?>
                                    <div class="d-flex flex-wrap gap-2">
                                        <?php $__currentLoopData = $serviceOpportunities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $opportunity): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <span class="badge bg-danger-subtle text-danger-emphasis"
                                                title="<?php echo e($opportunity->reason); ?>">
                                                <?php echo e($opportunity->serviceName); ?>

                                            </span>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                <?php endif; ?>
                            </dd>

                            <dt class="col-sm-4">Discovery Source</dt>
                            <dd class="col-sm-8"><?php echo e($website->discovery_source ?? 'Unknown'); ?></dd>

                            <dt class="col-sm-4">Discovered</dt>
                            <dd class="col-sm-8">
                                <?php echo e($website->discovered_at?->format('M j, Y') ?? 'Unknown'); ?>

                            </dd>

                            <dt class="col-sm-4">Last Updated</dt>
                            <dd class="col-sm-8 mb-0">
                                <?php echo e($website->last_updated_at?->format('M j, Y') ?? 'Not tracked yet'); ?>

                            </dd>
                        </dl>
                    </div>
                </div>
            </div>

            
            <div class="tab-pane fade" id="discovery-pane-full-audit" role="tabpanel"
                aria-labelledby="discovery-tab-full-audit" tabindex="0">
                <?php if($fullReportData !== null): ?>
                    <p class="text-secondary small mb-3">
                        Full audit completed
                        <?php echo e($fullAudit->updated_at?->diffForHumans() ?? 'recently'); ?> —
                        <a href="<?php echo e(route('audits.show', $fullAudit)); ?>">open the standalone report</a>
                        for the print/export options.
                    </p>
                    <?php echo $__env->make('audit.partials.full-report', $fullReportData, array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                <?php else: ?>
                    <div class="card">
                        <div class="card-body p-4 text-center">
                            <p class="mb-3">
                                <?php if($fullAudit !== null): ?>
                                    An audit was queued for this website but hasn't finished yet.
                                    <a href="<?php echo e(route('audits.show', $fullAudit)); ?>">Check its progress</a>.
                                <?php else: ?>
                                    This website hasn't been audited yet — run a full audit to see
                                    SEO, Performance, Security, Accessibility, and every other section
                                    here, right alongside its Discovery data.
                                <?php endif; ?>
                            </p>
                            <?php if($fullAudit === null): ?>
                                <form method="POST" action="<?php echo e(route('audits.store')); ?>" class="d-inline">
                                    <?php echo csrf_field(); ?>
                                    <input type="hidden" name="url" value="<?php echo e($website->url); ?>">
                                    <button type="submit" class="btn btn-primary btn-sm">Audit Now</button>
                                </form>
                            <?php endif; ?>
                        </div>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php if($fullReportData !== null): ?>
    
    <?php $__env->startPush('scripts'); ?>
        <script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.4/dist/chart.umd.min.js"></script>
        <script src="<?php echo e(asset('js/dashboard-charts.js')); ?>"></script>
        <?php if($fullReportData['outreachDraft']): ?>
            <script src="<?php echo e(asset('js/outreach-copy.js')); ?>"></script>
        <?php endif; ?>
    <?php $__env->stopPush(); ?>
<?php endif; ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\laragon\www\MsnVersionUpdate-09-To-13\analytics\resources\views\discovery\show.blade.php ENDPATH**/ ?>