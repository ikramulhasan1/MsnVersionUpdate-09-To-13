
<?php
    $overallScores = $content->scoreRows
        ->pluck('score')
        ->filter(static fn(?int $score): bool => $score !== null)
        ->values();

    $overallScore = $overallScores->isEmpty() ? null : (int) round($overallScores->avg());

    $overallGrade = match (true) {
        $overallScore === null => null,
        $overallScore >= 90 => 'A',
        $overallScore >= 75 => 'B',
        $overallScore >= 60 => 'C',
        $overallScore >= 40 => 'D',
        default => 'F',
    };

    $scoreBadgeColor = match (true) {
        $overallGrade === null => '#9c7a3c',
        in_array($overallGrade, ['A', 'B'], true) => '#2f8f5e',
        in_array($overallGrade, ['C', 'D'], true) => '#b5791f',
        default => '#b23b32',
    };
?>
<div class="pdf-cover">
    <table role="presentation" class="pdf-cover-logo-table">
        <tr>
            <td class="pdf-cover-logo-cell">
                <?php if($header->logoDataUri): ?>
                    <img src="<?php echo e($header->logoDataUri); ?>" alt="<?php echo e($header->companyName); ?>" class="pdf-cover-logo-img">
                <?php else: ?>
                    <span class="pdf-cover-logo-text"><?php echo e($header->companyName); ?></span>
                <?php endif; ?>
            </td>
        </tr>
    </table>

    <h1 class="pdf-cover-title">Website Audit Report</h1>

    <p class="pdf-cover-url"><?php echo e($header->websiteUrl); ?></p>
    <p class="pdf-cover-date">Generated <?php echo e($header->auditDate); ?></p>

    <?php if($overallScore !== null): ?>
        <table role="presentation" class="pdf-score-badge-table">
            <tr>
                <td class="pdf-score-badge-cell">
                    <div class="pdf-score-badge" style="background-color: <?php echo e($scoreBadgeColor); ?>;">
                        <div class="pdf-score-badge-number"><?php echo e($overallScore); ?></div>
                    </div>
                </td>
            </tr>
        </table>
        <p class="pdf-score-badge-caption">
            Overall Score: <?php echo e($overallScore); ?> / 100@if ($overallGrade)
                &nbsp;&mdash;&nbsp;Grade <?php echo e($overallGrade); ?>

            <?php endif; ?>
        </p>
    <?php else: ?>
        <p class="pdf-score-badge-empty">Overall score not available yet.</p>
    <?php endif; ?>

    <div class="pdf-cover-divider"></div>
</div>
<?php /**PATH D:\laragon\www\MsnVersionUpdate-09-To-13\analytics\resources\views\audit\pdf\partials\header.blade.php ENDPATH**/ ?>