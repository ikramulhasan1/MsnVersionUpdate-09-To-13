<?php $__env->startSection('title', 'Website Audit & Analysis Platform'); ?>

<?php $__env->startSection('content'); ?>
    <section class="hero">
        <div class="container text-center">
            <h1 class="hero-title">Know exactly what's holding your website back.</h1>
            <p class="hero-subtitle">
                Enter a URL and get a full technical, SEO, performance, security and UX audit &mdash; automatically.
            </p>

            <?php if($errors->any()): ?>
                <div class="alert alert-danger text-start mx-auto audit-form-width" role="alert">
                    <ul class="mb-0 ps-3">
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>

            <form
                id="audit-form"
                action="<?php echo e(route('audits.store')); ?>"
                method="POST"
                class="audit-form mx-auto audit-form-width"
            >
                <?php echo csrf_field(); ?>
                <div class="input-group input-group-lg shadow-sm">
                    <span class="input-group-text">https://</span>
                    <input
                        type="text"
                        name="url"
                        id="url"
                        class="form-control"
                        placeholder="example.com"
                        value="<?php echo e(old('url')); ?>"
                        required
                        autofocus
                    >
                    <button class="btn btn-primary px-4" type="submit" id="audit-submit">
                        Analyze
                    </button>
                </div>
                <p class="text-secondary small mt-2 mb-0">
                    Full report in minutes. No signup required.
                </p>
            </form>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script>
        document.getElementById('audit-form')?.addEventListener('submit', function (event) {
            const urlField = document.getElementById('url');
            let value = urlField.value.trim();

            // Allow users to type "example.com" and normalize to a full URL
            // before the native form submission fires.
            if (value && !/^https?:\/\//i.test(value)) {
                urlField.value = 'https://' + value;
            }

            AuditApp.showLoadingOverlay();
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\laragon\www\MsnVersionUpdate-09-To-13\analytics\resources\views/home/index.blade.php ENDPATH**/ ?>