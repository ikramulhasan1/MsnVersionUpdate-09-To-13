

<?php $__env->startSection('title', 'Dashboard — Website Audit & Analysis Platform'); ?>

<?php $__env->startSection('content'); ?>
    <section class="container py-4">
        
        <?php if(session('plan_limit_message')): ?>
            <div class="alert alert-warning small mb-4"><?php echo e(session('plan_limit_message')); ?></div>
        <?php endif; ?>

        <h1 class="h4 fw-semibold mb-1">Welcome back, <?php echo e(auth()->user()->name); ?></h1>
        <p class="text-secondary mb-4">Here's what's happening with your account.</p>

        <div class="row g-3 mb-4">
            <div class="col-12 col-md-4">
                <div class="card h-100">
                    <div class="card-body p-4">
                        <p class="text-secondary small mb-1">Total Audits Run</p>
                        <p class="h3 fw-bold mb-0"><?php echo e($auditCount); ?></p>
                    </div>
                </div>
            </div>
            <div class="col-12 col-md-4">
                <div class="card h-100">
                    <div class="card-body p-4">
                        <p class="text-secondary small mb-1">Websites Watched</p>
                        <p class="h3 fw-bold mb-0"><?php echo e($watchlistCount); ?></p>
                    </div>
                </div>
            </div>
            <div class="col-12 col-md-4">
                <div class="card h-100">
                    <div class="card-body p-4">
                        <p class="text-secondary small mb-1">Unread Notifications</p>
                        <p class="h3 fw-bold mb-0"><?php echo e($unreadNotificationCount); ?></p>
                    </div>
                </div>
            </div>
        </div>

        <div class="row g-3">
            <div class="col-12 col-lg-7">
                <div class="card mb-3">
                    <div class="card-body p-4">
                        <div class="d-flex align-items-center justify-content-between mb-3">
                            <h2 class="h6 fw-semibold mb-0">Recent Audits</h2>
                            <?php if($auditCount > 0): ?>
                                <span class="text-secondary small"><?php echo e($auditCount); ?> total</span>
                            <?php endif; ?>
                        </div>

                        <?php $__empty_1 = true; $__currentLoopData = $recentAudits; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $audit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <a href="<?php echo e(route('audits.show', $audit)); ?>"
                                class="d-flex align-items-center justify-content-between py-2 text-decoration-none border-bottom">
                                <span class="text-truncate me-2"><?php echo e($audit->url); ?></span>
                                <span class="badge <?php echo e(audit_status_badge_class($audit->status)); ?> flex-shrink-0">
                                    <?php echo e(audit_status_label($audit->status)); ?>

                                </span>
                            </a>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <p class="text-secondary small mb-0">You haven't run any audits yet.</p>
                        <?php endif; ?>
                    </div>
                </div>

                
                <div class="card">
                    <div class="card-body p-4">
                        <h2 class="h6 fw-semibold mb-2">Subscription</h2>

                        <?php if($plan === null): ?>
                            <p class="text-secondary small mb-0">No plan assigned yet.</p>
                        <?php else: ?>
                            <p class="mb-1">
                                <span class="fw-medium"><?php echo e($plan->name); ?></span>
                                <?php if($onTrial): ?>
                                    <span class="badge bg-warning-subtle text-warning-emphasis ms-1">
                                        Trial &mdash; ends <?php echo e(auth()->user()->trial_ends_at->diffForHumans()); ?>

                                    </span>
                                <?php elseif($trialExpired): ?>
                                    <span class="badge bg-danger-subtle text-danger-emphasis ms-1">
                                        Trial ended
                                    </span>
                                <?php endif; ?>
                            </p>

                            <?php if($trialExpired): ?>
                                <p class="text-secondary small mb-3">
                                    Your free trial has ended. Upgrade to keep running audits, use Bulk
                                    Audit, and export your reports.
                                </p>
                                <a href="<?php echo e(route('subscription.upgrade')); ?>" class="btn btn-primary btn-sm">
                                    Upgrade Now
                                </a>
                            <?php elseif($onTrial): ?>
                                <p class="text-secondary small mb-0">
                                    <?php echo e($plan->dailyAuditLimit() !== null ? $plan->dailyAuditLimit() . ' audit(s)/day, ' : ''); ?>

                                    <?php echo e($plan->allowsFeature('run-bulk-audit') ? '' : 'no Bulk Audit, '); ?>

                                    <?php echo e($plan->allowsFeature('export-data') ? '' : 'no exports'); ?>

                                    &mdash; during your trial.
                                </p>
                            <?php else: ?>
                                <p class="text-secondary small mb-0"><?php echo e($plan->priceLabel()); ?></p>
                            <?php endif; ?>
                        <?php endif; ?>
                    </div>
                </div>
            </div>

            <div class="col-12 col-lg-5">
                <div class="card mb-3">
                    <div class="card-body p-4">
                        <h2 class="h6 fw-semibold mb-3">Quick Actions</h2>
                        <div class="d-grid gap-2">
                            <a href="<?php echo e(route('home')); ?>" class="btn btn-primary btn-sm">Run a New Audit</a>
                            <a href="<?php echo e(route('discovery.index')); ?>" class="btn btn-outline-secondary btn-sm">
                                Browse Website Discovery
                            </a>
                            <a href="<?php echo e(route('bulk-audits.create')); ?>" class="btn btn-outline-secondary btn-sm">
                                Start a Bulk Audit
                            </a>
                            <a href="<?php echo e(route('discovery.watchlist')); ?>" class="btn btn-outline-secondary btn-sm">
                                View My Watchlist
                            </a>
                            
                            <a href="<?php echo e(route('subscription.upgrade')); ?>" class="btn btn-outline-secondary btn-sm">
                                Upgrade Subscription
                            </a>
                        </div>
                    </div>
                </div>

                <div class="card">
                    <div class="card-body p-4">
                        <div class="d-flex align-items-center justify-content-between mb-3">
                            <h2 class="h6 fw-semibold mb-0">Recent Notifications</h2>
                            <a href="<?php echo e(route('notifications.index')); ?>" class="small text-decoration-none">
                                View all
                            </a>
                        </div>

                        <?php $__empty_1 = true; $__currentLoopData = $recentNotifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <div class="py-2 border-bottom <?php echo e($notification->read_at === null ? 'app-notification-item unread' : ''); ?>">
                                <p class="fw-medium small mb-0"><?php echo e($notification->data['title'] ?? 'Notification'); ?></p>
                                <p class="text-secondary small mb-0"><?php echo e($notification->data['message'] ?? ''); ?></p>
                                <p class="text-secondary mb-0" style="font-size: 0.75rem;">
                                    <?php echo e($notification->created_at?->diffForHumans()); ?>

                                </p>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <p class="text-secondary small mb-0">No notifications yet.</p>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\laragon\www\MsnVersionUpdate-09-To-13\analytics\resources\views\dashboard\index.blade.php ENDPATH**/ ?>