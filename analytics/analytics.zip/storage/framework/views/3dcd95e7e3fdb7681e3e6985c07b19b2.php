<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title><?php echo $__env->yieldContent('title', 'Website Audit & Analysis Platform'); ?></title>

    
    <script>
        (function() {
            var saved = localStorage.getItem('audit-theme');
            var theme = saved || (window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light');
            document.documentElement.setAttribute('data-bs-theme', theme);
        })();
    </script>

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link rel="stylesheet"
        href="https://fonts.googleapis.com/css2?family=Fraunces:opsz,wght@9..144,500;9..144,600;9..144,700&family=Inter:wght@400;500;600;700&family=JetBrains+Mono:wght@500;700&display=swap">

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
    
    <link rel="stylesheet"
        href="<?php echo e(asset('css/app.css')); ?>?v=<?php echo e(file_exists(public_path('css/app.css')) ? filemtime(public_path('css/app.css')) : time()); ?>">
    <?php echo $__env->yieldPushContent('styles'); ?>
</head>

<body>
    
    <?php echo $__env->make('layouts.partials.sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <div class="app-main-wrapper">
        <div class="app-topbar d-print-none">
            <button type="button" id="app-sidebar-toggle" class="btn btn-sm app-sidebar-toggle-btn"
                aria-label="Toggle sidebar" aria-expanded="true">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"
                    stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
                    <path d="M4 6h16M4 12h16M4 18h16"></path>
                </svg>
            </button>

            <div class="ms-auto d-flex align-items-center">
                <button type="button" id="theme-toggle" class="btn btn-sm theme-toggle"
                    aria-label="Toggle dark mode" aria-pressed="false">
                    <svg class="theme-toggle-icon theme-toggle-icon-light" viewBox="0 0 24 24" fill="none"
                        stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"
                        aria-hidden="true">
                        <circle cx="12" cy="12" r="4"></circle>
                        <path
                            d="M12 2v2M12 20v2M4.93 4.93l1.41 1.41M17.66 17.66l1.41 1.41M2 12h2M20 12h2M6.34 17.66l-1.41 1.41M19.07 4.93l-1.41 1.41">
                        </path>
                    </svg>
                    <svg class="theme-toggle-icon theme-toggle-icon-dark" viewBox="0 0 24 24" fill="none"
                        stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"
                        aria-hidden="true">
                        <path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"></path>
                    </svg>
                </button>

                
                <?php if(auth()->guard()->check()): ?>
                    <div class="dropdown ms-3">
                        <button class="btn btn-sm app-user-menu-toggle dropdown-toggle d-flex align-items-center gap-2"
                            type="button" data-bs-toggle="dropdown" aria-expanded="false">
                            <?php if(auth()->user()->avatar_url): ?>
                                <img src="<?php echo e(auth()->user()->avatar_url); ?>" alt="" class="app-user-avatar"
                                    width="24" height="24">
                            <?php else: ?>
                                <span class="app-user-avatar app-user-avatar-initials"><?php echo e(auth()->user()->initials()); ?></span>
                            <?php endif; ?>
                            <span class="d-none d-md-inline"><?php echo e(auth()->user()->name); ?></span>
                        </button>
                        <ul class="dropdown-menu dropdown-menu-end">
                            <li><h6 class="dropdown-header"><?php echo e(auth()->user()->email); ?></h6></li>
                            <li><hr class="dropdown-divider"></li>
                            <li>
                                <form method="POST" action="<?php echo e(route('logout')); ?>">
                                    <?php echo csrf_field(); ?>
                                    <button type="submit" class="dropdown-item">Log Out</button>
                                </form>
                            </li>
                        </ul>
                    </div>
                <?php else: ?>
                    <a href="<?php echo e(route('login')); ?>" class="btn btn-sm btn-outline-secondary ms-3">Log In</a>
                    <a href="<?php echo e(route('register')); ?>" class="btn btn-sm btn-primary ms-2">Sign Up</a>
                <?php endif; ?>
            </div>
        </div>

        <main>
            <?php echo $__env->yieldContent('content'); ?>
        </main>

        <footer class="app-footer text-center text-secondary py-4 d-print-none">
            <div class="container small">
                &copy; <?php echo e(date('Y')); ?> Website Audit &amp; Analysis Platform.
            </div>
        </footer>
    </div>

    <div id="loading-overlay" class="loading-overlay d-none d-print-none">
        <div class="text-center">
            <div class="spinner-border" role="status" aria-hidden="true"></div>
            <p class="mt-3 mb-0 fw-medium">Analyzing website&hellip;</p>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="<?php echo e(asset('js/app.js')); ?>"></script>
    <script src="<?php echo e(asset('js/theme.js')); ?>"></script>
    <script src="<?php echo e(asset('js/sidebar.js')); ?>"></script>
    <?php if(auth()->guard()->check()): ?>
        
        <script src="<?php echo e(asset('js/notifications.js')); ?>"
            data-recent-url="<?php echo e(route('notifications.recent')); ?>"></script>
    <?php endif; ?>
    <?php echo $__env->yieldPushContent('scripts'); ?>
</body>

</html><?php /**PATH D:\laragon\www\MsnVersionUpdate-09-To-13\analytics\resources\views\layouts\app.blade.php ENDPATH**/ ?>